# New Glenn 7×2 外观模型

本模型选定 **NG-1 发射前外观**，以 Blue Origin 官方整箭照片定轮廓。NG-2 的官方尾段近照用于补充热防护分块与收拢状态的观察。总高 98 米、箭体名义直径 7 米；其他部件位置与尺寸均为照片估计，不是工程 CAD。

## 文件与验证

- `new-glenn-refined.blend`：米制、Z 轴朝上的可编辑源文件，保留独立壳体、支腿、紧固件和相机。
- `new-glenn-refined.glb`：米制、Y 轴朝上的网页资产；地面为 y=0。网格按语义部件和材质合并，整流罩左右瓣独立。
- `build_new_glenn.py`：完整可重建脚本；先保存可编辑 `.blend`，再合批导出 GLB。
- `verify_glb.py`、`glb-validation.json`：直接读取 GLB 二进制位置数据与节点变换，独立检查高度、轴向、根节点、部件归属、发动机和回收装置计数。
- `asset-stats.json`：建模端统计。以 `glb-validation.json` 的实际导出数据为最终性能与尺寸依据。
- `qa-full.png`、`qa-aft.png`、`qa-upper.png`、`qa-engines.png`、`qa-exploded.png`：完整、尾段、级间、七台喷管与分解检查图，已逐张查看。

GLB 根节点 `NG` 的自定义字段为 `vehicle=newglenn`、`variant=refined`。直接子节点只有 `booster`、`upper`、`fairing`；`recovery` 在 `booster` 内。每个网格都带 `part` 字段，其值为 `booster`、`upper`、`fairing` 或 `recovery`。两台 BE-3U 始终归属 `upper`，组装时全部收在级间段内；没有独立留在一级上的二级喷管。

导出没有相机、灯光、外部贴图、动画或第三方商标贴图。官网文字与羽毛标志由网站的独立涂装层处理。

## 官方实拍依据

照片版权归 Blue Origin。官网图库明确允许下载，并要求署名 Blue Origin。这里保存的照片供外形核对与可追溯记录使用，不是 GLB 贴图。

1. **NG-1 发射前整箭照片，主参考。** Blue Origin 在 2025-01-06 的 NG-1 页面展示发射台上的 New Glenn。用来确定白色主箭体、蓝色下边界、棕色级间段、长边条翼、二级环纹与整流罩曲线。
   - 说明页：[Blue Origin · NG-1](https://www.blueorigin.com/news/new-glenn-ng-1-mission)
   - 原图：[New-Glenn_Upend.jpg](https://d1o72l87sylvqg.cloudfront.net/blue-origin/New-Glenn_Upend.jpg)
   - 本地：`source-images/ng1-pad-upend.jpg`
2. **NG-2 尾段近照，补充参考。** 官网原图可清楚看到蓝色弧边、棕色热防护板、板边紧固件及两侧边条翼。模型不复制 NG-2 的任务名称，也不把 NG-2 名称混入 NG-1 涂装。
   - 说明页：[Blue Origin 官方图库](https://www.blueorigin.com/gallery/asset/6931c2fdac77095f7c5fe3b8)
   - 原图：[NG-2 tail](https://d1o72l87sylvqg.cloudfront.net/redstone/gallery-gallery_ng-2-nevertellmetheodds.jpg)
   - 本地：`source-images/ng2-stowed-tail.jpg`
3. **NG-2 回收全箭照片，2025-11-18。** 用于辅助观察长边条翼与前部控制翼的位置。图片拍摄较远，不能据此测定支腿铰链的工程尺寸。
   - 说明页：[Blue Origin 官方图库](https://www.blueorigin.com/gallery/asset/6931c2feb5fe7d829af49fdb)
   - 原图：[Recovered booster](https://d1o72l87sylvqg.cloudfront.net/redstone/gallery-dsc09492u.jpg)
   - 本地：`source-images/ng2-port-recovered.jpg`
4. **NG-2 海上回收远景，2025-11-15。** 仅留作回收构型背景；不用于细小结构重建。
   - 说明页：[Blue Origin 官方图库](https://www.blueorigin.com/gallery/asset/6931c2fedbc1528b6114d874)
   - 原图：[Booster on Jacklyn](https://d1o72l87sylvqg.cloudfront.net/redstone/gallery-gallery_ng2-jacklyn-towing.jpg)
   - 本地：`source-images/ng2-recovered-booster.jpg`
5. **官方七喷管照片。** [产品页原图](https://d1o72l87sylvqg.cloudfront.net/blue-origin/newglenn_high-performing-engines.jpg)保存为 `official-seven-be4-current.jpg`，确认七喷管外六内一排列。对该图的 SHA-256 核验表明，它与任务开始前已有的 `ng1-seven-be4.jpg` 完全相同；旧文件名中的“NG-1”不单独作为拍摄任务证据。`ng3-side-context-not-primary.png` 来自官网现用 2026 年整箭图，仅作结构延续的背景核对；NG-3 特有发动机更新、热防护修改和任务标识未移植。

官方数量与总体尺度核对来自 [New Glenn 产品页](https://www.blueorigin.com/new-glenn)：7 台 BE-4、2 台 BE-3U、4 片活动控制翼、6 条着陆腿，整体高度 98 米、整流罩直径 7 米。页面对两条长边条翼有说明，数量和轮廓结合正面实拍核对。[2024-09-23 二级热试车说明](https://www.blueorigin.com/news/new-glenn-completes-second-stage-hotfire)确认二级直径为 7 米；其二级整体高度口径包括隐藏段，不等同本模型露在级间段以上的白色外壳高度。

## 已建内容与近似边界

- 第九版更正：删除一级正反两面的推测性纵向长盖板、深色凹槽和固定件。官方 NG-1 正面实拍不支持一根长条贯穿 NEW GLENN / BLUE ORIGIN 字样；不能把它解释成已确认的管路。二级照片可见的局部盖板不受本次修改影响。
- 尾部为轻微鼓起的桶形外壳，分段过渡到 7 米白色箭体；替换原先大幅张开的简单圆锥。
- 棕色热防护分块、细接缝、部分板边紧固件有独立几何。颜色受实拍光照影响，采用克制的褐色变化，不重现某一次飞行的焦痕。
- 六条收拢支腿为贴近尾段的长壳体，带下端鞋形件、铰链和边缘接缝。可见比例取照片估计；缺少可测量的完整近照，壳厚、铰链轴径、板内机构与精确形状不可视为实物测绘。
- 一级四片控制翼、两条长边条翼分别建模。翼面位置、外伸长度、后掠角与细接缝为照片近似。不会把它们叫作 Falcon 格栅翼。
- 二级保留密集但浅的环纹，外露纵向盖板和低处流线形凸起。未编造盖板内的管道或线路功能。
- 七台 BE-4 与两台 BE-3U 有内外喷管壁、出口唇和简化喉部。隐藏的泵、阀、管路不建；喷管曲线不是制造图纸。
- 二级顶部采用简单的封闭外形，避免分解图显示成空管。这个顶面明确属于说明性封闭包络，未声称是实际储箱顶、任务载荷适配器或精确内部结构。
- 两瓣整流罩带薄内壁、分离边缘、底部圆形开口和细接缝。内壁颜色和厚度、开口具体功能均未作为工程事实标注。
- 98 米总高精确用于网站统一尺度；y=62 米的二级外壳起点、y=79.8 米的整流罩起点是照片估计，不单独发布为官方尺寸。

## 网站接入提醒

- `upper.position.y=62`，`fairing.position.y=79.8`，不要额外添加旧模型的 58 米二级偏移。
- 一级白色标志区域仍为半径 3.5 米。二级浅环纹最外缘为半径约 3.529 米，羽毛贴花建议半径至少 3.55 米，避免与环纹相交；羽毛中心可放在二级局部 y=9.3 米附近，并结合浏览器实看微调。
- 两瓣整流罩沿 X 轴向外移动；`fairing-left` 使用负 X，`fairing-right` 使用正 X。
- GLB 没有动画。网站仍用 semantic part movers 控制讲解式分解，不应把这种间距示意标为真实分离轨迹。

## New Glenn 9×4：只提出差异建议，不生成新资产

依据 [Blue Origin 9×4 产品页](https://www.blueorigin.com/new-glenn/9x4)，可确认的是近 400 英尺总高、8.7 米整流罩、一级 9 台 BE-4 Block 2、二级 4 台 BE-3U。页面没有将 **8.7 米明确写成一级箭体直径**，不能直接把整流罩宽度当全箭直径。

已保存官方概念图，全部为设计效果图，不能标成已飞行实物：

- [整箭演进对比](https://d1o72l87sylvqg.cloudfront.net/redstone/NG9x4_Evolution.jpg)：`source-images/ng9x4-evolution-concept.jpg`。
- [尾段与九喷管对比](https://d1o72l87sylvqg.cloudfront.net/blue-origin/NewGlenn-9x4_aftcompare_white.jpg)：`source-images/ng9x4-aft-comparison.jpg`。
- [四台二级发动机](https://d1o72l87sylvqg.cloudfront.net/blue-origin/NewGlenn-9x4_quattro.jpg)：`source-images/ng9x4-upper-concept.jpg`。
- [8.7 米整流罩俯视](https://d1o72l87sylvqg.cloudfront.net/blue-origin/NewGlenn-9x4_fairing.jpg)：`source-images/ng9x4-fairing-concept.jpg`。

适合做的有限差异：保留同一家族的白、蓝、棕色分区；上部更长，整流罩相对箭体有可辨认的扩径肩部；尾部九喷管为外圈八台与中央一台，设计图的排气口周围有多边形覆盖层；二级四喷管；边条翼相对全箭更短且更宽；尾部外侧腿壳的设计轮廓更明显。全箭对比图中的短白色级间领圈也可作为外形线索。

不应做的扩展：把 7×2 的 NG-1/NG-2 精确磨损、板块和支腿铰链直接复制成 9×4 已验证配置；把概念图细管线解释为已披露的工作机构；把近 400 英尺写成官方精确 121.92 米；把 8.7 米整流罩宽度自动应用到所有储箱。9×4 应继续显著标注“官方概念外形近似”。
