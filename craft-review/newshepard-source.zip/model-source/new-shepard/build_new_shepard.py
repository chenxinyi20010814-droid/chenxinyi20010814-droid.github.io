"""New Shepard crew-generation exterior, photo-led educational asset.
Blender 4.5+. Run: blender -b --factory-startup --python build_new_shepard.py
Only writes beside this script, or --output DIR. Metres/Z-up -> glTF Y-up.
19.2 m assembled height and 3.8 m capsule diameter are retained approximate
gallery dimensions, not claimed Blue Origin engineering measurements.
"""
import bpy, bmesh, math, json, sys, argparse, struct
from pathlib import Path
from mathutils import Vector, Matrix

parser=argparse.ArgumentParser(); parser.add_argument('--output',default=str(Path(__file__).resolve().parent))
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
OUT=Path(args.output).resolve(); OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene; scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1

def material(name,color,metal=0,rough=.5,coat=0):
    m=bpy.data.materials.new(name); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
    p.inputs['Coat Weight'].default_value=coat;p.inputs['Coat Roughness'].default_value=.10
    m.diffuse_color=(*color,1)
    return m

paint=material('NS exterior · clean warm white paint',(.815,.83,.835),.035,.43)
panelpaint=material('NS secondary fairings · slightly cooler white',(.70,.73,.75),.04,.48)
rimpaint=material('NS rounded edge and window frame · light grey',(.53,.57,.60),.18,.41)
joint=material('NS recessed panel joint',(.16,.18,.20),.05,.72)
seal=material('NS window gasket and protected recess',(.016,.022,.027),.04,.73)
glass=material('NS deep blue-grey curved glazing',(.010,.029,.046),.20,.105,.85)
dark=material('NS shaded non-reconstructed interior',(.008,.011,.015),0,.88)
metal=material('NS nozzle · satin metal surface',(.28,.30,.32),.69,.37)
neckmat=material('NS nozzle upper section · dark metal',(.065,.078,.09),.55,.55)
innermat=material('NS nozzle inner wall',(.026,.035,.042),.30,.76)
hardware=material('NS visible hinge and interface · satin grey',(.32,.35,.37),.65,.38)
underside=material('NS capsule underside · muted grey cover',(.36,.39,.40),.07,.72)

def empty(name,parent=None,loc=(0,0,0),part=None):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.parent=parent;o.location=loc
    if part:o['part']=part
    return o
root=empty('NS');root['vehicle']='newshepard';root['variant']='refined'
root['configuration']='Crew-generation New Shepard, six windows, launch configuration; recovery hardware stowed'
root['dimensions']='19.2m height / 3.8m capsule diameter are retained approximations, not official CAD values'
root['source_precision']='Blue Origin product structure diagram and modern crew photos; stations, small profiles and hardware dimensions estimated'
booster=empty('booster',root,part='booster')
recovery=empty('recovery',booster,part='recovery')
capsule=empty('capsule',root,(0,0,14.8),'capsule')
capsule['window_count']=6;capsule['configuration']='Closed crew capsule; no invented seats, escape plumbing or parachutes'

def part_of(o):
    p=o
    while p and not p.get('part'):p=p.parent
    return p.get('part') if p else None

def mesh(name,verts,faces,mat,parent,smooth=True,recalc=False):
    d=bpy.data.meshes.new(name);d.from_pydata(verts,[],faces);d.update()
    if recalc:
        bm=bmesh.new();bm.from_mesh(d);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(d);bm.free()
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.parent=parent
    d.materials.append(mat);o['part']=part_of(parent)
    for p in d.polygons:p.use_smooth=smooth
    return o

def lathe(name,profile,mat,parent,n=128,start=0,span=math.tau):
    verts=[(r*math.cos(start+span*i/n),r*math.sin(start+span*i/n),z) for r,z in profile for i in range(n+1)]
    faces=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=j*(n+1)+i;faces.append((a,a+1,a+n+2,a+n+1))
    return mesh(name,verts,faces,mat,parent)

def ring(name,r,z,minor,mat,parent,n=96,sections=10):
    return lathe(name,[(r+minor*math.cos(i*math.tau/sections),z+minor*math.sin(i*math.tau/sections)) for i in range(sections+1)],mat,parent,n)

def beam(name,a,b,width,depth,mat,parent,bevel=.012):
    a,b=Vector(a),Vector(b)
    bpy.ops.mesh.primitive_cube_add(size=1)
    o=bpy.context.object;o.name=name;o.parent=parent;o.location=(a+b)*.5
    o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();o.scale=(width,depth,(b-a).length)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(mat);o['part']=part_of(parent)
    if bevel:
        m=o.modifiers.new('Rounded manufactured exterior edge','BEVEL');m.width=bevel;m.segments=3
        bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=m.name)
    return o

def tube(name,a,b,r,mat,parent,n=32):
    a,b=Vector(a),Vector(b)
    o=lathe(name,[(0,0),(r,0),(r,(b-a).length),(0,(b-a).length)],mat,parent,n)
    o.location=a;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o

def curve_tube(name,points,r,mat,parent,closed=False):
    d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.bevel_depth=r;d.bevel_resolution=2
    s=d.splines.new('POLY');s.points.add(len(points)-1)
    for p,co in zip(s.points,points):p.co=(*co,1)
    s.use_cyclic_u=closed
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.parent=parent;d.materials.append(mat)
    bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
    bpy.ops.object.convert(target='MESH');o=bpy.context.object;o['part']=part_of(parent)
    return o

def poly_fin(name,outline,thickness,mat,parent):
    verts=[(r,s*thickness/2,z) for s in [-1,1] for r,z in outline];n=len(outline)
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    for i in range(n):faces.append((i,(i+1)%n,(i+1)%n+n,i+n))
    o=mesh(name,verts,faces,mat,parent,False,True)
    bevel=o.modifiers.new('Lightly rounded fin edge','BEVEL');bevel.width=.017;bevel.segments=3
    bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=bevel.name)
    return o

# Smooth interpolation avoids a stack of conical frusta. All stations remain
# exterior estimates, especially the visually rounded lower thrust section.
def smooth_samples(stations,per_interval=8):
    # Monotone cubic Hermite interpolation in z, using clipped secant slopes.
    zs=[p[1] for p in stations];rs=[p[0] for p in stations]
    sec=[(rs[i+1]-rs[i])/(zs[i+1]-zs[i]) for i in range(len(zs)-1)]
    slopes=[sec[0]]
    for i in range(1,len(zs)-1):
        slopes.append(0 if sec[i-1]*sec[i]<=0 else 2*sec[i-1]*sec[i]/(sec[i-1]+sec[i]))
    slopes.append(sec[-1])
    result=[]
    for i in range(len(zs)-1):
        dz=zs[i+1]-zs[i]
        for k in range(per_interval):
            t=k/per_interval;h00=2*t**3-3*t*t+1;h10=t**3-2*t*t+t;h01=-2*t**3+3*t*t;h11=t**3-t*t
            result.append((h00*rs[i]+h10*dz*slopes[i]+h01*rs[i+1]+h11*dz*slopes[i+1],zs[i]+t*dz))
    result.append(stations[-1]);return result

body_profile=smooth_samples([(1.02,.66),(1.25,.91),(1.46,1.44),(1.55,2.5),(1.55,12.65),(1.52,13.1),(1.49,14.48),(1.40,14.72)],9)
lathe('booster-smooth-exterior',body_profile,paint,booster,192)
for z,r in [(2.5,1.552),(6.2,1.552),(10.9,1.552),(13.08,1.525)]:ring('Fine circumferential body interface',r,z,.007,joint,booster)
lathe('Recessed aft protective annulus',[(1.025,.66),(.62,.75),(.53,.93),(.50,1.06)],neckmat,booster,128)
ring('Aft perimeter rounded lip',1.022,.66,.022,panelpaint,booster)

# One nozzle, with a genuinely open lower bell, separate interior wall and lip.
# Upper machinery is concealed. No arbitrary valves, pumps or engine struts.
engine=empty('BE-3PM',booster);engine['engine']=True;engine['engine_type']='BE-3PM'
bell_profile=[(.65,0),(.649,.05),(.626,.17),(.584,.35),(.529,.55),(.465,.77),(.394,1.02),(.325,1.24),(.265,1.44),(.218,1.65),(.202,1.87)]
lathe('BE-3PM outer bell',smooth_samples(bell_profile,5),metal,engine,128)
lathe('BE-3PM dark inner bell',[(r-.012,z+.006) for r,z in reversed(smooth_samples(bell_profile,5))],innermat,engine,128)
ring('BE-3PM open rolled lip',.645,.018,.018,hardware,engine,128)
lathe('BE-3PM upper dark sleeve',[(.22,1.48),(.23,1.80),(.215,1.92)],neckmat,engine,96)
lathe('BE-3PM unmodelled throat display occluder',[(0,1.925),(.204,1.925)],dark,engine,64)
for z,r in [(.42,.566),(.92,.422),(1.42,.27)]:ring('Subtle nozzle exterior band',r,z,.010,metal,engine,96)

# Upper ring and wedge assembly. Drag-brake panels are closed for launch;
# Blue Origin's separated diagram is a deployed illustration, not launch pose.
upper_ring=empty('upper-ring-and-wedge-assembly',recovery)
upper_ring['source']='Blue Origin current New Shepard structure diagram; stowed silhouette cross-checked with NS-38 liftoff'
lathe('Ring-fin continuous annular lower rim',[(1.51,13.18),(1.71,13.22),(1.80,13.31),(1.82,13.40),(1.81,13.48),(1.75,13.54),(1.54,13.48)],paint,upper_ring,160)
lathe('Ring-fin inner shaded edge',[(1.67,13.39),(1.77,13.42),(1.76,13.50),(1.68,13.50)],joint,upper_ring,128)
lathe('Upper capsule support annulus',[(1.39,14.56),(1.66,14.59),(1.79,14.67),(1.81,14.73),(1.79,14.78),(1.44,14.77)],paint,upper_ring,160)
lathe('Closed booster top exterior cover',[(0,14.60),(.60,14.63),(1.39,14.60)],panelpaint,booster,128)
for k in range(8):
    g=empty('upper-wedge-fin-'+str(k+1),upper_ring);g.rotation_euler.z=k*math.pi/4
    g['wedgeFin']=True
    poly_fin('Radial tapered wedge web',[(1.485,12.89),(1.79,13.32),(1.79,14.68),(1.48,14.56)],.065,paint,g)
    beam('Wedge leading edge',(1.80,0,13.40),(1.80,0,14.59),.055,.08,panelpaint,g,.009)
for k in range(4):
    g=empty('drag-brake-stowed-'+str(k+1),upper_ring);g.rotation_euler.z=math.pi/4+k*math.pi/2
    g['dragBrake']=True;g['pose']='stowed'
    start=-math.pi/8+.035;span=math.pi/4-.07
    p=lathe('Curved stowed drag-brake panel',[(1.79,13.52),(1.792,14.50),(1.765,14.60)],paint,g,36,start,span)
    mod=p.modifiers.new('Brake panel display thickness','SOLIDIFY');mod.thickness=.045
    bpy.context.view_layer.objects.active=p;bpy.ops.object.modifier_apply(modifier=mod.name)
    for a in [start,start+span]:
        curve_tube('Brake side recessed seam',[(1.797*math.cos(a),1.797*math.sin(a),z) for z in [13.56,13.90,14.25,14.52]],.008,joint,g)
    # Visible hinge barrel only; stowed actuating mechanism remains concealed.
    a=start+.08;b=start+span-.08
    curve_tube('Drag-brake hinge barrel',[(1.79*math.cos(a+(b-a)*i/12),1.79*math.sin(a+(b-a)*i/12),13.54) for i in range(13)],.034,hardware,g)

# Four clean, stowed landing-leg shells at cardinal axes. Unlike Falcon legs,
# these are narrow white longitudinal fairings. Only exterior end fittings show.
for k in range(4):
    leg=empty('landing-leg-stowed-'+str(k+1),recovery);leg.rotation_euler.z=k*math.pi/2
    leg['leg']=True;leg['pose']='stowed'
    stations=[(.19,1.49,.12),(.29,1.60,.21),(.70,1.69,.255),(1.7,1.70,.29),(3.5,1.69,.33),(4.85,1.66,.29),(5.36,1.61,.19),(5.63,1.56,.035)]
    verts=[];cols=16
    for z,r,w in stations:
        for i in range(cols+1):
            t=-1+2*i/cols;y=t*w;x=r-.045*(t*t)
            verts.append((x,y,z))
    faces=[]
    for j in range(len(stations)-1):
        for i in range(cols):
            a=j*(cols+1)+i;faces.append((a,a+1,a+cols+2,a+cols+1))
    shell=mesh('Curved stowed landing-leg shell',verts,faces,panelpaint,leg)
    mod=shell.modifiers.new('Visible leg-shell edge thickness','SOLIDIFY');mod.thickness=.038
    bpy.context.view_layer.objects.active=shell;bpy.ops.object.modifier_apply(modifier=mod.name)
    for sign in [-1,1]:
        curve_tube('Leg fairing perimeter seam',[(r-.041,sign*w,z) for z,r,w in stations],.009,joint,leg)
    beam('Stowed foot end shoe',(1.625,-.17,.25),(1.625,.17,.25),.17,.085,hardware,leg)
    for y in [-.20,.20]:
        beam('Visible leg root mounting cheek',(1.573,y,4.72),(1.573,y,5.04),.12,.065,paint,leg)
    tube('Leg root hinge exterior',(1.59,-.245,4.89),(1.59,.245,4.89),.054,hardware,leg)

# Four interleaved aft control fins. A shallow hinge line distinguishes the
# moveable edge without manufacturing speculative servos or fastener patterns.
for k in range(4):
    g=empty('aft-control-fin-'+str(k+1),recovery);g.rotation_euler.z=math.pi/4+k*math.pi/2
    g['controlFin']=True
    poly_fin('Swept aft control surface',[(1.44,1.35),(2.075,1.97),(2.075,3.05),(1.535,3.80)],.085,paint,g)
    beam('Control-fin external hinge',(1.64,0,1.77),(1.64,0,3.60),.045,.11,hardware,g,.008)
    curve_tube('Fine control surface seam',[(1.80,-.047,z) for z in [1.68,2.17,2.75,3.37]],.007,joint,g)

# One modest longitudinal exterior fairing is visible in Blue Origin's diagram.
service=empty('visible-longitudinal-exterior-fairing',booster);service.rotation_euler.z=math.pi/2
beam('Narrow white longitudinal cover',(1.574,0,5.53),(1.574,0,13.10),.085,.10,panelpaint,service,.025)
for z in [6.4,8.35,10.35,12.25]:
    beam('Cover segment joint',(1.584,-.05,z),(1.584,.05,z),.012,.035,joint,service,.003)

# Capsule: true Boolean window apertures, curved recessed opaque glazing,
# layered window reveals and a hollow display shell (no invented cabin).
cap_stations=[(1.55,0),(1.78,.10),(1.895,.25),(1.9,.47),(1.875,.75),(1.81,1.14),(1.72,1.65),(1.60,2.22),(1.43,2.83),(1.17,3.42),(.84,3.92),(.45,4.27),(0,4.4)]
cap_profile=smooth_samples(cap_stations,12)
def cap_r(z):
    if z<=cap_profile[0][1]:return cap_profile[0][0]
    if z>=4.4:return 0
    for (r0,z0),(r1,z1) in zip(cap_profile,cap_profile[1:]):
        if z0<=z<=z1:return r0+(r1-r0)*(z-z0)/(z1-z0)
    return 0

shell=lathe('capsule-main-rounded-shell',cap_profile,paint,capsule,192)
mod=shell.modifiers.new('Display shell thickness, not pressure-vessel specification','SOLIDIFY');mod.thickness=.065
bpy.context.view_layer.objects.active=shell;bpy.ops.object.modifier_apply(modifier=mod.name)

WINDOW_CENTER=2.05;WINDOW_HALF_H=.89
def window_outline(scale=1,n=72):
    pts=[]
    for i in range(n):
        a=math.tau*i/n;c=math.cos(a);s=math.sin(a)
        dz=WINDOW_HALF_H*math.copysign(abs(s)**.46,s)
        width=.535-.052*(dz/WINDOW_HALF_H)
        x=width*math.copysign(abs(c)**.46,c)
        pts.append((x*scale,WINDOW_CENTER+dz*scale))
    return pts

def curved_point(x,z,offset=0):
    r=cap_r(z)+offset
    return (x,-math.sqrt(max(0,r*r-x*x)),z)

def window_ring(name,outer_scale,inner_scale,outer_offset,inner_offset,mat,parent):
    a=window_outline(outer_scale);b=window_outline(inner_scale)
    verts=[curved_point(x,z,outer_offset) for x,z in a]+[curved_point(x,z,inner_offset) for x,z in b]
    n=len(a);faces=[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return mesh(name,verts,faces,mat,parent)

for k in range(6):
    angle=k*math.pi/3
    points=window_outline();n=len(points)
    verts=[(x,y,z) for y in [-2.5,-.55] for x,z in points]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    for i in range(n):faces.append((i,(i+1)%n,(i+1)%n+n,i+n))
    cutter=mesh('Window aperture cutter',verts,faces,dark,capsule,False,True);cutter.rotation_euler.z=angle
    bpy.context.view_layer.update()
    mod=shell.modifiers.new('True window aperture '+str(k+1),'BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter
    bpy.context.view_layer.objects.active=shell;bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter,do_unlink=True)
    w=empty('crew-window-'+str(k+1),capsule);w.rotation_euler.z=angle;w['window']=True;w['window_index']=k+1
    w['detail']='True aperture, curved inset glazing and layered frame; opaque display glass, no speculative cabin'
    window_ring('Window painted edge surround',1.11,1.035,.017,.018,rimpaint,w)
    window_ring('Recessed black window reveal',1.035,.976,.018,-.052,seal,w)
    outline=window_outline(.977);verts=[curved_point(0,WINDOW_CENTER,-.053)]
    rings=14
    for j in range(1,rings+1):
        t=j/rings
        for x,z in outline:verts.append(curved_point(x*t,WINDOW_CENTER+(z-WINDOW_CENTER)*t,-.054))
    faces=[];n=len(outline)
    for i in range(n):faces.append((0,1+i,1+(i+1)%n))
    for j in range(rings-1):
        for i in range(n):
            a=1+j*n+i;b=1+j*n+(i+1)%n;faces.append((a,a+n,b+n,b))
    mesh('Curved recessed window glass',verts,faces,glass,w)

# Thin exterior panel seams, a single hatch outline around one window, and
# two visible hinge envelopes. Their dimensions/placement are photographic.
for k in range(6):
    a=k*math.pi/3
    ps=[((cap_r(z)+.006)*math.cos(a),(cap_r(z)+.006)*math.sin(a),z) for z in [.56,.85,1.2,1.6,2.0,2.4,2.8,3.13,3.4,3.66]]
    curve_tube('Subtle capsule panel meridian',ps,.0045,rimpaint,capsule)
for z in [.50,3.72]:ring('Capsule circumferential panel seam',cap_r(z)+.003,z,.005,rimpaint,capsule,160)
hatch=empty('closed-crew-hatch',capsule);hatch.rotation_euler.z=0;hatch['hatch']=True
hatchpoints=[]
for i in range(96):
    a=math.tau*i/96;c=math.cos(a);s=math.sin(a)
    z=1.755+1.44*math.copysign(abs(s)**.40,s)
    x=.686*math.copysign(abs(c)**.40,c)
    hatchpoints.append(curved_point(x,z,.011))
curve_tube('Closed crew hatch fine perimeter',hatchpoints,.007,joint,hatch,True)
for z in [.78,2.33]:
    x=.69;y=curved_point(x,z,.015)[1]
    beam('Hatch hinge envelope',(x,y,z-.10),(x,y,z+.10),.10,.05,panelpaint,hatch,.014)
    tube('Hatch exterior hinge pin',(x+.025,y-.035,z-.095),(x+.025,y-.035,z+.095),.020,hardware,hatch,24)

# Closed, restrained underside: no escape-engine or cabin reconstruction.
lathe('Capsule bottom annular skirt',[(1.54,0),(1.79,.06),(1.84,.13),(1.73,.17),(1.47,.10)],panelpaint,capsule,160)
lathe('Capsule underside closed cover',[(0,.05),(.55,.035),(1.30,.055),(1.49,.10)],underside,capsule,160)
ring('Capsule lower recessed interface',1.76,.09,.018,joint,capsule,160)
ring('Capsule lower rounded exterior edge',1.895,.255,.012,paint,capsule,160)
ring('Closed crown panel fine seam',.44,4.275,.004,rimpaint,capsule,96)

for obj in root.children_recursive:
    if obj.type=='MESH':
        obj['source_precision']='Photographic exterior approximation; no engineering dimensions implied'
scene['asset_notes']='Read README.md. Editable components saved before static semantic/material batching. No animations or photo textures.'
bpy.context.view_layer.update()
points=[]
for obj in root.children_recursive:
    if obj.type=='MESH':points.extend(obj.matrix_world@Vector(c) for c in obj.bound_box)
lo=[min(p[i] for p in points) for i in range(3)];hi=[max(p[i] for p in points) for i in range(3)]
dimensions=[hi[i]-lo[i] for i in range(3)]
triangles=lambda:sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in root.children_recursive if o.type=='MESH')
editable_meshes=sum(o.type=='MESH' for o in root.children_recursive)
assert abs(lo[2])<.003 and abs(dimensions[2]-19.2)<.025
assert len([o for o in root.children_recursive if o.get('engine')])==1
assert len([o for o in root.children_recursive if o.get('window')])==6
assert len([o for o in root.children_recursive if o.get('leg')])==4
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'new-shepard.blend'))

# Preserve meaningful component groups, batch only their static material meshes.
boundaries=['engine','window','leg','dragBrake','controlFin','wedgeFin','hatch']
buckets={}
for obj in list(root.children_recursive):
    if obj.type!='MESH':continue
    parent=obj.parent
    while parent!=root and not (parent.get('part') or any(parent.get(k) for k in boundaries)):
        parent=parent.parent
    buckets.setdefault((parent,tuple(m.name for m in obj.data.materials)),[]).append(obj)
for (parent,_),objects in buckets.items():
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:obj.select_set(True)
    bpy.context.view_layer.objects.active=objects[0]
    if len(objects)>1:bpy.ops.object.join()
    obj=bpy.context.object
    transform=parent.matrix_world.inverted()@obj.matrix_world;obj.data.transform(transform)
    obj.parent=parent;obj.matrix_parent_inverse=Matrix.Identity(4);obj.matrix_basis=Matrix.Identity(4)
    obj.name=parent.name+' · '+obj.data.materials[0].name;obj['part']=part_of(parent)
for obj in list(root.children_recursive)[::-1]:
    if obj.type=='EMPTY' and not obj.children and not obj.get('part') and not any(obj.get(k) for k in boundaries):bpy.data.objects.remove(obj,do_unlink=True)
bpy.ops.object.select_all(action='DESELECT')
for obj in [root,*root.children_recursive]:obj.select_set(True)
bpy.context.view_layer.update()
bpy.ops.export_scene.gltf(filepath=str(OUT/'new-shepard.glb'),export_format='GLB',use_selection=True,export_extras=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False)
raw=(OUT/'new-shepard.glb').read_bytes();gltf=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]])
gm=gltf['meshes'];ga=gltf['accessors'];gn=gltf['nodes']
readback={'nodes':len(gn),'mesh_instances':sum(len(gm[n['mesh']]['primitives']) for n in gn if 'mesh' in n),
 'triangles':sum(sum(ga[p['indices']]['count']//3 for p in gm[n['mesh']]['primitives']) for n in gn if 'mesh' in n),
 'engines':sum(bool(n.get('extras',{}).get('engine')) for n in gn),
 'windows':sum(bool(n.get('extras',{}).get('window')) for n in gn),
 'legs':sum(bool(n.get('extras',{}).get('leg')) for n in gn),
 'animations':len(gltf.get('animations',[]))}
report={'vehicle':'newshepard','variant':'refined','configuration':'crew-generation, launch/stowed',
 'height_approx_m':19.2,'capsule_diameter_approx_m':3.8,'capsule_base_z_m':14.8,
 'capsule_shell_radii_local_z_m':{str(z):round(cap_r(z),6) for z in [.65,.70,.75,.80,.85,.90,.95]},
 'capsule_window_vertical_limits_local_z_m':{'aperture':[1.16,2.94],'outer_frame':[1.0621,3.0379]},
 'bounds_z_up_m':{'min':lo,'max':hi,'size':dimensions},'editable_meshes':editable_meshes,
 'triangles':triangles(),'glb_bytes':len(raw),'export_readback':readback,
 'part_hierarchy':'NS > booster > recovery; NS > capsule. BE-3PM stays with booster; all six windows stay with capsule.',
 'textures':'None. Geometry and original material parameters only; no photo pixels embedded.',
 'notes':'See README.md. Overall and local dimensions approximate, not engineering specifications.'}
assert readback['engines']==1 and readback['windows']==6 and readback['legs']==4 and readback['animations']==0
assert readback['triangles']<=250000 and len(raw)<=7_000_000
(OUT/'metrics.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
