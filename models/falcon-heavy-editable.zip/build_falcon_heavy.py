"""Falcon Heavy Block 5 / GOES-U 2024-06-25 educational exterior.

Run with Blender 4.5+:
  blender -b --factory-startup --python build_falcon_heavy.py -- --base PATH
The accepted F9 .blend is read-only input. Outputs are beside this script unless
--output is supplied. Metres/Z-up source; glTF metre/Y-up export. No animation.
Overall envelope is official; stations/hardware profiles are photo estimates.
"""
import bpy, math, json, sys, argparse, hashlib, struct
from pathlib import Path
from mathutils import Vector, Matrix

DEFAULT_BASE = str(Path(__file__).resolve().parent / 'input' / 'falcon9-block5.blend')
parser=argparse.ArgumentParser()
parser.add_argument('--base',default=DEFAULT_BASE)
parser.add_argument('--output',default=str(Path(__file__).resolve().parent))
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
OUT=Path(args.output).resolve(); OUT.mkdir(parents=True,exist_ok=True)
BASE=Path(args.base).resolve()
if BASE == OUT/'falcon-heavy.blend': raise ValueError('Input and output must differ')
bpy.ops.wm.open_mainfile(filepath=str(BASE))
bpy.context.scene.frame_set(0)
bpy.context.view_layer.update()
for obj in bpy.context.scene.objects:
    # Capture the accepted, physically stowed pose before discarding NLA data.
    basis=obj.matrix_basis.copy()
    obj.animation_data_clear()
    obj.matrix_basis=basis
    for key in ['animation_clip','animation_duration','animation_description']:
        if key in obj: del obj[key]
bpy.context.scene.frame_start=0; bpy.context.scene.frame_end=0
bpy.context.scene.unit_settings.system='METRIC'
bpy.context.scene.unit_settings.scale_length=1
root=bpy.data.objects['F9']; root.name='FH'
root['vehicle']='fh'
root['variant']='Falcon Heavy Block 5 · GOES-U · 2024-06-25'
root['configuration']='Recoverable side boosters; expended center core; standard fairing'
root['source_precision']='Official overall envelope; photo-estimated component stations and attachment profiles; not engineering geometry'
root['height_m']=70.0; root['core_diameter_m']=3.66; root['width_nominal_m']=12.2
root['pose']='Launch configuration: eight legs and eight grid fins stowed; no animation'
center=bpy.data.objects['booster']; center['core_role']='expended-center'
upper=bpy.data.objects['upper']; fairing=bpy.data.objects['fairing']
upper.location.z=47.0; fairing.location.z=56.8

def empty(name,parent=None,loc=(0,0,0),part=None):
    obj=bpy.data.objects.new(name,None); bpy.context.collection.objects.link(obj)
    obj.parent=parent; obj.location=loc
    if part: obj['part']=part
    return obj

def clone_tree(obj,parent,prefix):
    new=obj.copy(); bpy.context.collection.objects.link(new)
    new.name=prefix+obj.name; new.parent=parent
    new.matrix_parent_inverse=obj.matrix_parent_inverse.copy()
    new.matrix_basis=obj.matrix_basis.copy()
    new.animation_data_clear()
    for child in obj.children: clone_tree(child,new,prefix)
    return new

def delete_tree(obj):
    for child in list(obj.children): delete_tree(child)
    bpy.data.objects.remove(obj,do_unlink=True)

left=clone_tree(center,root,'L-'); left.name='side-left'; left['part']='side'; left['core_role']='recoverable-side'
right=clone_tree(center,root,'R-'); right.name='side-right'; right['part']='side'; right['core_role']='recoverable-side'
delete_tree(bpy.data.objects['recovery'])
for side in [left,right]:
    for obj in list(side.children):
        localname=obj.name[2:]
        if localname.startswith('falcon-interstage') or localname.startswith('interstage-panel-joint'):
            delete_tree(obj)
        elif localname.startswith('structural-interface'):
            if max(v.co.z for v in obj.data.vertices)>46: delete_tree(obj)
    rec=next(c for c in side.children if c.get('part')=='recovery')
    rec.name=side.name+'-recovery'; rec['pose']='stowed'
    for obj in rec.children_recursive:
        if obj.get('leg'): obj['pose']='stowed'
        if obj.get('gridfin'): obj['pose']='stowed'

def material(name,color,metal=.1,rough=.5):
    m=bpy.data.materials.new(name); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Metallic'].default_value=metal; p.inputs['Roughness'].default_value=rough
    return m

paint=bpy.data.materials['White exterior paint · substrate varies by part']
carbon=bpy.data.materials['Coated composite interstage']
edge=bpy.data.materials['Interfaces and nozzle lip']
seal=bpy.data.materials['Recessed joints']
mountpaint=material('FH attachment · warm light coated metal',(.66,.67,.64),.32,.49)
mountdark=material('FH attachment · dark interface',(.07,.078,.085),.32,.56)
bandmat=material('GOES-U upper-stage · visible grey circumferential band',(.21,.235,.26),.04,.71)
racewaymat=material('FH exterior raceway · dark coated channel',(.021,.026,.031),.08,.65)

def mesh(name,vertices,faces,mat,parent,smooth=True):
    data=bpy.data.meshes.new(name); data.from_pydata(vertices,[],faces); data.update()
    o=bpy.data.objects.new(name,data); bpy.context.collection.objects.link(o); o.parent=parent
    data.materials.append(mat)
    for p in data.polygons:p.use_smooth=smooth
    return o

def lathe(name,profile,mat,parent,n=96):
    verts=[(r*math.cos(math.tau*i/n),r*math.sin(math.tau*i/n),z) for r,z in profile for i in range(n+1)]
    faces=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=j*(n+1)+i; faces.append((a,a+1,a+n+2,a+n+1))
    return mesh(name,verts,faces,mat,parent)

def ring(name,r,z,minor,mat,parent,n=64):
    return lathe(name,[(r+minor*math.cos(i*math.tau/8),z+minor*math.sin(i*math.tau/8)) for i in range(9)],mat,parent,n)

def beam(name,a,b,width,depth,mat,parent):
    a,b=Vector(a),Vector(b)
    bpy.ops.mesh.primitive_cube_add(size=1)
    obj=bpy.context.object; obj.name=name; obj.parent=parent
    obj.location=(a+b)*.5; obj.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
    obj.scale=(width,depth,(b-a).length)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    obj.data.materials.append(mat)
    bevel=obj.modifiers.new('Small exterior corner radius','BEVEL'); bevel.width=.01; bevel.segments=2
    bpy.context.view_layer.objects.active=obj; bpy.ops.object.modifier_apply(modifier=bevel.name)
    return obj

def cylinder_between(name,a,b,r,mat,parent,n=24):
    a,b=Vector(a),Vector(b)
    o=lathe(name,[(0,0),(r,0),(r,(b-a).length),(0,(b-a).length)],mat,parent,n)
    o.location=a; o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
    return o

# GOES-U imagery shows the center interstage white. The broad dark grey band
# is higher, on the upper-stage exterior. No thermal-kit function is asserted.
interstage=bpy.data.objects['falcon-interstage']
interstage.data=interstage.data.copy(); interstage.data.materials.clear(); interstage.data.materials.append(paint)
for o in center.children:
    if o.name.startswith('interstage-panel-joint'):
        o.data=o.data.copy(); o.data.materials.clear(); o.data.materials.append(paint)
tank=bpy.data.objects['upper-stage-tank']; bpy.data.objects.remove(tank,do_unlink=True)
tank=lathe('upper-stage-tank',[(0,0),(1.83,0),(1.83,3.0),(1.83,8.28),(0,8.28)],paint,upper,128)
tank.data.materials.append(bandmat)
for p in tank.data.polygons:
    z=sum(tank.data.vertices[i].co.z for i in p.vertices)/len(p.vertices)
    if 0.001<z<2.999:p.material_index=1

# No F9 interstage or upper stage on either side booster: each receives a rounded
# GOES-U nosecone. Its shoulder and height are photographic estimates.
NOSE_BASE=42.5; NOSE_H=3.40
for side in [left,right]:
    nose=empty(side.name+'-nosecone',side)
    nose['detail_source']='GOES-U: SpaceX rollout side view and Ben Cooper pad photographs, June 2024'
    profile=[(1.83,NOSE_BASE)]
    for i in range(1,41):
        t=i/40
        profile.append((1.83*math.cos(t*math.pi/2),NOSE_BASE+NOSE_H*math.sin(t*math.pi/2)))
    lathe('Rounded side-booster nosecone',profile,paint,nose,128)
    ring('Nosecone lower circumferential seam',1.833,NOSE_BASE,.012,seal,nose)

# Photographs show black longitudinal exterior channels in this mission. Keep
# them shallow and restrained; do not label their concealed contents/functions.
for core,width in [(center,.080),(left,.080),(right,.145)]:
    channel=empty(core.name+'-front-exterior-channel',core)
    channel['detail_source']='Ben Cooper GOES-U pad front photo #27: visible exterior dark strip; width/offset photo-estimated'
    beam('Dark longitudinal channel',(0,-1.842,2.2),(0,-1.842,42.25),width,.055,racewaymat,channel)
    for z,h,w in [(40.9,1.03,.19),(37.9,.44,.14),(36.0,.54,.15)]:
        beam('Visible channel local cover',(0,-1.873,z-h/2),(0,-1.873,z+h/2),max(width,w),.065,racewaymat,channel)
    # Rounded dark top enclosure seen on the front of all three cores in NASA
    # image 0005. Follow the skin curvature so it does not float above the cone.
    padverts=[]; count=48
    for depth in [.012,.095]:
        for i in range(count):
            a=math.tau*i/count; x=.305*math.cos(a); z=42.40+1.12*math.sin(a)
            r=1.83
            if core!=center and z>NOSE_BASE:
                r=1.83*math.sqrt(max(0,1-((z-NOSE_BASE)/NOSE_H)**2))
            padverts.append((x,-math.sqrt(r*r-x*x)-depth,z))
    padfaces=[tuple(reversed(range(count))),tuple(range(count,count*2))]
    for i in range(count):padfaces.append((i,(i+1)%count,(i+1)%count+count,i+count))
    mesh('Rounded dark top channel enclosure',padverts,padfaces,racewaymat,channel)

# Fix core separation from the 12.2m overall span and the actual stowed geometry.
# It is a display-scale/photo estimate, not a SpaceX centerline separation spec.
bpy.context.view_layer.update()
pts=[]
inv=left.matrix_world.inverted()
for o in left.children_recursive:
    if o.type=='MESH':
        pts.extend(inv@o.matrix_world@Vector(c) for c in o.bound_box)
half=max(abs(p.x) for p in pts)
SEPARATION=6.10-half
left.location.x=-SEPARATION; right.location.x=SEPARATION
root['core_center_separation_photo_estimate_m']=round(SEPARATION,4)

# Small local attachment shoes and pin interfaces in the inter-core gap. These
# are an exterior envelope, not invented precision release machinery. Each
# span belongs wholly to its side booster; a center mating shoe stays on center.
# No transporter-erector arms, fairing cradle or tall cross-core gantry are added.
for side,sgn in [(left,-1),(right,1)]:
    attach=empty(side.name+'-attachments',side)
    attach['detail_source']='GOES-U photographs: visible inter-core connection envelopes only; exact attachment hardware dimensions unverified'
    attach['exploded_ownership']='Side half moves with side; central mating shoe stays with center'
    innerx=-sgn*1.73; center_face=-sgn*(SEPARATION-1.84)
    # Paired aft fittings between the first-stage bodies. Keep these below the
    # leg mounting zone; do not draw full-width beams through all three cores.
    for y in [-.64,.64]:
        beam('Aft local attachment shoe',(innerx,y,2.02),(innerx,y,2.82),.19,.32,mountpaint,attach)
        cylinder_between('Aft short inter-core pin',(innerx,y,2.40),(center_face,y,2.40),.12,mountdark,attach)
        beam('Aft upper short link',(innerx,y,2.78),(center_face,y,2.50),.105,.12,mountpaint,attach)
        beam('Center aft mating shoe',(sgn*1.79,y,2.10),(sgn*1.79,y,2.72),.12,.33,mountpaint,center)
    # The upper attachment envelope is deliberately compact, not the white
    # horizontal ground-support arm prominent across the front pad photo.
    for y in [-.45,.45]:
        beam('Upper local side interface',(innerx,y,41.68),(innerx,y,42.44),.18,.25,mountpaint,attach)
        cylinder_between('Upper short inter-core link',(innerx,y,42.17),(center_face,y,42.17),.085,mountpaint,attach)
        beam('Center upper mating shoe',(sgn*1.80,y,41.86),(sgn*1.80,y,42.42),.11,.28,mountpaint,center)

    # The thin white transverse member is present both in the official pad
    # close-up and in NOAA's off-tower launch image, unlike the large ground arms.
    # Split at the central mating shoe; each side-owned half moves out cleanly.
    end=-sgn*(SEPARATION-.27)
    beam('Flight upper transverse connection',(0,-1.985,43.28),(end,-1.985,43.28),.14,.15,mountpaint,attach)
    beam('Flight upper short diagonal',(innerx,-1.83,43.20),(center_face,-1.83,41.88),.12,.115,mountpaint,attach)
    beam('Center transverse connection saddle',(sgn*.30,-1.95,43.02),(sgn*.30,-1.95,43.48),.23,.16,mountpaint,center)

# The dark nose-tip appearance in the hangar rollout image is not confirmed as
# a permanent flight surface; NOAA's daylight liftoff image looks white. Omit it.

# GOES-U close-up 0005 has a visibly rounded main-fairing nose. Refine only the
# last metre of the accepted F9 curve in this FH copy. Join with matching radius
# and slope; sqrt(delta) gives a rounded end tangent instead of a pointed cusp.
# This is a photographic silhouette approximation, not a fairing engineering law.
bpy.context.view_layer.update()
join_z=12.2; tip_z=13.2
phase=(join_z-6.65)/6.55*math.pi/2
join_r=2.6*math.cos(phase)**.82
beta=.82*(math.pi/(2*6.55))*math.tan(phase)-.5
for half in fairing.children:
    for obj in half.children_recursive:
        if obj.type!='MESH':continue
        obj.data=obj.data.copy()
        to_fairing=fairing.matrix_world.inverted()@obj.matrix_world
        from_fairing=to_fairing.inverted()
        for v in obj.data.vertices:
            p=to_fairing@v.co
            if join_z<p.z<tip_z-1e-7:
                delta=tip_z-p.z
                old_r=2.6*math.cos((p.z-6.65)/6.55*math.pi/2)**.82
                new_r=join_r*math.sqrt(delta)*(1-beta+beta*delta)
                p.x*=new_r/old_r; p.y*=new_r/old_r
                v.co=from_fairing@p
        obj.data.update()
root['fairing_nose_photo_refinement']='Final 1m rounded to GOES-U NASA 0005 silhouette; same total height/diameter and split halves; original F9 unchanged'

for obj in [root,*root.children_recursive]:
    if obj.get('engine'): obj['engine_family']='Merlin vacuum' if obj.parent==upper else 'Merlin 1D sea level'
    if obj.type=='MESH': obj.hide_render=False
bpy.context.view_layer.update()

def bounds():
    ps=[]
    for o in root.children_recursive:
        if o.type=='MESH': ps.extend(o.matrix_world@Vector(c) for c in o.bound_box)
    lo=[min(p[i] for p in ps) for i in range(3)]; hi=[max(p[i] for p in ps) for i in range(3)]
    return {'min':lo,'max':hi,'size':[hi[i]-lo[i] for i in range(3)]}

def tri_count(obs):
    return sum(sum(max(0,len(p.vertices)-2) for p in o.data.polygons) for o in obs if o.type=='MESH')

editable_meshes=sum(o.type=='MESH' for o in root.children_recursive)
editable_triangles=tri_count(root.children_recursive)
source_bounds=bounds()
assert len([o for o in root.children_recursive if o.get('engine')])==28
assert len([o for o in root.children_recursive if o.get('gridfin')])==8
assert len([o for o in root.children_recursive if o.get('leg')])==8
assert not any(o.get('gridfin') or o.get('leg') or o.get('part')=='recovery' for o in center.children_recursive)
assert abs(source_bounds['size'][0]-12.2)<.025
assert abs(source_bounds['size'][2]-70)<.05
bpy.context.scene['asset_notes']='Read NOTES.md. All local profile dimensions are visual estimates. Source .blend remains unbatched; original F9 is never overwritten.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'falcon-heavy.blend'))

# Web batching: preserve part roots and all engine/fin/leg marker nodes. The
# editable .blend above retains the exact component hierarchy and materials.
# Only static export meshes are collected into each nearest semantic part.
# Place the parallel cores temporarily at a common origin while batching. This
# avoids translation roundoff creating three copies of identical engine buffers.
side_locations=[left.location.copy(),right.location.copy()]
left.location.x=0; right.location.x=0; bpy.context.view_layer.update()
groups={}
for obj in list(root.children_recursive):
    if obj.type!='MESH': continue
    parent=obj.parent
    while parent!=root and 'part' not in parent: parent=parent.parent
    groups.setdefault((parent,tuple(m.name for m in obj.data.materials)),[]).append(obj)

for (parent,_),objects in groups.items():
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.data=obj.data.copy(); obj.select_set(True)
    bpy.context.view_layer.objects.active=objects[0]
    if len(objects)>1: bpy.ops.object.join()
    obj=bpy.context.object
    transform=parent.matrix_world.inverted()@obj.matrix_world
    obj.data.transform(transform)
    obj.parent=parent; obj.matrix_parent_inverse=Matrix.Identity(4); obj.matrix_basis=Matrix.Identity(4)
    obj.name=parent.name+' · '+obj.data.materials[0].name
    obj['static_batch']=True

left.location=side_locations[0]; right.location=side_locations[1]
bpy.context.view_layer.update()

# Preserve the original flag groups as position/reference markers. Renderer
# meshes are under the core/recovery roots so batch count stays mobile-friendly.
for obj in list(root.children_recursive):
    if obj.type=='EMPTY' and (obj.get('engine') or obj.get('gridfin') or obj.get('leg')):
        obj['static_geometry_batched_to_part']=True
for obj in list(root.children_recursive)[::-1]:
    if obj.type=='EMPTY' and not obj.children and not any(k in obj for k in ['part','engine','gridfin','leg']):
        bpy.data.objects.remove(obj,do_unlink=True)

# Reuse truly identical material batches across the three cores / two recoveries.
# Quantizing at 1 micron neutralizes floating point parent-translation noise.
cache={}; reused=0
for obj in root.children_recursive:
    if obj.type!='MESH': continue
    h=hashlib.sha256()
    h.update('|'.join(m.name for m in obj.data.materials).encode())
    for v in obj.data.vertices:h.update(struct.pack('<3q',*(round(c*1e6) for c in v.co)))
    for p in obj.data.polygons:
        h.update(struct.pack('<2I',len(p.vertices),p.material_index))
        h.update(struct.pack('<'+'I'*len(p.vertices),*p.vertices))
    for layer in obj.data.uv_layers:
        for uv in layer.data:h.update(struct.pack('<2q',*(round(c*1e6) for c in uv.uv)))
    key=h.digest()
    if key in cache: obj.data=cache[key]; reused+=1
    else:cache[key]=obj.data

bpy.ops.object.select_all(action='DESELECT')
for obj in [root,*root.children_recursive]: obj.select_set(True)
bpy.context.view_layer.update()
bpy.ops.export_scene.gltf(filepath=str(OUT/'falcon-heavy.glb'),export_format='GLB',use_selection=True,
    export_extras=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False)
raw=(OUT/'falcon-heavy.glb').read_bytes()
gltf=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]])
gltf_meshes=gltf['meshes']; gltf_accessors=gltf['accessors']
gltf_report={
    'gltf_meshes':len(gltf_meshes),
    'gltf_unique_primitives':sum(len(m['primitives']) for m in gltf_meshes),
    'gltf_render_mesh_instances':sum(len(gltf_meshes[n['mesh']]['primitives']) for n in gltf['nodes'] if 'mesh' in n),
    'gltf_instanced_triangles':sum(sum(gltf_accessors[p['indices']]['count']//3 for p in gltf_meshes[n['mesh']]['primitives']) for n in gltf['nodes'] if 'mesh' in n),
    'gltf_nodes':len(gltf['nodes']),
    'gltf_engine_markers':sum(bool(n.get('extras',{}).get('engine')) for n in gltf['nodes']),
    'gltf_gridfin_markers':sum(bool(n.get('extras',{}).get('gridfin')) for n in gltf['nodes']),
    'gltf_leg_markers':sum(bool(n.get('extras',{}).get('leg')) for n in gltf['nodes']),
    'gltf_animations':len(gltf.get('animations',[]))}
assert gltf_report['gltf_engine_markers']==28
assert gltf_report['gltf_gridfin_markers']==8
assert gltf_report['gltf_leg_markers']==8
assert gltf_report['gltf_animations']==0
report={
    'variant':root['variant'],'source_blend':str(BASE),'height_nominal_m':70,'core_diameter_m':3.66,
    'fairing_diameter_m':5.2,'width_nominal_m':12.2,
    'core_center_separation_photo_estimate_m':SEPARATION,
    'bounds_z_up_m':source_bounds,'editable_mesh_objects':editable_meshes,'triangles':editable_triangles,
    'export_mesh_objects':sum(o.type=='MESH' for o in root.children_recursive),
    'export_unique_mesh_datablocks':len(cache),'identical_material_batches_reused':reused,
    'glb_bytes':(OUT/'falcon-heavy.glb').stat().st_size,
    'engines':{'sea_level':27,'vacuum':1},'stowed_grid_fins':8,'stowed_legs':8,
    'center_recovery_hardware':False,'animations':0,
    'semantic_markers':'engine/gridfin/leg flags retained; static drawing meshes batched under part roots; editable source retains full per-component parents',
    'personally_viewed_reference_files':['goes-u-27-pad-night.jpg','goes-u-40.jpg','goes-u-45.jpg','spacex-goes-u-rollout-front.jpg','spacex-goes-u-rollout-side.jpg','nasa-goes-u-0005-original.jpg','nasa-goes-u-0010-original.jpg','noaa-goes-u-launch-original.jpg'],
    'texture_policy':'Only inherited original procedural 256px F9 surface maps. No reference photo pixels embedded.',
    'precision':'Envelope official; component stations, core separation, nosecone curves and attachment shapes are visual approximations, not engineering data.',
    'fairing_refinement':'FH copy only: final 1m of main-fairing nose rounded from accepted F9 profile to NASA GOES-U 0005 silhouette; same height, width, split semantics.'}
report['export_readback']=gltf_report
(OUT/'asset-stats.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
