"""Photo-led Falcon 9 landing legs, Blender metres/Z up.

Visual approximation from supplied photographs 1, 2 and especially 5; not
engineering drawings. build_landing_legs(parent, deployed=False) is independent
of the main builder, creates no cameras/lights, and returns one semantic root.
The two poses have the same shell geometry and different telescopic extension.
Exterior is dark; the bounded pale panel exists only on the concave inner face.
"""
import math
import bpy
from mathutils import Vector, Matrix

LENGTH = 7.58
HINGE_R = 1.88
HINGE_Z = 1.8
DEPLOY_ANGLE = -math.acos(-3.20 / LENGTH)
ANIMATION_NAME = 'landing-legs'
ANIMATION_FPS = 30
ANIMATION_START = 0
ANIMATION_END = 96
STRUT_ANCHOR = Vector((0, 1.935, 8.50))
STRUT_TIP_T = .886


def _empty(name, parent):
    obj = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(obj)
    obj.parent = parent
    return obj


def _material(name, color, metallic, roughness):
    name = 'Landing legs | ' + name
    existing = bpy.data.materials.get(name)
    if existing:
        return existing
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.diffuse_color = (*color, 1)
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (*color, 1)
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = roughness
    return mat


def _mesh(name, vertices, faces, material, parent, smooth=False):
    data = bpy.data.meshes.new(name)
    data.from_pydata(vertices, [], faces)
    data.update()
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.parent = parent
    data.materials.append(material)
    for poly in data.polygons:
        poly.use_smooth = smooth
    return obj


def _cylinder(name, a, b, radius, material, parent, sides=20):
    """Closed, genuinely cylindrical member between exact endpoints."""
    a, b = Vector(a), Vector(b)
    direction = (b - a).normalized()
    reference = Vector((0, 0, 1)) if abs(direction.z) < .90 else Vector((1, 0, 0))
    u = direction.cross(reference).normalized()
    v = direction.cross(u).normalized()
    vertices = [tuple(p + radius*(math.cos(i*2*math.pi/sides)*u +
                                 math.sin(i*2*math.pi/sides)*v))
                for p in (a, b) for i in range(sides)]
    faces = [(i, (i+1) % sides, (i+1) % sides+sides, i+sides)
             for i in range(sides)]
    faces += [tuple(reversed(range(sides))), tuple(range(sides, 2*sides))]
    obj = _mesh(name, vertices, faces, material, parent, smooth=True)
    for poly in obj.data.polygons[-2:]:
        poly.use_smooth = False
    return obj


def _box(name, center, dimensions, material, parent, bevel=.015):
    x, y, z = (v/2 for v in dimensions)
    cx, cy, cz = center
    vertices = [(cx+sx*x, cy+sy*y, cz+sz*z)
                for sz in (-1, 1) for sy in (-1, 1) for sx in (-1, 1)]
    faces = [(0, 2, 3, 1), (4, 5, 7, 6), (0, 1, 5, 4),
             (2, 6, 7, 3), (0, 4, 6, 2), (1, 3, 7, 5)]
    obj = _mesh(name, vertices, faces, material, parent)
    if bevel:
        modifier = obj.modifiers.new('Rounded exposed hardware edges', 'BEVEL')
        modifier.width = bevel
        modifier.segments = 2
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(modifier=modifier.name)
    return obj


def _pad(name, z, width, height, material, parent, xcenter=0, radius=1.852):
    """Thin chamfered mounting pad following the cylindrical skin, not a block."""
    vertices, faces = [], []
    rows, cols = 4, 12
    for depth in (0, .028):
        for row, t in enumerate((0, .09, .91, 1)):
            half = width*.5*(.83 if row in (0, 3) else 1)
            for i in range(cols+1):
                x = xcenter+half*(-1+2*i/cols)
                vertices.append((x, math.sqrt(radius*radius-x*x)+depth,
                                 z+height*(t-.5)))
    stride = cols+1
    count = rows*stride
    for side in range(2):
        for row in range(rows-1):
            for i in range(cols):
                a = side*count+row*stride+i
                face = (a, a+1, a+stride+1, a+stride)
                faces.append(face if side else tuple(reversed(face)))
    outline = list(range(cols+1))+[r*stride+cols for r in range(1,rows)]
    outline += list(range(count-2, count-stride-1, -1))
    outline += [r*stride for r in range(rows-2,0,-1)]
    for a,b in zip(outline, outline[1:]+outline[:1]):
        faces.append((a,b,b+count,a+count))
    return _mesh(name, vertices, faces, material, parent, True)


def _link(name, a, b, ra, rb, thickness, material, parent, slotted=False):
    """Paired exterior cheek geometry; outline and slot proportions estimated."""
    a,b = Vector(a), Vector(b)
    axis = (b-a).normalized()
    cross = Vector((1,0,0)).cross(axis)
    def outline(ca, cb, r1, r2):
        return ([ca+r1*(math.cos(i*math.pi/8)*cross-math.sin(i*math.pi/8)*axis)
                 for i in range(9)] +
                [cb+r2*(-math.cos(i*math.pi/8)*cross+math.sin(i*math.pi/8)*axis)
                 for i in range(9)])
    outer = outline(a,b,ra,rb)
    loops = [outer]
    if slotted:
        loops.append(outline(a+axis*ra*.90,b-axis*rb*.90,ra*.30,rb*.30))
    vertices = [tuple(p+Vector((side*thickness*.5,0,0)))
                for side in (-1,1) for loop in loops for p in loop]
    n=len(outer); step=n*len(loops); faces=[]
    for i in range(n):
        j=(i+1)%n
        faces.append((i,j,j+step,i+step))
        if slotted:
            faces += [(i+n,i+n+step,j+n+step,j+n),
                      (i,i+n,j+n,j),(i+step,j+step,j+n+step,i+n+step)]
    if not slotted:
        faces += [tuple(reversed(range(n))),tuple(range(n,2*n))]
    obj=_mesh(name,vertices,faces,material,parent)
    bevel=obj.modifiers.new('Small edge break on shaped cheek','BEVEL')
    bevel.width=.005; bevel.segments=2
    bpy.context.view_layer.objects.active=obj
    bpy.ops.object.modifier_apply(modifier=bevel.name)
    return obj


def _boss(name, x, y, z, radius, material, boltmat, parent):
    # One visible concentric boss and hexagonal head, not an invented bolt array.
    side = 1 if x >= 0 else -1
    _cylinder(name+' circular bearing face', (x-.018,y,z),(x+.018,y,z),
              radius,material,parent,24)
    _cylinder(name+' recessed pin end', (x+side*.020,y,z),(x+side*.030,y,z),
              radius*.53,boltmat,parent,16)
    _cylinder(name+' hexagonal keeper', (x+side*.030,y,z),(x+side*.042,y,z),
              radius*.27,material,parent,6)


def _ribbed_collar(parent, radius, warm, dark):
    """Exterior triangular ribs observed in the B1048 photograph.

    Child of an unscaled collar node: never inherits telescopic axial scale.
    Rib count and dimensions are visual approximations, not manufacturing data.
    """
    parts=[]
    for i in range(18):
        theta=i*2*math.pi/18
        radial=Vector((math.cos(theta),math.sin(theta),0))
        tangent=Vector((-math.sin(theta),math.cos(theta),0))
        points=[radial*r+Vector((0,0,z)) for r,z in
                ((radius,-.037),(radius+.034,-.030),(radius+.010,.034),(radius,.037))]
        vertices=[tuple(p+tangent*side*.006) for side in (-1,1) for p in points]
        parts.append(_mesh('upper strut collar radial rib',vertices,
              [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],
              warm,parent))
    for z in (-.043,.043):
        parts.append(_cylinder('upper strut collar edge bead',(0,0,z-.006),(0,0,z+.006),
                  radius+.012,warm,parent,36))
    # Keep one rigid animated mesh per collar, avoiding a draw call per rib.
    bpy.ops.object.select_all(action='DESELECT')
    for obj in [parent,*parts]: obj.select_set(True)
    bpy.context.view_layer.objects.active=parent
    bpy.ops.object.join()


def _body_hardware(leg, shell, k, dark, metal, alloy, warm, padmat):
    """Reference-led visible mounting surfaces; concealed mechanics omitted."""
    prefix='leg-%d-'%k
    _pad(prefix+'upper curved body mounting pad',8.53,.64,.94,padmat,leg)
    for x in (-.225,.225):
        # Shaped paired links replace the earlier rectangular saddle/clevis.
        _link(prefix+'upper warm mounting cheek',(x,1.864,8.82),
              (x,1.935,8.50),.083,.105,.045,warm,leg)
        _link(prefix+'lower dark mounting cheek',(x,1.86,8.25),
              (x,1.935,8.50),.070,.088,.045,metal,leg,True)
        _boss(prefix+'upper pivot boss',x,1.935,8.50,.104,warm,metal,leg)
        for z in (8.82,8.25):
            _boss(prefix+'body link pin',x,1.864,z,.051,alloy,metal,leg)
    for x in (-.245,.245):
        for z in (8.17,8.90):
            y=math.sqrt(1.852**2-x*x)+.029
            _cylinder(prefix+'saddle visible fastener',(x,y,z),(x,y+.022,z),
                      .020,alloy,leg,6)
    for x in (-.385,.385):
        _pad(prefix+'lower root curved pad',1.83,.245,.54,metal,leg,xcenter=x,radius=1.834)
        _link(prefix+'lower skirt shaped hinge cheek',(x,1.82,1.62),
              (x,HINGE_R,HINGE_Z),.076,.112,.082,dark,leg)
        _boss(prefix+'lower hinge outer boss',x,HINGE_R,HINGE_Z,.122,metal,alloy,leg)
        for z in (1.61,2.045):
            y=math.sqrt(1.834**2-x*x)+.029
            _cylinder(prefix+'root pad visible fastener',(x,y,z),(x,y+.025,z),
                      .024,alloy,leg,6)
    _cylinder(prefix+'lower tangential hinge pin',(-.43,HINGE_R,HINGE_Z),
              (.43,HINGE_R,HINGE_Z),.102,metal,leg,24)
    for x in (-.25,.25):
        _link(prefix+'shell root shaped ear',(x,0,0),(x,.14,.30),
              .103,.077,.095,dark,shell)
        _boss(prefix+'moving shell root pin',x,0,0,.092,metal,alloy,shell)


# Sparse silhouette controls, sampled smoothly. Broad near the hinge, tapering
# throughout its length, with a small rounded nose instead of a triangular spike.
_WIDTHS = [(0, .31), (.05, .57), (.13, .655), (.28, .602),
           (.49, .478), (.70, .326), (.86, .187), (.94, .111),
           (.975, .071), (.994, .034), (1, .008)]


def _width(t):
    for i in range(len(_WIDTHS)-1):
        t0, w0 = _WIDTHS[i]
        t1, w1 = _WIDTHS[i+1]
        if t <= t1:
            m0 = ((w1-w0)/(t1-t0) if i == 0 else
                  (w1-_WIDTHS[i-1][1])/(t1-_WIDTHS[i-1][0]))
            m1 = ((w1-w0)/(t1-t0) if i+2 == len(_WIDTHS) else
                  (_WIDTHS[i+2][1]-w0)/(_WIDTHS[i+2][0]-t0))
            q = (t-t0)/(t1-t0)
            return max(.008, (2*q**3-3*q*q+1)*w0 + (q**3-2*q*q+q)*(t1-t0)*m0
                       + (-2*q**3+3*q*q)*w1 + (q**3-q*q)*(t1-t0)*m1)
    return .008


def _surface(t, x, inside=False):
    width = _width(t)
    q = min(1, abs(x/width))
    # Convex dark exterior and recessed inside; perimeter has real wall thickness.
    y = .115 + .108*(1-q*q) * (.78+.22*math.sin(math.pi*t))
    return (x, y-(.048 if inside else 0), LENGTH*t)


def _shell(parent, dark, pale, ribmat):
    rows, columns = 60, 12
    vertices = []
    for inside in (False, True):
        for i in range(rows+1):
            t = i/rows
            width = _width(t)
            vertices += [_surface(t, width*(-1+2*j/columns), inside)
                         for j in range(columns+1)]
    stride = columns+1
    count = (rows+1)*stride
    faces = []
    for i in range(rows):
        for j in range(columns):
            a = i*stride+j
            faces.append((a, a+stride, a+stride+1, a+1))
            a += count
            faces.append((a, a+1, a+stride+1, a+stride))
    for i in range(rows):
        for j in (0, columns):
            a, b = i*stride+j, (i+1)*stride+j
            faces.append((a, b, b+count, a+count))
    for i in (0, rows):
        for j in range(columns):
            a = i*stride+j
            faces.append((a, a+count, a+count+1, a+1))
    _mesh('rounded dark composite petal', vertices, faces, dark, parent, True)

    # An inset has its own bounded outline and does not wrap onto the outer face.
    vertices, faces = [], []
    panel_rows = 52
    for i in range(panel_rows+1):
        t = .055 + (.959-.055)*i/panel_rows
        width = max(.014, _width(t)-.053)
        # Rounded panel ends leave a continuous, thicker black border.
        taper = min(1, ((i+.4)/2.7)**.5, ((panel_rows-i+.4)/2.7)**.5)
        width *= taper
        for j in range(columns+1):
            x = width*(-1+2*j/columns)
            px, py, pz = _surface(t, x, True)
            vertices.append((px, py-.0025, pz))
    for i in range(panel_rows):
        for j in range(columns):
            a = i*stride+j
            faces.append((a, a+1, a+stride+1, a+stride))
    _mesh('bounded pale inner shell panel', vertices, faces, pale, parent, True)

    # Six shallow transverse reinforcement ribs, informed by photo 5. They
    # follow the concave surface; no invented rivet arrays or hydraulic plumbing.
    for index, t in enumerate((.135, .27, .425, .59, .75, .865)):
        span = _width(t)-.061
        vertices, faces = [], []
        for row in range(2):
            tt = t + (-1 if row == 0 else 1)*.0018
            for j in range(9):
                x = span*(-1+2*j/8)
                px, py, pz = _surface(tt, x, True)
                vertices.append((px, py-.017, pz))
        faces = [(j, j+1, j+10, j+9) for j in range(8)]
        _mesh('inner transverse rib %d' % (index+1), vertices, faces, ribmat, parent, True)


def _pose(point, deployed=False, angle=None):
    x, y, z = point
    angle = (DEPLOY_ANGLE if deployed else 0) if angle is None else angle
    return Vector((x, HINGE_R+y*math.cos(angle)-z*math.sin(angle),
                   HINGE_Z+y*math.sin(angle)+z*math.cos(angle)))


def _animate_object(obj):
    """One common NLA track name exports as one clip across the four legs."""
    data = obj.animation_data
    action = data.action
    action.name = ANIMATION_NAME + ' | ' + obj.name
    for curve in action.fcurves:
        for point in curve.keyframe_points:
            point.interpolation = 'LINEAR'
    track = data.nla_tracks.new()
    track.name = ANIMATION_NAME
    strip = track.strips.new(ANIMATION_NAME, ANIMATION_START, action)
    strip.name = ANIMATION_NAME
    strip.extrapolation = 'HOLD'
    data.action = None


def _strut(parent, shell, leg_index, dark, metal, alloy, warm):
    """Four overlapping cylinders, with exact articulated end connections.

    V2's folded rod endpoints almost coincide. Its photographic exterior does
    not supply a physically resolvable internal nested-tube storage length.
    We retain those endpoints and the deployed four-stage dimensions, and
    animate axial stroke by object TRS only. This is a linkage illustration,
    not an engineering claim about the actual telescoping mechanism.
    """
    prefix = 'leg-%d-' % leg_index
    tip = Vector(_surface(STRUT_TIP_T, 0, True))
    tip.y -= .125
    stages = ((0, .37, .118, dark), (.35, .69, .095, dark),
              (.67, .93, .075, metal), (.91, 1, .055, alloy))
    moving = []
    members = []
    for index, (a, b, radius, material) in enumerate(stages):
        obj = _cylinder(prefix+'strut-stage-'+str(index+1),
                        (0, 0, -.5), (0, 0, .5), radius, material, parent, 24)
        obj.rotation_mode = 'QUATERNION'
        obj['rig_role'] = 'telescopic-stage'
        obj['stage'] = index+1
        obj['batch_boundary'] = True
        moving.append(obj)
        collar = None
        if index < len(stages)-1:
            collar = _cylinder(prefix+'strut-collar-'+str(index+1),
                               (0, 0, -.036), (0, 0, .036),
                               radius+.020, warm if index == 0 else metal, parent, 24)
            collar.rotation_mode = 'QUATERNION'
            collar['rig_role'] = 'locking-collar'
            collar['batch_boundary'] = True
            moving.append(collar)
            if index == 0:
                _ribbed_collar(collar, radius+.020, warm, dark)
        members.append((obj, collar, a, b))

    _cylinder(prefix+'upper-strut-pivot', STRUT_ANCHOR+Vector((-.245,0,0)),
              STRUT_ANCHOR+Vector((.245,0,0)), .105, metal, parent, 24)
    fitting = _empty(prefix+'upper-strut-rigid-end-fitting',parent)
    fitting.rotation_mode='QUATERNION'
    fitting['rig_role']='rigid-end-fitting'
    fitting['batch_boundary']=True
    _cylinder(prefix+'upper fitting knuckle',(-.135,0,0),(.135,0,0),
              .126,dark,fitting,24)
    _cylinder(prefix+'upper fitting neck',(0,0,0),(0,0,.13),
              .121,dark,fitting,24)
    _cylinder(prefix+'upper fitting shoulder',(0,0,.105),(0,0,.132),
              .129,metal,fitting,24)
    moving.append(fitting)
    # The lower joint, clevis and shell rotate as one rigid assembly.
    _cylinder(prefix+'shell-strut-pivot', tip+Vector((-.155,0,0)),
              tip+Vector((.155,0,0)), .078, metal, shell, 24)
    contact = Vector(_surface(STRUT_TIP_T, 0, True))
    for x in (-.10, .10):
        delta = Vector((x,0,0))
        _link(prefix+'tip-shaped-clevis-cheek',tip+delta,contact+delta,
              .064,.052,.033,dark,shell)
        _boss(prefix+'tip-clevis-pin',x,tip.y,tip.z,.066,metal,alloy,shell)

    for frame in range(ANIMATION_START, ANIMATION_END+1):
        progress = (frame-ANIMATION_START)/(ANIMATION_END-ANIMATION_START)
        angle = DEPLOY_ANGLE*progress
        end = _pose(tip, angle=angle)
        delta = end-STRUT_ANCHOR
        direction = delta.normalized()
        rotation = delta.to_track_quat('Z', 'Y')
        fitting.location=STRUT_ANCHOR
        fitting.rotation_quaternion=rotation
        for path in ('location','rotation_quaternion'):
            fitting.keyframe_insert(data_path=path,frame=frame,group='Rigid upper end fitting')
        for obj, collar, a, b in members:
            obj.location = STRUT_ANCHOR+delta*((a+b)/2)
            obj.rotation_quaternion = rotation
            obj.scale = (1, 1, delta.length*(b-a))
            for path in ('location', 'rotation_quaternion', 'scale'):
                obj.keyframe_insert(data_path=path, frame=frame,
                                    group='Telescopic stroke')
            if collar:
                collar.location = STRUT_ANCHOR+delta*b
                collar.rotation_quaternion = rotation
                for path in ('location', 'rotation_quaternion'):
                    collar.keyframe_insert(data_path=path, frame=frame,
                                           group='Locking collar')
    for obj in moving:
        _animate_object(obj)


def build_landing_legs(parent, deployed=False):
    """Return a single animated recovery root with four leg=true extras.

    Approximate shell length 7.58m, hinge radius1.88m at z1.8m. Four leg axes
    are pi/4+k*pi/2. Deployed foot sole is exactly z=-1.60m, farthest radius
    approximately8.73m. Stowed maximum radius is under2.25m, top under9.5m.
    The 3.2-second landing-legs clip uses linear angular progress, 30 fps.
    Only explicit rod axial scales and rigid-node TRS are animated. Initial
    file pose is stowed; no duplicate deployed geometry and no root lift.
    """
    dark = _material('dark composite exterior', (.017,.020,.024), .04, .58)
    pale = _material('pale inner structural panel', (.72,.73,.72), .03, .53)
    ribmat = _material('inner panel ribs', (.41,.43,.43), .20, .49)
    metal = _material('graphite collars and pivots', (.085,.094,.104), .62, .39)
    alloy = _material('exposed satin strut', (.29,.32,.35), .74, .32)
    warm = _material('muted warm exterior hardware finish', (.30,.265,.135), .52, .47)
    padmat = _material('body mounting pad finish', (.46,.48,.46), .22, .49)
    root = _empty('legs-stowed', parent)
    root['part'] = 'recovery'
    root['pose'] = 'stowed'
    root['animation_clip'] = ANIMATION_NAME
    root['animation_duration'] = 3.2
    root['animation_description'] = 'Synchronous educational deployment, not actual flight timing'
    root['source_precision'] = 'Photo-estimated shell and linkage; no engineering claim'
    root['hardware_reference'] = 'B1048 close-up, Pauline Acalin / Teslarati; external geometry only'
    root['hardware_precision'] = 'Curved pads, paired cheeks, bosses and ribbed collar photo-led; dimensions, rib and fastener counts approximate; no alloy or fluid-function identification'
    for k in range(4):
        leg = _empty('stowed-leg-'+str(k+1), root)
        leg.rotation_euler.z = math.pi/4+k*math.pi/2-math.pi/2
        leg['leg'] = True
        shell = _empty('leg-%d-shell-hinge' % (k+1), leg)
        shell['rig_role'] = 'rigid-shell-hinge'
        shell['batch_boundary'] = True
        shell.location = (0, HINGE_R, HINGE_Z)
        shell.rotation_mode = 'QUATERNION'
        _shell(shell, dark, pale, ribmat)

        _body_hardware(leg,shell,k+1,dark,metal,alloy,warm,padmat)
        _strut(leg, shell, k+1, dark, metal, alloy, warm)

        # Keep v2's landed shoe, now one rigid piece in both poses. Construct
        # its exact deployed geometry then transform it into the shell frame.
        foot_center = _pose(_surface(.982,0,False), True)
        shoe = _box('leg-%d-ground-contact-shoe' % (k+1),
                    (0,foot_center.y,-1.565), (.20,.37,.07), dark, shell, .030)
        inverse_deployed = (Matrix.Translation((0, HINGE_R, HINGE_Z)) @
                            Matrix.Rotation(DEPLOY_ANGLE, 4, 'X')).inverted()
        shoe.data.transform(inverse_deployed)
        for frame in range(ANIMATION_START, ANIMATION_END+1):
            progress = (frame-ANIMATION_START)/(ANIMATION_END-ANIMATION_START)
            shell.rotation_quaternion = Matrix.Rotation(DEPLOY_ANGLE*progress, 4, 'X').to_quaternion()
            shell.keyframe_insert(data_path='rotation_quaternion', frame=frame,
                                 group='Rigid shell deployment')
        _animate_object(shell)
    scene = bpy.context.scene
    scene.render.fps = ANIMATION_FPS
    scene.frame_start, scene.frame_end = ANIMATION_START, ANIMATION_END
    scene.frame_set(ANIMATION_END if deployed else ANIMATION_START)
    return root
