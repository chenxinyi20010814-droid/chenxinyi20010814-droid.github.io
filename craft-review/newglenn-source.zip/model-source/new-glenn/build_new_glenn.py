"""New Glenn 7x2, NG-1 prelaunch exterior, educational photo reconstruction.
Run: Blender -b --factory-startup --python build_new_glenn.py
Source is metre / Z-up; glTF exporter produces metre / Y-up. No logos.
All station measurements except official total height and core diameter are
photographic estimates, not Blue Origin engineering dimensions.
"""
import bpy, math, json, struct, random
from pathlib import Path
from mathutils import Vector
OUT = Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
random.seed(7)

def material(name,c,metal=0,rough=.5):
    m=bpy.data.materials.new(name); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*c,1)
    p.inputs['Metallic'].default_value=metal; p.inputs['Roughness'].default_value=rough
    m.diffuse_color=(*c,1)
    return m
white=material('NG warm white exterior',(.79,.805,.80),.16,.4)
white2=material('NG white interface trim',(.66,.695,.695),.28,.42)
ivory=material('Fairing inner liner',(.40,.38,.30),.03,.83)
silver=material('Visible hardware light metal',(.43,.48,.49),.76,.34)
blue=material('NG lower body blue paint',(.011,.055,.31),.15,.32)
edge=material('Thermal panel edge strips',(.35,.33,.24),.48,.55)
seam=material('Fine recessed seams',(.10,.12,.12),.18,.74)
dark=material('Engine bay and covered machinery',(.018,.026,.032),.40,.51)
bellmat=material('BE-4 nozzle nickel alloy exterior',(.28,.31,.32),.83,.32)
bellinner=material('Nozzle interior dark metal',(.047,.052,.055),.50,.62)
nozzleLip=material('Nozzle lip light metal',(.52,.56,.57),.89,.26)
thermal=[]
for i,c in enumerate([(.24,.177,.088),(.28,.205,.102),(.22,.167,.089),(.305,.228,.122),(.25,.194,.108),(.20,.162,.093),(.29,.216,.127),(.235,.19,.105)]):
    thermal.append(material('NG thermal exterior panel %02d'%i,tuple(v*.54 for v in c),.36,.69))

def empty(name,parent=None,part=None,loc=(0,0,0)):
    o=bpy.data.objects.new(name,None); bpy.context.collection.objects.link(o); o.parent=parent; o.location=loc
    if part:o['part']=part
    return o
root=empty('NG'); root['vehicle']='newglenn'; root['variant']='refined'
root['configuration']='New Glenn 7x2, NG-1 prelaunch exterior; no mission logos'
root['source_precision']='Official total height and core diameter; photo-estimated exterior details, not engineering CAD'
root['height_m']=98.0; root['body_diameter_m']=7.0; root['pose']='assembled launch, landing legs stowed'
booster=empty('booster',root,'booster')
recovery=empty('recovery',booster,'recovery')
upper=empty('upper',root,'upper',(0,0,62.0))
fairing=empty('fairing',root,'fairing',(0,0,79.8))
left=empty('fairing-left',fairing,'fairing'); left['split_sign']=-1
right=empty('fairing-right',fairing,'fairing'); right['split_sign']=1
booster['be4_count']=7; recovery['leg_count']=6; recovery['control_fin_count']=4; recovery['strake_count']=2
upper['be3u_count']=2; upper['engine_concealed_in_assembled_pose']=True

def partof(o):
    while o:
        if o.get('part'):return o['part']
        o=o.parent
    raise RuntimeError('mesh without semantic part')
def mesh(name,verts,faces,mat,parent,smooth=True):
    d=bpy.data.meshes.new(name); d.from_pydata(verts,[],faces); d.update()
    o=bpy.data.objects.new(name,d); bpy.context.collection.objects.link(o); o.parent=parent
    o['part']=partof(parent); d.materials.append(mat)
    for p in d.polygons:p.use_smooth=smooth
    return o
def lathe(name,profile,mat,parent,n=128,a0=0,span=math.tau):
    v=[(r*math.cos(a0+span*i/n),r*math.sin(a0+span*i/n),z) for r,z in profile for i in range(n+1)]
    f=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=j*(n+1)+i;f.append((a,a+1,a+n+2,a+n+1))
    return mesh(name,v,f,mat,parent)
def ring(name,r,z,w,mat,parent,n=96):
    return lathe(name,[(r+w*math.cos(i*math.tau/6),z+w*math.sin(i*math.tau/6)) for i in range(7)],mat,parent,n)
def beam(name,a,b,w,d,mat,parent,bevel=.0):
    a,b=Vector(a),Vector(b)
    bpy.ops.mesh.primitive_cube_add(size=1)
    o=bpy.context.object;o.name=name;o.parent=parent;o.location=(a+b)/2
    o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();o.scale=(w,d,(b-a).length)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(mat);o['part']=partof(parent)
    if bevel:
        mod=o.modifiers.new('Edge radius','BEVEL');mod.width=bevel;mod.segments=2
        bpy.ops.object.modifier_apply(modifier=mod.name)
    return o
def rod(name,a,b,r,mat,parent,n=12):
    a,b=Vector(a),Vector(b)
    o=lathe(name,[(0,0),(r,0),(r,(b-a).length),(0,(b-a).length)],mat,parent,n)
    o.location=a;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def radial(a,r,z):return (r*math.cos(a),r*math.sin(a),z)
def panel_patch(name,z0,z1,r0,r1,a0,a1,mat,parent,n=8):
    return lathe(name,[(r0,z0),(r1,z1)],mat,parent,n,a0,a1-a0)
def patch_fasteners(name,z0,z1,r0,r1,a0,a1,parent,count=5):
    # Small, visible edge fasteners only. Their exact count is representative.
    for j in range(count):
        a=a0+(a1-a0)*j/(count-1)
        for z,r in [(z0,r0),(z1,r1)]:
            rod(name,radial(a,r+.009,z),radial(a,r+.026,z),.017,silver,parent,6)

# Main first stage: smooth white exterior and restrained circumferential joints.
# Removed the speculative paired longitudinal channels: no reference supports
# a raised strip crossing the NG-1 front lettering. Do not restore by symmetry.
lathe('First stage white tank exterior',[(3.5,10.85),(3.5,53.25)],white,booster,192)
for z in [11.15,18.7,30.4,42.0,52.95]:
    ring('Tank circumferential interface',3.502,z,.012,white2,booster,192)
# Actual lower blue paint boundary is a shallow arch in front view, not a flat
# cylinder stripe. Keep logos separate for the site's exact livery layer.
v=[];f=[];n=192
for j in range(2):
    for i in range(n+1):
        a=math.tau*i/n; z=11.1 if j==0 else 12.0+.82*abs(math.sin(a))
        v.append((3.508*math.cos(a),3.508*math.sin(a),z))
for i in range(n):f.append((i,i+1,n+i+2,n+i+1))
mesh('Blue lower tank arched band',v,f,blue,booster)

# Aft thermal skirt has a modest barrel shape. It does not flare into a cone.
tail_profile=[(3.63,.50),(3.77,.90),(3.88,2.5),(3.9,4.6),(3.82,7.05),(3.64,9.3),(3.5,11.12)]
lathe('Aft skirt thermal substrate',tail_profile,thermal[2],booster,192)
lathe('Aft skirt inner dark lining',[(3.54,.5),(3.54,4.5)],dark,booster,128)
def tailr(z):
    for (ra,za),(rb,zb) in zip(tail_profile,tail_profile[1:]):
        if za<=z<=zb:return ra+(rb-ra)*(z-za)/(zb-za)
    return tail_profile[-1][0]
rows=[.62,2.25,3.9,5.8,7.5,9.25,11.10]
for row,(za,zb) in enumerate(zip(rows,rows[1:])):
    for k in range(24):
        a0=math.tau*k/24+.0025;a1=math.tau*(k+1)/24-.0025
        panel_patch('Aft thermal protection panel',za+.015,zb-.015,tailr(za)+.014,tailr(zb)+.014,a0,a1,thermal[(k*3+row*5)%8],booster)
        if row in [3,4,5]:patch_fasteners('Aft panel edge fastener',za+.065,zb-.065,tailr(za)+.02,tailr(zb)+.02,a0+.025,a1-.025,booster,3)
for z in rows[1:-1]:ring('Aft panel transverse edge',tailr(z)+.018,z,.010,edge,booster,192)
lathe('White lower skirt rim',[(3.59,.42),(3.63,.50),(3.66,.64)],white2,booster,192)
ring('Aft lower metallic lip',3.63,.46,.047,silver,booster,192)

# Six stowed landing leg shells. In launch photos they are near-flush long
# inset panels, with a broad lower shoe and a narrower rounded shoulder.
for k in range(6):
    a=math.tau*k/6+math.pi/6;leg=empty('landing-leg-%02d'%(k+1),recovery,'recovery');leg.rotation_euler.z=a
    leg['leg']=True;leg['pose']='stowed';leg['detail_precision']='Shell and hinge proportions photo-estimated; concealed hydraulic system omitted'
    # Built as shallow curved, tapered shell; no long exposed fictitious piston.
    levels=[(.73,.45),(.97,.59),(1.35,.60),(6.65,.51),(7.10,.43),(7.40,.27)]
    vv=[]
    for offset in [.035,.14]:
        for z,halfwidth in levels:
            r=tailr(z)+offset
            for j in range(9):
                t=-halfwidth+2*halfwidth*j/8
                vv.append((math.sqrt(max(0,r*r-t*t)),t,z))
    ff=[];L=len(levels);stride=9;layer=L*stride
    for q in range(2):
        for j in range(L-1):
            for t in range(8):
                s=q*layer+j*stride+t;ff.append((s,s+1,s+10,s+9) if q else (s+9,s+10,s+1,s))
    for j in range(L-1):
        for t in [0,8]:
            s=j*stride+t;ff.append((s,s+9,s+9+layer,s+layer))
    for j in [0,L-1]:
        for t in range(8):
            s=j*stride+t;ff.append((s,s+1,s+1+layer,s+layer))
    mesh('Stowed leg curved thermal shell',vv,ff,thermal[4],leg)
    for z,hw in [(1.35,.61),(3.0,.575),(4.7,.55),(6.65,.52)]:
        for side in [-1,1]:
            rod('Leg shell edge fastener',(tailr(z)+.145,side*hw*.90,z),(tailr(z)+.18,side*hw*.90,z),.034,silver,leg,8)
    for side in [-1,1]:
        # Long edge seal follows the shell taper and does not stand off.
        for (z0,w0),(z1,w1) in zip(levels,levels[1:]):
            rod('Leg edge seal',(tailr(z0)+.13,side*w0,z0),(tailr(z1)+.13,side*w1,z1),.022,edge,leg,8)
    rod('Leg lower hinge axle',(tailr(1.06)+.16,-.49,1.06),(tailr(1.06)+.16,.49,1.06),.09,silver,leg,16)
    beam('Leg heel thermal shoe',(tailr(.86)+.10,-.45,.84),(tailr(.86)+.10,.45,.84),.34,.24,dark,leg,.055)
    for side in [-1,1]:
        beam('Lower hinge bracket',(tailr(1.03)+.04,side*.49,.91),(tailr(1.03)+.14,side*.49,1.32),.16,.19,white2,leg,.025)

# Large swept strakes: two opposing long, thin thermal-covered surfaces.
# A symmetric wedge section captures thickness, unlike a flat extrusion.
strake_outline=[(3.46,8.7),(4.72,12.5),(5.45,17.2),(5.45,24.9),(3.48,37.8)]
def finmesh(name,outline,thickness,mat,parent):
    vv=[(r,-thickness/2,z) for r,z in outline]+[(r,thickness/2,z) for r,z in outline]
    n=len(outline);ff=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    for j in range(n):ff.append((j,(j+1)%n,(j+1)%n+n,j+n))
    return mesh(name,vv,ff,mat,parent,False)
for k,a in enumerate([0,math.pi]):
    st=empty('strake-%02d'%(k+1),recovery,'recovery');st.rotation_euler.z=a;st['strake']=True
    finmesh('Strake thermal shell',strake_outline,.14,thermal[3],st)
    for (r0,z0),(r1,z1) in zip(strake_outline,strake_outline[1:]+strake_outline[:1]):
        rod('Strake thin perimeter cap',(r0,0,z0),(r1,0,z1),.048,edge,st,8)
    for z in [12.7,15.1,17.8,20.5,23.2,26.1,29.0,31.8,34.6]:
        # Determine intersection with leading/trailing sweep for segmented tiles.
        ints=[]
        for (r0,z0),(r1,z1) in zip(strake_outline,strake_outline[1:]+strake_outline[:1]):
            if min(z0,z1)<=z<=max(z0,z1) and z1!=z0:ints.append(r0+(r1-r0)*(z-z0)/(z1-z0))
        if len(ints)>=2:
            for side in [-1,1]:rod('Strake transverse thermal panel seam',(min(ints),side*.073,z),(max(ints),side*.073,z),.010,edge,st,6)
    rod('Strake root fairing',(3.49,0,10.5),(3.49,0,36.9),.095,white2,st,12)

# The interstage is a long brown thermal region, four actuated fins near its
# lower half and a bright upper separation ring. The interior receives the two
# upper nozzles; no cap is allowed to intersect those nozzles.
lathe('Interstage dark substrate',[(3.5,53.20),(3.5,61.93)],thermal[0],booster,192)
lathe('Interstage inside wall',[(3.43,53.20),(3.43,61.97)],dark,booster,128)
for row,(z0,z1) in enumerate([(53.26,55.4),(55.4,57.5),(57.5,59.5),(59.5,61.85)]):
    for k in range(20):
        a0=math.tau*k/20+.002;a1=math.tau*(k+1)/20-.002
        panel_patch('Interstage thermal panel',z0+.016,z1-.016,3.516,3.516,a0,a1,thermal[(k+3*row)%8],booster,8)
    ring('Interstage panel course edge',3.520,z0,.014,edge,booster,192)
for z in [53.05,53.23,61.88,61.98]:ring('Interstage separation collar',3.51,z,.06,white2,booster,192)
for k in range(4):
    a=math.pi/4+k*math.pi/2;g=empty('control-fin-%02d'%(k+1),recovery,'recovery');g.rotation_euler.z=a;g['controlFin']=True
    outline=[(3.48,54.0),(5.4,55.45),(5.4,57.1),(3.48,58.7)]
    finmesh('Actuated swept control fin',outline,.18,thermal[2],g)
    for (r0,z0),(r1,z1) in zip(outline,outline[1:]+outline[:1]):rod('Control fin edge',(r0,0,z0),(r1,0,z1),.048,edge,g,8)
    rod('Control fin root hinge',(3.59,0,54.75),(3.59,0,58.10),.11,dark,g,16)
    for z in [55.4,56.2,57.05]:
        rr=5.35 if z<57.1 else 5.2
        for side in [-1,1]:rod('Control fin thermal seam',(3.64,side*.092,z),(rr,side*.092,z),.01,edge,g,6)
    for z in [54.9,57.9]:rod('Fin hinge bearing',(3.55,-.21,z),(3.55,.21,z),.16,silver,g,16)

# Engines use sampled bell contours, a dark inside surface and metallic lip.
# BE-4 plumbing is hidden by the thermal aft bay, so only broad covered engine
# envelopes are modelled. This is deliberate, not an invented machinery bundle.
def engine(name,parent,x,y,z,h,exitR,kind):
    g=empty(name,parent,partof(parent),(x,y,z));g['engine']=kind
    prof=[];steps=26
    for i in range(steps+1):
        t=i/steps
        # z=0 exit. Smooth contraction into throat/chamber, approximate contour.
        r=exitR*(.19+.81*(1-t)**.63)
        prof.append((r,h*.83*t))
    prof +=[(exitR*.20,h*.93),(exitR*.24,h)]
    lathe(kind+' outer bell contour',prof,bellmat,g,80)
    inn=[(max(.03,r-.043),zz+.020) for r,zz in prof[:steps+1]]
    lathe(kind+' dark inner nozzle',list(reversed(inn)),bellinner,g,80)
    ring(kind+' machined exit lip',exitR-.016,.032,.026,nozzleLip,g,96)
    for t in [.29,.54,.72]:
        r=exitR*(.19+.81*(1-t)**.63);ring(kind+' nozzle reinforcement',r+.011,h*.83*t,.012,bellmat,g,80)
    lathe(kind+' throat covered mount',[(exitR*.25,h*.87),(exitR*.26,h+.30)],dark,g,32)
    return g
for k in range(7):
    if k==6:x=y=0
    else:a=k*math.tau/6;x,y=2.23*math.cos(a),2.23*math.sin(a)
    engine('BE-4-%02d'%(k+1),booster,x,y,0,3.5,.985,'BE-4')
# Flat aft engine-bay plate has holes aligned to the nozzles, rather than
# crossing the exhaust openings. A sparse annular web keeps draw calls low.
for k in range(6):
    a=k*math.tau/6+math.pi/6
    panel_patch('Aft peripheral thermal blanket',.72,.82,3.20,3.53,a-.18,a+.18,dark,booster,8)
    rod('Aft small attachment',radial(a,3.39,.61),radial(a,3.61,.61),.095,silver,booster,12)

# Two-engine liquid-hydrogen upper stage. Its concealed aft compartment extends
# into the first-stage interstage and belongs exclusively to the upper group.
lathe('Upper stage main white wall',[(3.5,0),(3.5,17.8)],white,upper,192)
# A simple closed bulkhead avoids depicting the cryogenic stage as an empty
# tube in the explanatory separated view. It is explicitly representative;
# mission-specific payload adapters and concealed internal equipment omitted.
bulkhead=lathe('Representative closed forward bulkhead',[(3.46,17.48),(3.20,17.79),(2.55,18.11),(1.6,18.38),(0,18.50)],white2,upper,128)
bulkhead['detail_precision']='Representative closed stage envelope, not a reconstruction of internal tank or payload hardware'
lathe('Upper stage lower inward dome',[(.5,-2.55),(2.6,-1.35),(3.40,-.4),(3.46,0)],white2,upper,128)
lathe('Upper stage lower aft skirt',[(3.46,-.6),(3.46,.22)],white2,upper,128)
for k,x in enumerate([-1.60,1.60]):
    engine('BE-3U-%02d'%(k+1),upper,x,0,-6.2,4.6,1.40,'BE-3U')
    rod('BE-3U covered mounting neck',(x,0,-1.75),(x,0,-.8),.31,dark,upper,24)
for z in [0,.26,17.5,17.76]:ring('Upper stage end collar',3.511,z,.043,white2,upper,192)
for i in range(84):
    z=.5+i*.2
    # Shallow ribs, not black rings: mimic the real corrugated white exterior.
    lathe('Upper stage shallow circumferential rib',[(3.5,z-.035),(3.529,z-.007),(3.529,z+.020),(3.5,z+.043)],white2,upper,160)
for a in [-math.pi/2,math.pi/2]:
    ch=empty('Upper stage external long cover',upper,'upper');ch.rotation_euler.z=a
    beam('Upper slim conduit cover',(3.545,0,.60),(3.545,0,17.0),.14,.12,white,ch,.017)
    for z in [1.0,4,7,10,13,16.4]:
        beam('Upper conduit bracket',(3.60,-.12,z),(3.60,.12,z),.05,.055,silver,ch,.006)
# A tear-drop shaped exterior blister is visible low on the real GS2 wall.
bl=empty('Upper visible low service blister',upper,'upper');bl.rotation_euler.z=-math.pi/2-.40
finmesh('GS2 tapered exterior blister',[(3.49,1.0),(3.77,1.08),(3.82,3.35),(3.70,4.60),(3.49,5.05)],.48,white,bl)
rod('GS2 blister lower exposed fixture',(3.64,0,.30),(3.69,0,1.20),.09,silver,bl,16)
for a in [math.pi/2+.4,-math.pi/2+.4]:
    g=empty('GS2 small lower access panel',upper,'upper');g.rotation_euler.z=a
    beam('Small rectangular service cover',(3.537,0,.5),(3.537,0,1.1),.40,.055,white2,g,.032)

# Standard fairing, smooth tangent shoulder and a gently rounded tip.
# Two closed thin shells are retained as separately movable semantic children.
profile=[(3.5,0),(3.5,8.80)]
for i in range(1,49):
    t=i/48
    # Half-ellipse profile closely follows NG-1, including smooth shoulder.
    profile.append((3.5*math.cos(t*math.pi/2),8.8+9.4*math.sin(t*math.pi/2)))
for half, a0 in [(right,-math.pi/2),(left,math.pi/2)]:
    half['pose']='closed';half['inner_liner']='representative, not an engineering interior'
    lathe('Fairing smooth outer shell',profile,white,half,80,a0,math.pi)
    inside=[(max(0,r-.060),z+.008 if z<18 else z-.024) for r,z in profile]
    lathe('Fairing inner thin liner',list(reversed(inside)),ivory,half,80,a0,math.pi)
    # Close longitudinal split rims using the same fairing contour.
    for a in [a0,a0+math.pi]:
        vv=[]
        for prof in [profile,inside]:vv += [(r*math.cos(a),r*math.sin(a),z) for r,z in prof]
        nn=len(profile);ff=[(i,i+1,i+1+nn,i+nn) for i in range(nn-1)]
        mesh('Fairing split rim',vv,ff,white2,half)
        for (r0,z0),(r1,z1) in zip(profile,profile[1:]):
            if z1<18.18:rod('Fairing fine longitudinal seam',radial(a,r0+.006,z0),radial(a,r1+.006,z1),.011,white2,half,6)
    lathe('Fairing lower separation flange',[(3.45,.03),(3.53,.03),(3.53,.18),(3.49,.20)],white2,half,80,a0,math.pi)
    lathe('Fairing lower recessed interface',[(3.51,.30),(3.51,.335)],seam,half,80,a0,math.pi)
    # Dark circular acoustic/service ports above the lower separation ring.
    for i in range(6):
        a=a0+math.pi*(i+.5)/6
        p0=radial(a,3.502,.92);p1=radial(a,3.52,.92)
        rod('Fairing dark circular port',p0,p1,.145,dark,half,20)
    for z in [3.5,8.8]:
        lathe('Fairing restrained transverse seam',[(3.504,z-.006),(3.504,z+.006)],white2,half,80,a0,math.pi)
    for a in [a0+.35,a0+2.0]:
        for z in [4.4,13.1]:
            r=3.5 if z<8.8 else 3.5*math.sqrt(max(0,1-((z-8.8)/9.4)**2))
            g=empty('Fairing small flush fitting',half,'fairing');g.rotation_euler.z=a
            beam('Fairing instrument fitting',(r+.01,0,z-.12),(r+.01,0,z+.12),.16,.018,white2,g,.014)

# Studio cameras/lights only for the editable source and review renders. They
# are never exported into the web model.
def camera(name,loc,target,scale):
    d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o)
    o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    d.type='ORTHO';d.ortho_scale=scale;d.lens=55;return o
cam=camera('QA full assembly',(100,-150,75),(0,0,49),109)
camera('QA aft detail',(30,-40,17),(0,0,11),29)
camera('QA upper detail',(34,-50,70),(0,0,66),34)
camera('QA engine underside',(14,-19,-24),(0,0,1.5),13)
for name,loc,power,size in [('Key', (25,-35,75),42000,28),('Fill',(-35,-15,40),24000,35),('Rim',(20,35,60),60000,25)]:
    d=bpy.data.lights.new(name,'AREA');o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o)
    o.location=loc;o.rotation_euler=(Vector((0,0,45))-o.location).to_track_quat('-Z','Y').to_euler();d.energy=power;d.shape='DISK';d.size=size
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.20,.24,.29,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.65
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.render.resolution_x=1200;scene.render.resolution_y=1400;scene.render.resolution_percentage=100
scene.camera=cam
bpy.context.view_layer.update()
source_meshes=[o for o in root.children_recursive if o.type=='MESH']
source_tris=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in source_meshes)
source_obj_count=len(source_meshes)
source_bounds=[o.matrix_world@v.co for o in source_meshes for v in o.data.vertices]
assert abs(min(p.z for p in source_bounds))<.001
assert abs(max(p.z for p in source_bounds)-98)<.00001
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'new-glenn-refined.blend'))

# Batch each semantic part / shell / material for fast browser rendering. Save
# first so the .blend remains editable at component level, then export the
# consolidated runtime scene. Empty hardware identifiers are retained.
buckets={}
for o in source_meshes:
    part=o['part']; ancestor=o
    while ancestor.parent and ancestor.parent not in [booster,upper,recovery,left,right]:ancestor=ancestor.parent
    dest=ancestor.parent
    if dest not in [booster,upper,recovery,left,right]:raise RuntimeError('Unexpected mesh parent')
    key=(dest.name,o.data.materials[0].name)
    buckets.setdefault(key,[]).append(o)
for (parentname,matname),objects in buckets.items():
    if not objects:continue
    bpy.ops.object.select_all(action='DESELECT')
    for o in objects:o.select_set(True)
    bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join()
    o=bpy.context.object;world=o.matrix_world.copy();o.parent=bpy.data.objects[parentname];o.matrix_world=world
    o.name=parentname+'__'+matname;o['part']=partof(o.parent)
    # glTF uses face normals for thin plate details and smooth normals for tanks.
runtime_meshes=[o for o in root.children_recursive if o.type=='MESH']
bpy.ops.object.select_all(action='DESELECT');root.select_set(True)
for o in root.children_recursive:o.select_set(True)
bpy.context.view_layer.objects.active=root
bpy.ops.export_scene.gltf(filepath=str(OUT/'new-glenn-refined.glb'),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_extras=True,export_animations=False,export_cameras=False,export_lights=False,export_texcoords=False,export_normals=True,export_materials='EXPORT')
stats={'asset':'new-glenn-refined.glb','configuration':'NG-1 prelaunch, 7x2, exterior photo reconstruction','height_m':98,'body_diameter_m':7,'source_meshes':source_obj_count,'source_triangles':source_tris,'runtime_meshes':len(runtime_meshes),'runtime_materials':len({m.name for o in runtime_meshes for m in o.data.materials}),'runtime_batches':len(buckets),'glb_bytes':(OUT/'new-glenn-refined.glb').stat().st_size,'booster_base_y':0,'upper_base_y':62,'fairing_base_y':79.8,'be4_count':7,'be3u_count':2,'fins':4,'strakes':2,'stowed_legs':6,'ground_y':0,'source_axis':'Z-up','glb_axis':'Y-up','bbox_blender':{'min':[min(p[i] for p in source_bounds) for i in range(3)],'max':[max(p[i] for p in source_bounds) for i in range(3)]},'upper_engine_global_min_y':55.8,'upper_engine_global_max_y':60.7,'upper_engine_max_radial_extent_m':3.0,'interstage_internal_radius_m':3.43,'semantic_groups':['booster','upper','fairing','booster/recovery','fairing/fairing-left','fairing/fairing-right']}
(OUT/'asset-stats.json').write_text(json.dumps(stats,indent=2))
print('ASSET_STATS',json.dumps(stats))
# Runtime geometry renders also confirm that batching did not disturb geometry.
for camera_name,outname,res in [('QA full assembly','qa-full.png',(1100,1400)),('QA aft detail','qa-aft.png',(1400,1100)),('QA upper detail','qa-upper.png',(1100,1400)),('QA engine underside','qa-engines.png',(1200,1200))]:
    scene.camera=bpy.data.objects[camera_name];scene.render.resolution_x=res[0];scene.render.resolution_y=res[1]
    scene.render.filepath=str(OUT/outname);bpy.ops.render.render(write_still=True)
