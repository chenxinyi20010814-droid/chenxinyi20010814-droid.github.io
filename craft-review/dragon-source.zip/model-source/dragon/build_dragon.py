"""Crew Dragon: closed nosecone / trunk. Public envelope, photo-estimated details.
References: NASA Commercial Crew press kit, Demo-2 exterior and annotated drawing.
Metres, Blender Z-up; GLB converts to Y-up. No private CAD/interior claim.
"""
import bpy, math, json, os
from pathlib import Path
from mathutils import Vector

HERE=Path(__file__).resolve().parent
OUT=Path(os.environ.get('DRAGON_EXPORT_DIR',str(HERE.parents[1]/'public/models')))
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
bpy.context.scene.unit_settings.system='METRIC'
def material(name,c,metal=0,rough=.4):
    m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
    return m
paint=material('Crew capsule white finish',(.80,.83,.85),.035,.37)
panel=material('Trunk radiator finish',(.68,.73,.76),.08,.50)
edge=material('Interface metallic rim',(.32,.36,.4),.65,.32)
joint=material('Narrow exterior seams',(.15,.18,.20),.05,.65)
glass=material('Dark window glazing',(.009,.025,.045),.36,.15)
black=material('Thruster recess',(.007,.01,.012),.08,.77)
shieldmat=material('PICA-X exterior face',(.034,.03,.028),.0,.88)
solar=material('Body-mounted solar cells',(.012,.033,.073),.4,.30)
cellwire=material('Solar cell interconnect grid',(.18,.26,.37),.35,.5)
def empty(name,parent=None,z=0,part=None):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.parent=parent;o.location.z=z
    if part:o['part']=part
    return o
root=empty('DRAGON');root['vehicle']='dragon';root['variant']='Crew Dragon, closed nosecone with trunk; photo-estimated exterior'
trunk=empty('trunk',root,part='trunk');cap=empty('capsule',root,3.5,'capsule')
escape=empty('escape',cap,part='escape');shield=empty('shield',cap,part='shield')
def mesh(name,vs,fs,mat,parent,smooth=True):
    d=bpy.data.meshes.new(name);d.from_pydata(vs,[],fs);d.update()
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.parent=parent;d.materials.append(mat)
    for p in d.polygons:p.use_smooth=smooth
    return o
def lathe(name,profile,mat,parent,n=128,start=0,span=math.tau):
    vs=[(r*math.sin(start+span*i/n),-r*math.cos(start+span*i/n),z) for r,z in profile for i in range(n+1)]
    fs=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=start+span*(i+.5)/n;z=(profile[j][1]+profile[j+1][1])/2
            cut=False
            if name=='Pressure-capsule exterior':
                for bay in [-1.18,1.18,math.pi-1.18,math.pi+1.18]:
                    da=(a-bay+math.pi)%math.tau-math.pi
                    if abs(da*radius(1.42)/.49)**4+abs((z-1.42)/.47)**4<1:cut=True
            if not cut:fs.append((j*(n+1)+i,j*(n+1)+i+1,(j+1)*(n+1)+i+1,(j+1)*(n+1)+i))
    return mesh(name,vs,fs,mat,parent)
def ring(name,r,z,th,mat,parent):
    return lathe(name,[(r+th*math.cos(t*math.tau/8),z+th*math.sin(t*math.tau/8)) for t in range(9)],mat,parent)
def line(name,points,th,mat,parent,closed=False):
    c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=th;c.bevel_resolution=1
    s=c.splines.new('POLY');s.points.add(len(points)-1)
    for p,v in zip(s.points,points):p.co=(*v,1)
    s.use_cyclic_u=closed;o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.parent=parent;c.materials.append(mat)
    bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False)
    return o
# Photo-calibrated rounded base and continuous taper, with a broad opening nose cap.
stations=[(0,1.80),(.13,1.93),(.32,2.0),(.62,1.985),(1.05,1.92),(1.7,1.78),(2.4,1.56),(3.05,1.30),(3.60,1.05),(3.72,.98),(3.98,.82),(4.25,.56),(4.48,.26),(4.6,0)]
def radius(z):
    for i in range(len(stations)-1):
        a,r=stations[i];b,q=stations[i+1]
        if a<=z<=b:
            t=(z-a)/(b-a)
            m0=(q-stations[max(i-1,0)][1])/(b-stations[max(i-1,0)][0])
            m1=(stations[min(i+2,len(stations)-1)][1]-r)/(stations[min(i+2,len(stations)-1)][0]-a)
            return (2*t**3-3*t*t+1)*r+(t**3-2*t*t+t)*(b-a)*m0+(-2*t**3+3*t*t)*q+(t**3-t*t)*(b-a)*m1
    return stations[0][1] if z<0 else 0
lathe('Pressure-capsule exterior',[(radius(z),z) for z in [i*3.72/160 for i in range(161)]],paint,cap,256)
lathe('Closed opening nosecone',[(radius(z),z) for z in [3.72+i*.88/32 for i in range(33)]],paint,cap)
ring('Nosecone seam',radius(3.72)+.004,3.72,.009,joint,cap)
lathe('Rounded capsule base ring',[(1.80,0),(1.93,.13),(2,.32),(1.996,.37)],edge,cap)
lathe('Heat shield underside',[(0,-.03),(.6,-.028),(1.3,.005),(1.76,.075),(1.87,.14)],shieldmat,shield)
def pos(a,z,offset=.007):
    r=radius(z)+offset;return (r*math.sin(a),-r*math.cos(a),z)
def outline(a,z,w,h,power=4,n=72):
    out=[]
    for i in range(n):
        t=i*math.tau/n;c=math.cos(t);s=math.sin(t)
        out.append((a+math.copysign(abs(c)**(2/power),c)*w/2/radius(z),z+math.copysign(abs(s)**(2/power),s)*h/2))
    return out
def patch(name,az,mat,parent,offset=.009):
    # Radial tessellation follows body curvature rather than a floating flat plate.
    mid=(sum(a for a,z in az)/len(az),sum(z for a,z in az)/len(az));n=len(az)
    vs=[pos(*mid,offset)];fs=[]
    for j in range(1,7):
        for a,z in az:vs.append(pos(mid[0]+(a-mid[0])*j/6,mid[1]+(z-mid[1])*j/6,offset))
    for i in range(n):fs.append((0,1+i,1+(i+1)%n))
    for j in range(5):
        p=1+j*n;q=p+n
        for i in range(n):fs.append((p+i,q+i,q+(i+1)%n,p+(i+1)%n))
    return mesh(name,vs,fs,mat,parent)
def rimpatch(name,a,z,w,h,mat,parent,power=4):
    rim=outline(a,z,w,h,power);patch(name+' lip',rim,edge,parent,.014)
    inside=outline(a,z,w-.045,h-.045,power);patch(name,inside,mat,parent,.018)
    return rim
# Two main crew windows flank the side hatch; actual local dimensions are estimates.
for sign in [-1,1]:rimpatch('Crew window '+str(sign),sign*.48,2.35,.50,.72,glass,cap,2.5)
h=outline(0,2.22,.94,1.23,6);line('Side hatch gasket',[pos(a,z,.015) for a,z in h],.009,joint,cap,True)
for z in [1.72,2.70]:
    a=.31;line('Hatch hinge',[pos(a,z-.055,.025),pos(a,z+.055,.025)],.025,edge,cap)
line('Hatch latch surround',[pos(a,z,.023) for a,z in outline(.21,2.13,.17,.20,6,32)],.007,joint,cap,True)
# Visible removable exterior panel boundaries. No guessed fastener forest.
for a in [0,math.pi]:
    line('Lower access panel',[pos(t,z,.01) for t,z in outline(a,.96,1.18,1.03,8)],.004,joint,cap,True)
for a in [-.65,.65,math.pi-.65,math.pi+.65]:
    line('Draco exterior panel',[pos(t,z,.012) for t,z in outline(a,1.30,.55,1.16,3)],.006,joint,escape,True)
    for da,z in [(-.075,1.54),(.075,1.78),(0,1.04)]:
        patch('Draco attitude outlet',outline(a+da,z,.17,.24,2,40),black,escape,.02)
# Four separate escape bays, outboard of the attitude-control panels. NASA
# exterior drawings show a downward-facing hood and a long fairing below it.
# Angles, depth and shell shape are photo estimates, not pressure-vessel CAD.
for a in [-1.18,1.18,math.pi-1.18,math.pi+1.18]:
    rim=outline(a,1.42,.98,.94,4,96)
    inner=outline(a,1.42,.80,.77,4,96)
    vs=[pos(t,z,.038) for t,z in rim]+[pos(t,z,-.21) for t,z in inner]
    fs=[(i,(i+1)%96,(i+1)%96+96,i+96) for i in range(96)]
    mesh('Escape bay sloping inner walls',vs,fs,edge,escape)
    patch('Escape bay recessed backing',inner,black,escape,-.215)
    line('Escape bay opening rim',[pos(t,z,.047) for t,z in rim],.023,paint,escape,True)
    # A modest outward hood conceals the unmodelled internal engine body.
    lower=[(a-.20,.38),(a+.20,.38),(a+.15,.91),(a-.15,.91)]
    patch('Escape bay lower fairing',lower,paint,escape,.038)
    line('Escape fairing outer edge',[pos(t,z,.047) for t,z in lower],.012,joint,escape,True)
    for da in [-.105,.105]:
        nozzle=outline(a+da,1.37,.27,.33,2.5,48)
        patch('SuperDraco recessed exit',nozzle,black,escape,-.145)
        line('SuperDraco nozzle lip',[pos(t,z,-.14) for t,z in nozzle],.023,edge,escape,True)
# Four forward Draco engines are under the closed nosecone, not exposed on this model.
escape['totalSuperDraco']=8;escape['totalDraco']=16;escape['visibleDraco']=12
escape['note']='Forward Draco engines hidden by closed nosecone; outlet profiles photographic approximations'
# Trunk: open-ended thin outer structure, fixed body-mounted solar half and radiator half.
lathe('Open trunk shell',[(1.79,3.5),(1.83,3.5),(1.83,0),(1.79,0),(1.79,3.5)],panel,trunk)
for z in [.045,3.43]:ring('Trunk end frame',1.832,z,.023,edge,trunk)
lathe('Solar half',[(1.841,.12),(1.841,3.34)],solar,trunk,96,0,math.pi)
# Cell lines are restricted to the solar surface. Cell pitch is display simplification.
for i in range(35):
    a=.016+i*(math.pi-.032)/34
    line('Solar longitudinal interconnect',[(1.846*math.sin(a),-1.846*math.cos(a),z) for z in [.14,3.32]],.0035,cellwire,trunk)
for i in range(25):
    z=.14+i*3.18/24
    line('Solar transverse interconnect',[(1.847*math.sin(a),-1.847*math.cos(a),z) for a in [j*math.pi/96 for j in range(97)]],.0035,cellwire,trunk)
for i in range(9):
    a=math.pi+i*math.pi/8
    line('Radiator panel joint',[(1.835*math.sin(a),-1.835*math.cos(a),.14),(1.835*math.sin(a),-1.835*math.cos(a),3.33)],.005,joint,trunk)
for i in range(4):
    a=math.pi/4+i*math.pi/2
    shape=[(1.825,.02),(2.28,.02),(2.28,1.25),(2.16,1.7),(1.825,2.8)]
    vs=[(r*math.sin(a)+d*math.cos(a),-r*math.cos(a)+d*math.sin(a),z) for d in [-.035,.035] for r,z in shape]
    fs=[tuple(range(4,-1,-1)),tuple(range(5,10))]+[(j,(j+1)%5,(j+1)%5+5,j+5) for j in range(5)]
    mesh('Trunk stabilizer '+str(i+1),vs,fs,paint,trunk,False)
    line('Stabilizer root',[((1.837)*math.sin(a),-(1.837)*math.cos(a),z) for z in [.15,2.65]],.012,edge,trunk)
    for z in [.25,3.18]:
        line('Trunk mounting pad',[(1.846*math.sin(a+t),-1.846*math.cos(a+t),z) for t in [-.07,.07]],.045,edge,trunk)
# Render camera and light helpers, excluded from GLB.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24
scene.world.color=(.18,.18,.18);scene.render.resolution_x=1000;scene.render.resolution_y=1300;scene.render.resolution_percentage=100
def camera(name,loc,target,scale):
    d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=scale;return o
cam=camera('inspection-camera',(9,-19,10),(0,0,4.05),9.6);scene.camera=cam
for name,loc,power,size in [('key',(-7,-11,13),2300,8),('fill',(8,-5,6),1700,7),('rim',(2,7,11),2400,5)]:
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,4))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'crew-dragon.blend'))
# Batch by semantic parent and material to limit web draw calls; preserve editable file above.
for p in [trunk,cap,escape,shield]:
    bymat={}
    for o in list(p.children):
        if o.type=='MESH':bymat.setdefault(o.data.materials[0].name,[]).append(o)
    for name,objects in bymat.items():
        bpy.ops.object.select_all(action='DESELECT')
        for o in objects:o.select_set(True)
        bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();bpy.context.object.name=p.name+'-'+name
bpy.ops.object.select_all(action='DESELECT');root.select_set(True)
for o in root.children_recursive:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'crew-dragon.glb'),export_format='GLB',use_selection=True,export_extras=True,export_yup=True)
meshes=[o for o in root.children_recursive if o.type=='MESH']
triangles=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in meshes)
stats={'triangles':triangles,'meshes':len(meshes),'bytes':(OUT/'crew-dragon.glb').stat().st_size,'height_m':8.1,'capsule_diameter_m':4,'precision':'overall dimensions public; local details estimated from NASA exterior photo/drawing'}
(HERE/'asset-stats.json').write_text(json.dumps(stats,indent=2))
scene.render.filepath=str(HERE/'inspection.png');bpy.ops.render.render(write_still=True)
print(json.dumps(stats))
