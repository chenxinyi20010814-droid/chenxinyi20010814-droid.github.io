"""Starship V3 exterior: B19/S39, SpaceX 12 May 2026 reference set.
Blender metres/Z-up -> GLB metres/Y-up. Official envelope; photo-estimated
stations and exterior fittings. No reconstruction of concealed engineering.
"""
import bpy, math, json, sys
from pathlib import Path
from mathutils import Vector
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from booster_detail import build_booster
OUT=HERE.parents[1]/'public'/'models'; OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
bpy.context.scene.unit_settings.system='METRIC'
bpy.context.scene.unit_settings.scale_length=1

def mat(name,color,metal,rough):
    m=bpy.data.materials.new(name); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Metallic'].default_value=metal; p.inputs['Roughness'].default_value=rough
    return m
steel=mat('V3 satin stainless steel',(.46,.49,.52),.91,.31)
darksteel=mat('Raptor dark alloy exterior',(.10,.115,.13),.78,.38)
edge=mat('Machined interface metal',(.57,.60,.62),.86,.26)
inner=mat('Nozzle interior',(.023,.027,.03),.42,.61)
seal=mat('Recessed interface and seal',(.021,.025,.029),.15,.73)
tps=mat('Ceramic thermal protection · hexagonal seams',(.034,.037,.043),.03,.69)
tpsEdge=mat('Thermal protection curved edges',(.028,.032,.036),.04,.70)
tileFace=mat('Individual ceramic tile faces',(.009,.011,.014),.025,.76)
tileGap=mat('Recessed gaps between thermal tiles',(.003,.004,.005),0,.92)

# Restrained sheet waviness, not arbitrary scratches or battle damage.
steelPixels=[]
for y in range(256):
    for x in range(256):
        u=x/256*math.tau; v=y/256*math.tau
        nx=.035*math.sin(u*3+math.sin(v))+.012*math.sin(u*17)
        ny=.024*math.cos(v*6+math.sin(u*2))
        n=Vector((nx,ny,1)).normalized(); steelPixels.extend((n.x*.5+.5,n.y*.5+.5,n.z*.5+.5,1))
im=bpy.data.images.new('Starship steel micro waviness',width=256,height=256,alpha=False)
im.colorspace_settings.name='Non-Color'; im.pixels.foreach_set(steelPixels); im.pack()
tex=steel.node_tree.nodes.new('ShaderNodeTexImage'); tex.image=im
nm=steel.node_tree.nodes.new('ShaderNodeNormalMap'); nm.inputs['Strength'].default_value=.65
steel.node_tree.links.new(tex.outputs['Color'],nm.inputs['Color'])
steel.node_tree.links.new(nm.outputs['Normal'],steel.node_tree.nodes.get('Principled BSDF').inputs['Normal'])

# A small seamless repeat with beveled hex joints. This is a material map, not a
# claim about the exact tile count or engineering layout. Physical pitch ~0.30m.
W,H=256,444; pitch=.30; periodX=pitch; periodY=pitch*math.sqrt(3)
def hex_sample(u,v):
    # Pointy hex centers form alternating half-offset rows in a 2-row repeat.
    best=1e9; cid=(0,0)
    for row in range(-1,4):
        cy=row*.5
        for col in range(-1,3):
            cx=col+(row%2)*.5
            dx=(u-cx); dy=(v-cy)*math.sqrt(3)
            d=max(abs(dx), .5*abs(dx)+math.sqrt(3)/2*abs(dy))
            if d<best: best=d; cid=(col,row)
    return best,cid
colors=[]; normals=[]
def tile_height(u,v):
    d,_=hex_sample(u,v); return min(1,max(0,(.493-d)/.018))
for y in range(H):
    for x in range(W):
        u=(x+.5)/W; v=(y+.5)/H
        d,cid=hex_sample(u,v); h=tile_height(u,v)
        val=.012+(.021+.002*math.sin(cid[0]*8+cid[1]*11))*h
        grain=.0007*math.sin(x*1.71+y*2.13)*h
        colors.extend((val+grain,val*1.015+grain,val*1.055+grain,1))
        dx=(tile_height(u+1/W,v)-tile_height(u-1/W,v))*.18
        dy=(tile_height(u,v+1/H)-tile_height(u,v-1/H))*.18
        n=Vector((-dx,-dy,1)).normalized(); normals.extend((n.x*.5+.5,n.y*.5+.5,n.z*.5+.5,1))
for name,pixels,is_normal in [('Starship TPS color',colors,False),('Starship TPS bevel normal',normals,True)]:
    im=bpy.data.images.new(name,width=W,height=H,alpha=False)
    im.colorspace_settings.name='Non-Color' if is_normal else 'sRGB'
    im.pixels.foreach_set(pixels); im.pack()
    tex=tps.node_tree.nodes.new('ShaderNodeTexImage'); tex.image=im; tex.extension='REPEAT'
    p=tps.node_tree.nodes.get('Principled BSDF')
    if is_normal:
        nm=tps.node_tree.nodes.new('ShaderNodeNormalMap'); nm.inputs['Strength'].default_value=.7
        tps.node_tree.links.new(tex.outputs['Color'],nm.inputs['Color'])
        tps.node_tree.links.new(nm.outputs['Normal'],p.inputs['Normal'])
    else: tps.node_tree.links.new(tex.outputs['Color'],p.inputs['Base Color'])

def empty(name,parent=None,z=0,part=None):
    o=bpy.data.objects.new(name,None); bpy.context.collection.objects.link(o)
    o.parent=parent; o.location.z=z
    if part: o['part']=part
    return o
def mesh(name,verts,faces,material,parent):
    data=bpy.data.meshes.new(name); data.from_pydata(verts,[],faces); data.update()
    o=bpy.data.objects.new(name,data); bpy.context.collection.objects.link(o)
    o.parent=parent; data.materials.append(material)
    for p in data.polygons: p.use_smooth=True
    return o
def lathe(name,profile,material,parent,n=64,start=0,span=2*math.pi):
    verts=[(r*math.cos(start+span*i/n),r*math.sin(start+span*i/n),z) for r,z in profile for i in range(n+1)]
    faces=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=j*(n+1)+i; faces.append((a,a+1,a+n+2,a+n+1))
    o=mesh(name,verts,faces,material,parent)
    uv=o.data.uv_layers.new(name='Exterior metres')
    for poly in o.data.polygons:
        for li in poly.loop_indices:
            vi=o.data.loops[li].vertex_index; row,col=divmod(vi,n+1)
            # Constant circumferential scale keeps longitudinal columns aligned.
            # Nose columns compress with curvature, a documented texture simplification.
            uv.data[li].uv=(4.5*span*col/n/(periodX if material==tps else 12),profile[row][1]/(periodY if material==tps else 12))
    return o
def cylinder(name,r,z0,z1,material,parent,n=64):
    return lathe(name,[(0,z0),(r,z0),(r,z1),(0,z1)],material,parent,n)
def torus(name,r,z,minor,material,parent,n=64):
    return lathe(name,[(r+minor*math.cos(i*math.tau/6),z+minor*math.sin(i*math.tau/6)) for i in range(7)],material,parent,n)
def beam(name,a,b,width,depth,material,parent):
    a,b=Vector(a),Vector(b)
    bpy.ops.mesh.primitive_cube_add(size=1,location=(a+b)/2)
    o=bpy.context.object; o.name=name; o.parent=parent; o.dimensions=(width,depth,(b-a).length)
    o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(material)
    return o
def tube(name,points,r,material,parent):
    curve=bpy.data.curves.new(name,'CURVE'); curve.dimensions='3D'; curve.resolution_u=6
    curve.bevel_depth=r; curve.bevel_resolution=1
    spline=curve.splines.new('POLY'); spline.points.add(len(points)-1)
    for p,co in zip(spline.points,points): p.co=(*co,1)
    o=bpy.data.objects.new(name,curve); bpy.context.collection.objects.link(o); o.parent=parent
    o.data.materials.append(material)
    bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o
    bpy.ops.object.convert(target='MESH')
    return bpy.context.object
def bell(name,r,h,parent,z=0,x=0,y=0,n=48):
    g=empty(name,parent,z); g.location.x=x; g.location.y=y
    if not parent.get('engine'): g['engine']=True
    g['batch_boundary']=True
    profile=[(r*(.22+.78*(1-i/14)**1.55),h*i/14) for i in range(15)]
    lathe(name+'-bell',profile,darksteel,g,n)
    lathe(name+'-open-interior',[(max(.01,rr-.018),zz) for rr,zz in reversed(profile)],inner,g,n)
    torus(name+'-exit-rim',r-.007,.016,.014,edge,g,n)
    for t in [.64,.80,.96]:
        torus(name+'-cooling-jacket-joint',r*(.22+.78*(1-t)**1.55)+.007,h*t,.015,edge,g,32)
    cylinder(name+'-chamber',r*.23,h,h+.40,darksteel,g,32)
    torus(name+'-chamber-flange',r*.28,h+.12,.032,edge,g,32)
    # Two offset exterior turbopump masses and one visible curved feed loop are
    # simplified from SpaceX's Raptor 3 photograph; not a complete fluid circuit.
    for sign,scale in [(-1,1),(1,.82)]:
        pump=cylinder(name+'-external-pump',r*.24*scale,h+.35,h+.70,edge,g,24)
        pump.location.x=sign*r*.30
    pts=[(-r*.50,0,h+.68),(-r*.68,0,h+.54),(-r*.70,0,h+.25),(-r*.62,0,h+.08),(-r*.28,0,h)]
    tube(name+'-exterior-feed-loop',pts,r*.065,darksteel,g)
    cylinder(name+'-upper-mount-neck',r*.17,h+.63,h+1.25,edge,g,24)
    return g

root=empty('STARSHIP'); root['vehicle']='starship'
root['variant']='V3 B19/S39 representative May 2026 exterior'
root['precision']='124m/9m official envelope; hardware stations and shapes photograph-estimated'
booster=empty('booster',root,part='booster')
recovery=empty('recovery',booster,part='recovery')
kit={k:globals()[k] for k in ['mesh','lathe','cylinder','torus','beam','empty','bell','steel','darksteel','edge','inner','seal']}
build_booster(booster,recovery,kit)
# Plain dark occlusion plane prevents the unmodeled tanks from appearing as a
# full-length empty tunnel through the aft openings. Not an engineering bulkhead.
occ=cylinder('B19-unmodeled-interior-occlusion',4.46,2.84,2.86,inner,booster,64)
occ['display_only']='Unmodeled interior occlusion, not an asserted bulkhead geometry'
ship=empty('ship',root,72,'ship')
heat=empty('flaps',ship,part='flaps')
# Continuous S39 envelope: straight tank/barrel and tangent rounded ogive.
profile=[(4.5,2.7),(4.5,40.5)]
for i in range(1,75):
    t=i/74
    profile.append((4.5*math.cos(t*math.pi/2)**.78,40.5+11.5*t))
profile[-1]=(0,52)
lathe('S39-stainless-envelope',profile,steel,ship,192)
# A thin visible lower skirt rather than a sealed old-generation engine cave.
lathe('S39-open-aft-skirt',[(4.5,.3),(4.5,2.7),(4.45,2.7),(4.45,.3)],steel,ship,128)
for z in [i*1.82+.35 for i in range(23) if i*1.82+.35<40.5]:
    lathe('S39-circumferential-weld',[(4.504,z-.008),(4.504,z+.008)],edge,ship,128)
# Windward = Blender -Y / browser +Z; cut follows visible V3 tile boundary.
shield=[(r+.023 if r>.03 else r,z) for r,z in [(4.5,.35),*profile]]
lathe('S39-TPS-recessed-base',shield,tileGap,heat,96,-math.pi*1.025,math.pi*1.05)
# Batched individual six-sided faces have a shallow crown and real recessed
# gaps. No per-tile objects/draw calls. Pitch and nose tessellation are estimates,
# not a replica of the proprietary tile map.
def radius_at(z):
    if z<=40.5: return 4.5
    return 4.5*max(0,math.cos(min(1,(z-40.5)/11.5)*math.pi/2))**.78
verts=[]; faces=[]; tileCount=0; halfspan=math.pi*.525
for row in range(197):
    z=.55+row*pitch*math.sqrt(3)/2
    if z>51.65: break
    rr=radius_at(z); limit=rr*halfspan
    for col in range(-int(limit/pitch)-1,int(limit/pitch)+2):
        x=(col+(row%2)*.5)*pitch
        if abs(x)+pitch*.48>limit: continue
        theta=-math.pi/2+x/rr; off=len(verts)
        verts.append(((rr+.054)*math.cos(theta),(rr+.054)*math.sin(theta),z))
        for k in range(6):
            a=math.pi/6+k*math.tau/6
            xx=x+pitch/math.sqrt(3)*.956*math.cos(a)
            zz=z+pitch/math.sqrt(3)*.956*math.sin(a)
            r=radius_at(zz); th=-math.pi/2+xx/max(r,.05)
            verts.append(((r+.046)*math.cos(th),(r+.046)*math.sin(th),zz))
        for k in range(6): faces.append((off,off+1+k,off+1+(k+1)%6))
        tileCount+=1
tiles=mesh('S39-individual-hex-tile-field',verts,faces,tileFace,heat)
tiles['tile_count_model_only']=tileCount; tiles['precision']='Teaching tessellation; not actual installed tile count'
# Nose tile coverage wraps around the tip in S39's rollout photographs.
cap=[(r+.024 if r>.03 else r,z) for r,z in profile if z>=50]
lathe('S39-tiled-tip',cap,tps,heat,64,math.pi*.025,math.pi*.95)
for angle in [-math.pi*1.025,math.pi*.025]:
    tube('S39-TPS-boundary',[((r+.025)*math.cos(angle),(r+.025)*math.sin(angle),z) for r,z in shield if r>.04],.017,tpsEdge,heat)

def flap(name,outline,side,depth):
    g=empty(name,heat); g['flap']=True; g['batch_boundary']=True
    if 'forward' in name: g.rotation_euler.z=side*.48
    # The thick lens/capped edge replaces a featureless thin rectangular plate.
    verts=[(side*x,y,z) for y in [-depth/2,depth/2] for x,z in outline]
    n=len(outline); faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    o=mesh(name+'-thick-metal-core',verts,faces,steel,g)
    for p in o.data.polygons: p.use_smooth=False
    # Forward and aft faces have distinct TPS / exposed metallic appearance.
    face=mesh(name+'-tiled-windward',[(side*x,-depth/2-.015,z) for x,z in outline],[tuple(range(n))],tps,g)
    for p in face.data.polygons: p.use_smooth=False
    uv=face.data.uv_layers.new(name='Tile pitch')
    for l in face.data.loops:
        x,z=outline[l.vertex_index]; uv.data[l.index].uv=(side*x/periodX,z/periodY)
    def inside(x,z):
        yes=False
        for i,(a,b) in enumerate(outline):
            c,d=outline[(i+1)%n]
            if (b>z)!=(d>z) and x<(c-a)*(z-b)/(d-b)+a: yes=not yes
        return yes
    tv=[]; tf=[]
    for row in range(int(min(z for _,z in outline)/(.8660254*pitch)),int(max(z for _,z in outline)/(.8660254*pitch))+1):
        zz=row*.8660254*pitch
        for col in range(int(min(x for x,_ in outline)/pitch)-1,int(max(x for x,_ in outline)/pitch)+2):
            xx=(col+(row%2)*.5)*pitch
            ring=[(xx+pitch/math.sqrt(3)*.956*math.cos(math.pi/6+k*math.tau/6),zz+pitch/math.sqrt(3)*.956*math.sin(math.pi/6+k*math.tau/6)) for k in range(6)]
            if not all(inside(x,z) for x,z in ring): continue
            off=len(tv); tv.append((side*xx,-depth/2-.041,zz))
            tv.extend((side*x,-depth/2-.033,z) for x,z in ring)
            for k in range(6): tf.append((off,off+1+k,off+1+(k+1)%6))
    mesh(name+'-individual-tiles',tv,tf,tileFace,g)
    pts=[(side*x,-depth/2-.02,z) for x,z in outline]
    tube(name+'-rounded-leading-edge',pts+[pts[0]],.062,tpsEdge,g)
    # Longitudinal hinge cover, three separated attachment collars; small seam
    # on the leeward face follows the real panel geometry rather than fake rivets.
    x0=outline[0][0]; z0=min(z for _,z in outline)+.35; z1=max(z for _,z in outline)-.55
    hinge=[(4.29,40.8),(4.17,43.0),(2.65,47.7)] if 'forward' in name else [(x0,z0),(x0,z1)]
    tube(name+'-hinge-cover',[(side*x,.14,z) for x,z in hinge],.13,darksteel,g)
    for t in [.10,.50,.88]:
        zz=z0+(z1-z0)*t
        xx=x0 if 'forward' not in name else 4.29-(zz-40.8)/6.9*1.64
        beam(name+'-hinge-collar',(side*(xx-.10),-.06,zz),(side*(xx+.15),.30,zz),.12,.19,edge,g)
    if 'forward' not in name: tube(name+'-leeward-panel-seam',[(side*(x0+.35),depth/2+.01,z0+.3),(side*(x0+.35),depth/2+.01,z1-.5)],.014,seal,g)
    return g
for side in [-1,1]:
    flap('S39-aft-flap-'+str(side),[(4.35,.4),(7.0,.4),(7.0,8.5),(4.52,14.1),(4.35,14.3)],side,.30)
    flap('S39-forward-flap-'+str(side),[(4.28,40.5),(6.7,40.4),(6.6,43.2),(2.65,48.0),(2.62,47.3),(4.13,43.0)],side,.22)

# Four leeward docking drogues are visible in the official rollout. The recess
# is an exterior ring only: no invented docking/propellant mechanism behind it.
for k,(x,z) in enumerate([(-2.2,36.0),(2.2,36.0),(-2.2,26.8),(2.2,26.8)]):
    rr=next((r for r,zz in profile if zz>=z),4.5)
    y=math.sqrt(max(0,rr*rr-x*x))+.025
    g=empty('S39-docking-drogue-'+str(k+1),ship); g['docking_drogue']=True
    g.location=(x,y,z); g.rotation_euler.x=-math.pi/2
    lathe('drogue-flared-ring',[(.25,0),(.36,.035),(.40,.08),(.38,.14),(.30,.17),(.25,.08)],edge,g,48)
    cylinder('drogue-dark-recess',.249,.01,.025,seal,g,48)
# Discrete access covers on leeward barrel: sizes/placement are approximate.
for angle,z in [(math.pi/2,40.9),(math.pi/2,21.8),(math.pi/2,7.0)]:
    rr=4.5 if z<40.5 else next(r for r,zz in profile if zz>=z)
    g=empty('S39-flush-access-cover',ship); g.location=(rr*math.cos(angle),rr*math.sin(angle),z); g.rotation_euler.x=-math.pi/2
    lathe('cover-edge',[(.28,0),(.30,.015),(.28,.03),(0,.03)],darksteel,g,48)
for k in range(3):
    a=k*math.tau/3+.5
    e=bell('S39-Raptor-vacuum-'+str(k+1),1.06,2.15,ship,z=.12,x=2.65*math.cos(a),y=2.65*math.sin(a),n=64)
    e['engine_type']='Raptor-vacuum'; e['precision']='Expanded bell exterior estimate; not Raptor3 internal CAD'
for k in range(3):
    a=k*math.tau/3+1.55
    e=bell('S39-Raptor3-sea-'+str(k+1),.59,1.7,ship,z=.30,x=1.06*math.cos(a),y=1.06*math.sin(a),n=48)
    e['engine_type']='Raptor3-sea'
# Open nozzle field; small support ring only. Avoid an invented solid plate
# passing through the six nozzles or copying V2's individual thermal shrouds.
torus('S39-aft-support-ring',4.34,2.75,.105,darksteel,ship,96)
occ=cylinder('S39-unmodeled-interior-occlusion',4.45,3.35,3.37,inner,ship,64)
occ['display_only']='Unmodeled interior occlusion, not an asserted bulkhead geometry'
for k in range(6):
    a=k*math.tau/6
    beam('S39-visible-aft-support',(3.6*math.cos(a),3.6*math.sin(a),2.75),(4.4*math.cos(a),4.4*math.sin(a),2.75),.09,.15,darksteel,ship)

bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'starship-v3.blend'))
# Batch by semantic part/material, without crossing engine or flap boundaries.
boundaries=[root,booster,recovery,ship,heat]+[o for o in root.children_recursive if o.get('batch_boundary')]
for parent in boundaries:
    def own(p):
        out=[]
        for c in list(p.children):
            if c.get('batch_boundary') or c.get('part'): continue
            if c.type=='MESH': out.append(c)
            else: out.extend(own(c))
        return out
    buckets={}
    for o in own(parent): buckets.setdefault(tuple(m.name for m in o.data.materials),[]).append(o)
    for group in buckets.values():
        if len(group)<2: continue
        bpy.ops.object.select_all(action='DESELECT')
        for o in group: o.select_set(True)
        bpy.context.view_layer.objects.active=group[0]; bpy.ops.object.join()
        o=bpy.context.object; world=o.matrix_world.copy(); o.parent=parent; o.matrix_world=world
        o.name=parent.name+'-'+o.data.materials[0].name
for o in list(bpy.context.scene.objects):
    if o.type!='MESH': continue
    bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
bpy.ops.object.select_all(action='DESELECT')
for o in [root,*root.children_recursive]: o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'starship-v3.glb'),export_format='GLB',use_selection=True,
    export_extras=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False)
stats={'variant':root['variant'],'height_m':124,'booster_m':72,'ship_m':52,'body_diameter_m':9,
    'glb_bytes':(OUT/'starship-v3.glb').stat().st_size,
    'triangles':sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in bpy.context.scene.objects if o.type=='MESH'),
    'mesh_objects':sum(o.type=='MESH' for o in bpy.context.scene.objects),
    'textures':[{'name':im.name,'width':im.size[0],'height':im.size[1]} for im in bpy.data.images if im.name.startswith('Starship')],
    'notes':'Official V3 envelope; component stations, tile pitch, fin clocking, welds and unphotographed engine-field supports are educational approximations.'}
(HERE/'asset-stats.json').write_text(json.dumps(stats,indent=2)); print(json.dumps(stats))
