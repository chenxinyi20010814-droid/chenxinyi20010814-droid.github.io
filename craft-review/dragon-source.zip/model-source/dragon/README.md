# Crew Dragon 轻量精修

构型：鼻锥关闭的载人 Crew Dragon，带非加压舱段。整体使用 SpaceX 官方 8.1 米总高与 4 米直径；不是早期货运 Dragon，也不复制某次任务贴花。

依据与主任务实际查看的图：

- [SpaceX Dragon 官方产品页](https://www.spacex.com/vehicles/dragon/)。
- [NASA Commercial Crew Press Kit](https://www.nasa.gov/commercial-crew-program-press-kit/)。
- [NASA Demo-2 外观照片](https://www.nasa.gov/wp-content/uploads/2024/04/spacex-demo-2-dragon.jpg)。
- [NASA 标注结构图](https://www.nasa.gov/wp-content/uploads/2024/04/spacex-dragon-graphic-2.jpg)。

本轮增加圆滑舱体、鼻锥接缝、舷窗、舱门轮廓与铰链、四组推进器开口、隔热盾外观、接口环、舱段散热表面与太阳能电池分区、四片舱段稳定翼。只做外部讲解，不建座舱与未公开的内部机构。

总计 16 台 Draco 的说明保留；外观模型显示 12 个可见开口，另 4 个位于关闭鼻锥内。8 台 SuperDraco 按四组双开口展示。开口形状、位置和深度为照片近似，深色凹面是简化表现，不是发动机工程剖面。窗口采用贴合曲面的玻璃面与边缘，不建透明舱内视野。

局部轴站、舱体曲率、壳厚、热盾形状、接缝与太阳能电池数量均为展示近似。白漆、玻璃、金属与深色热防护的参数用于区分表面，不是材料实验值。未复制照片像素，也未补入随机管线、螺钉或磨损。

## 文件

`crew-dragon.blend` 为合批前可编辑源；`build_dragon.py` 为 Blender 4.5 脚本。项目内运行 `blender --background --factory-startup --python model-source/dragon/build_dragon.py`，输出网页 GLB 至 `public/models/crew-dragon.glb`。下载包单独使用时设置 `DRAGON_EXPORT_DIR` 指定输出目录。

根 `DRAGON`、米制、Y-up，地面 0。`capsule` 基准 y=3.5；`escape`、`shield` 跟随 capsule，`trunk` 独立。分解仅用于讲解，不是真实飞行轨迹。

实际网页资产：3,260,008 字节、155,976 三角面、15 网格。没有自动旋转或预置动画。网页新旧图和交互检查见 `/craft-review/`。

验收前复核发现初版将 SuperDraco 放在 Draco 面板底部，已按 NASA 结构图修正：Draco 小喷口位于靠舱门的面板，SuperDraco 双喷口在更外侧的独立凹舱。四处凹舱在外壳中开孔，包含内壁和双出口，具体斜角与深度仍为外观估计。
