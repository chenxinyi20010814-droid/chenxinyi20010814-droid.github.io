# New Shepard · refined crew exterior

这是现代载人 New Shepard 的教学展示模型：乘员舱关闭、四条着陆腿和四块减速板收起。以 Blue Origin 当前产品结构图与 NS-38 实拍核对外观；不声称是 NS-38 某个序列号的工程复刻。未采用早期无窗原型舱。

## 交付

- `new-shepard.blend`：可编辑源文件，133 个网格对象，在网页静态合批之前保存。
- `new-shepard.glb`：米制、Y-up、地面 Y=0；4,624,952 bytes，220,120 个三角面，93 个实际绘制网格，126 个节点，无动画、无贴图。
- `build_new_shepard.py`：独立生成脚本，仅依赖 Blender 自带 Python/bpy，不读取或修改旧火箭资产。
- `metrics.json`：尺寸、三角面、标记计数、层级和贴字半径的实际检查结果。
- `render_checks.py`：读取源文件并生成四张检查图；不会保存灯光或相机回源文件。
- `full.png`、`capsule.png`、`ring-fin.png`、`tail.png`：实际 Blender/Cycles 渲染，不是参考照片或示意占位图。

重建：`blender --background --factory-startup --python build_new_shepard.py`。默认写脚本所在目录，也可在末尾用 `-- --output /absolute/output/path`。检查图：`blender --background --factory-startup --python render_checks.py`。Blender 4.5+；本次用现有 `/private/tmp/flight-atlas-blender/Blender.app/Contents/MacOS/Blender` 构建。`.blend1` 是 Blender 自动保留的前一源文件备份，不是交付主版本。

## 层级与部件

`NS` 带 `vehicle="newshepard"`、`variant="refined"`。根下仅有 `booster` 与 `capsule` 两个主要分解部件；`recovery` 嵌在 booster 内。胶囊局部原点在 Blender Z=14.8m，导出后在网页 Y=14.8m。上部环翼、楔翼、减速板、尾翼和着陆腿跟随 booster；六扇窗和关闭舱门全部跟随 capsule。每个网格都有 `part="booster"`、`"capsule"` 或 `"recovery"`。

保留 1 个 `engine=true` 的 BE-3PM 组、6 个 `window=true` 组、4 个 `leg=true` 组；另有 `dragBrake`、`controlFin`、`wedgeFin` 和 `hatch` 外形分组。发动机是单个有内外壁与开口的喷管，不是黑色圆盘代替。玻璃是在真实穿孔内的弯曲网格，带独立浅灰边框与深色凹入窗沿。主体采用连续圆滑轮廓；显示材料区分白漆、窗沿、胶圈、蓝灰玻璃、喷管和小范围可见金属件。

## 一手资料与实际查看的照片

Blue Origin [New Shepard 产品页](https://www.blueorigin.com/new-shepard)说明了载人舱、环翼与楔翼、减速板、BE-3PM、尾翼、着陆装置的组件关系。其[官方结构图](https://d1o72l87sylvqg.cloudfront.net/blue-origin/newshepard-specs_vessel.png)提供主要外形参考，但图中腿和减速板是展开姿态，本模型改为发射收起姿态；结构图本身不是实拍。

Blue Origin [NS-38 任务记录（2026-01-22）](https://www.blueorigin.com/news/new-shepard-ns-38-mission)确认这次是载人任务。该任务的乘员与落地舱照片用于核对圆钝舱顶、大窗、窗沿和舱门外轮廓。Blue Origin [NS-38 胶囊下降图库条目](https://www.blueorigin.com/gallery/asset/6972c92fc8b28f2654a8abe8)与[助推器着陆图库条目](https://www.blueorigin.com/gallery/asset/6972c930c8b28f2654a8abfe)补充构型检查；远景不能支持精细机构尺寸。

作者亲自打开查看以下本地原始参考，未把其中任何像素嵌入 GLB：

- `/tmp/blue-origin-reference/new-shepard-official-vessel.png`：上述官方结构图，整体组件关系、环翼/楔翼/尾翼、外部白色纵向盖板。
- `/tmp/blue-origin-reference/ns38-full-stack-liftoff.jpg`：现代载人整箭升空实拍，收起构型轮廓。
- `/tmp/blue-origin-reference/ns38-capsule.jpg`：NS-38 乘员站在落地胶囊前，主要真实近景参考；人群遮挡的底部细节不作精确复建。
- `/tmp/blue-origin-reference/ns38-booster-landing.jpg`：NS-38 助推器着陆实拍，回收组件相对位置；本模型不复制展开姿态。
- `/tmp/blue-origin-reference/ns37-booster-landing.jpeg`：现代载人助推器远景，仅作外部轮廓交叉检查，不复制某次飞行污渍。
- `/tmp/newshepard-refinement/ns38-capsule-descent.jpg`：[官方原图](https://d1o72l87sylvqg.cloudfront.net/redstone/gallery-NS38-capsule-descent.jpg)，远景舱形补充，不用于舱底内部细节。
- `/tmp/newshepard-refinement/official-ns15-capsule.jpg`：[当前产品页关联的官方 NS-15 舱下降图](https://d1o72l87sylvqg.cloudfront.net/blue-origin/BlueOrigin_NS15_06_CapsuleDescent-1.jpg)，仅作载人一代舱体外观补充；不是 NS-38 实拍，也没有混入早期无窗原型。

## 近似与未复建部分

保留展厅既有约 19.2m 总高、约 3.8m 胶囊主体直径、胶囊基准 14.8m 和助推器主体 3.1m 直径。这些不是本次从官方精确工程表核得的数值。各轴站、翼面与减速板尺寸、腿壳剖面、喷管曲线、窗框深度、舱门/板缝位置均为基于外观的简化估计。由于外缘与窗框厚度，实际网格最大包围盒约 3.815×3.823×19.200m，并非声称胶囊结构直径增至 3.823m。

玻璃保持不透明，未虚构座舱内部；壳体 0.065m 显示厚度不代表压力容器厚度。上部关闭盖板及舱底灰色盖面是克制的显示封闭面，不是逃逸发动机、推进管线或降落伞机构复原。喷管喉部遮蔽未建模区域；没有任意泵、阀、随机螺钉、内部杆系或精密制造断言。材质颜色、金属度和粗糙度是为了清楚显示而设的原创参数，不是 Blue Origin 材料规格。羽毛、旗和文字交给站点涂装，不在本资产内绘制。

## 贴字与坐标

Blender 的胶囊 local Z 对应网页 local Y。正面舱门位于 Blender -Y，即网页 +Z。六扇窗围绕胶囊均布；真实孔的局部高度 1.16–2.94m，外窗框最低 1.0621m。因此以 local Y=0.8、宽 2m、高 0.3m 贴字不会压到窗框；单扇舱门的下段轮廓可能在同一方位经过，这是外部舱门缝，不是窗。

以下是主体壳面半径（米），不含额外贴字偏移：

| 胶囊 local Y | 半径 |
| --- | --- |
| 0.65 | 1.887081 |
| 0.70 | 1.881029 |
| 0.75 | 1.875000 |
| 0.80 | 1.868555 |
| 0.85 | 1.861199 |
| 0.90 | 1.853003 |
| 0.95 | 1.844288 |

当前 `curvedDecal` 自带 +0.025m 偏移。local Y=0.8、高 0.3m 时，传入底半径 1.887081、顶半径 1.844288 即可；无需再手动增加偏移。原底 1.86 / 顶 1.8 在新轮廓上会部分陷壳。助推器 local Y=5.6–12.65 主体半径保持 1.55m。

## 检查结果

构建后实际读回 GLB 的索引数、节点标记和动画数量；同时检查最低点 0、总高约 19.2、1 台发动机、6 窗、4 腿。已运行四视角渲染并亲自查看：整箭轮廓与收起状态、胶囊穿孔/窗沿/舱门、隐藏胶囊后的环翼/楔翼/收起减速板、尾部单喷管与四腿四尾翼。近看发现并修正过窗中央分片线和玻璃网格反向法线，交付检查图来自修正后的几何。最后一次重建仅增加贴字半径统计，几何未变。网页加载、涂装、分解动画和明暗主题由主代理继续做浏览器检查，本目录不代替浏览器测试。
