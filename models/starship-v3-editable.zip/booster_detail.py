"""Photo-led Super Heavy V3 / B19 exterior asset, metre units, Blender Z up.

Entry point: build_booster(booster, recovery, kit). Uses kit['mesh'], kit['empty']
and the host's shared kit['bell'] for the same Raptor exterior on both stages.

REFERENCE LIMITS (deliberate, not engineering drawings):
  Personally inspected official B19_Transport_2603083576, B19_Lift_Pad2_2603083611,
  the official V3 full-stack photo, and Raptor_V3_McG_20240802_1w3a8289.
  Counts / V3 changes come from the SpaceX V3 update: three lowered larger grid
  fins, integrated open hotstage, exposed forward dome, 33 Raptor 3, no individual
  aft shrouds or large aft cavity; thin inter-engine and inner-13 TVC shielding.
  Fin clocking, weld spacing, truss bay count, engine ring radii and plate layout
  are photo / visualization estimates. No internal actuator, plumbing network,
  thrust frame, feed tube, or tank internals are represented. Engine top detail
  is a restrained exterior silhouette from the Raptor photo; transport hardware
  in that reference is deliberately omitted.

The parent scene specifies 0..72 m. The 68.4..72 m hotstage envelope uses the
official B19 photo's visible truss proportions, still a photographic estimate.
"""
from math import sin, cos, pi, sqrt, atan2

TAU = 2 * pi
BODY_RADIUS = 4.5
BODY_BASE = 2.8
HOTSTAGE_BASE = 68.4
BOOSTER_TOP = 72.0
GRIDFIN_Z = 62.6
GRIDFIN_CLOCK = (20.0, 140.0, 260.0)  # Equal 120 deg model clocking is an estimate.


def _add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def _sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def _mul(a, s):
    return tuple(x * s for x in a)


def _dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def _cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _unit(a):
    return _mul(a, 1 / max(sqrt(_dot(a, a)), 1e-12))


class _Batch:
    """One material / semantic subgroup, disconnected geometry in one mesh."""
    def __init__(self):
        self.v, self.f = [], []

    def add(self, vertices, faces):
        off = len(self.v)
        self.v.extend(vertices)
        self.f.extend(tuple(i + off for i in face) for face in faces)

    def revolve(self, profile, n=48, shift=(0, 0, 0), reverse=False, transform=None):
        v = []
        for r, z in profile:
            for i in range(n):
                p = (r*cos(TAU*i/n), r*sin(TAU*i/n), z)
                if transform:
                    p = transform(p)
                v.append(_add(p, shift))
        f = []
        for k in range(len(profile)-1):
            for i in range(n):
                j = (i+1) % n
                face = (k*n+i, k*n+j, (k+1)*n+j, (k+1)*n+i)
                f.append(tuple(reversed(face)) if reverse else face)
        self.add(v, f)

    def ring(self, radius, z, minor=0.02, n=64, sides=4, shift=(0, 0, 0), transform=None):
        profile = [(radius + minor*cos(TAU*j/sides), z + minor*sin(TAU*j/sides))
                   for j in range(sides+1)]
        self.revolve(profile, n, shift=shift, transform=transform)

    def beam(self, a, b, width, depth=None):
        d = _unit(_sub(b, a))
        ref = (0, 0, 1) if abs(d[2]) < .95 else (0, 1, 0)
        u = _mul(_unit(_cross(d, ref)), width/2)
        w = _mul(_unit(_cross(u, d)), (depth or width)/2)
        q = [_add(_mul(u, s), _mul(w, t)) for s, t in ((-1,-1),(1,-1),(1,1),(-1,1))]
        self.add([_add(p, x) for p in (a, b) for x in q],
                 [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])

    def tube(self, points, radius, n=8):
        vertices = []
        for k, p in enumerate(points):
            tangent = _unit(_sub(points[min(k+1, len(points)-1)], points[max(0,k-1)]))
            ref = (0,1,0) if abs(tangent[1]) < .9 else (1,0,0)
            u = _unit(_cross(tangent, ref))
            w = _unit(_cross(tangent, u))
            vertices.extend(_add(p, _mul(_add(_mul(u,cos(TAU*j/n)), _mul(w,sin(TAU*j/n))), radius))
                            for j in range(n))
        faces = []
        for k in range(len(points)-1):
            for j in range(n):
                faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
        self.add(vertices, faces)

    def polygon_prism(self, xy, bottom, top):
        n = len(xy)
        self.add([(x,y,z) for z in (bottom,top) for x,y in xy],
                 [tuple(reversed(range(n))), tuple(range(n,2*n))] +
                 [(j,(j+1)%n,(j+1)%n+n,j+n) for j in range(n)])

    def transformed(self, fn):
        self.v = [fn(v) for v in self.v]
        return self

    def emit(self, kit, name, mat, parent, smooth=False, **extras):
        if not self.v:
            return None
        obj = kit['mesh'](name, self.v, self.f, mat, parent)
        if obj is not None:
            for k,v in extras.items():
                obj[k] = v
            if smooth and hasattr(obj, 'data') and hasattr(obj.data, 'polygons'):
                for p in obj.data.polygons:
                    p.use_smooth = True
        return obj


def _clip(poly, a, b, c):
    """Clip convex 2-D polygon to a*x+b*y <= c."""
    out = []
    for i,p in enumerate(poly):
        q = poly[(i+1)%len(poly)]
        dp, dq = a*p[0]+b*p[1]-c, a*q[0]+b*q[1]-c
        if dp <= 1e-9:
            out.append(p)
        if (dp < 0) != (dq < 0):
            t = dp/(dp-dq)
            out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    return out


def _perforated_cell(batch, center, poly, hole, z, thickness=.055):
    """A thin Voronoi panel with an actual circular engine opening, no disk cap."""
    cx, cy = center
    angles = sorted(set([round((atan2(y-cy,x-cx) % TAU), 9) for x,y in poly] +
                        [round(TAU*i/32,9) for i in range(32)]))
    outer, inner = [], []
    for angle in angles:
        dx,dy = cos(angle),sin(angle)
        distance = 1e5
        for i,p in enumerate(poly):
            q=poly[(i+1)%len(poly)]
            ex,ey=q[0]-p[0],q[1]-p[1]
            den=dx*ey-dy*ex
            if abs(den)<1e-10:
                continue
            px,py=p[0]-cx,p[1]-cy
            t=(px*ey-py*ex)/den
            s=(px*dy-py*dx)/den
            if t>0 and -1e-7<=s<=1+1e-7:
                distance=min(distance,t)
        if distance == 1e5:
            raise ValueError('Cannot intersect thermal shield cell')
        # Hairline gaps indicate replaceable surface panels, not deep structures.
        distance=max(hole+.01,distance-.009)
        outer.append((cx+dx*distance,cy+dy*distance))
        inner.append((cx+dx*hole,cy+dy*hole))
    count=len(angles)
    vertices=[(x,y,h) for h in (z,z+thickness) for ring in (inner,outer) for x,y in ring]
    faces=[]
    for i in range(count):
        j=(i+1)%count
        faces.extend([(i,j,count+j,count+i),
                      (2*count+i,3*count+i,3*count+j,2*count+j),
                      (i,2*count+i,2*count+j,j),
                      (count+i,count+j,3*count+j,3*count+i)])
    batch.add(vertices,faces)


def _body(booster, kit):
    steel, dark, edge = kit['steel'],kit['darksteel'],kit['edge']
    shell=_Batch()
    # Open lower shell; no tall aft cavity, no blanket closing engine disk.
    shell.revolve([(4.47,BODY_BASE),(4.5,3.02),(4.5,HOTSTAGE_BASE),(4.46,HOTSTAGE_BASE+.05)],n=192)
    shell.emit(kit,'B19 stainless tank exterior',steel,booster,smooth=True,exterior=True)
    seams=_Batch()
    # 1.8 m barrel-course estimate; actual course count is not asserted.
    heights=[BODY_BASE+i*1.8 for i in range(1,36) if BODY_BASE+i*1.8 < HOTSTAGE_BASE]
    for k,z in enumerate(heights):
        seams.revolve([(4.502,z-.009),(4.502,z+.009)],n=128)
        z0=max(BODY_BASE,z-1.8)
        for j in range(8):
            theta=TAU*j/8+(k%2)*pi/8
            dt=.0016
            seams.add([(4.503*cos(t),4.503*sin(t),h) for h in (z0+.02,z-.02) for t in (theta-dt,theta+dt)],[(0,1,3,2)])
    seams.emit(kit,'Shallow circumferential and staggered axial welds',edge,booster,smooth=True,visual_estimate=True)
    # Visible exterior raceway on the reference's un-tiled booster barrel.
    cover=_Batch()
    th=-pi/4
    def on_barrel(v):
        r,t,z=v
        return (r*cos(th)-t*sin(th),r*sin(th)+t*cos(th),z)
    cover.beam((4.57,0,6.2),(4.57,0,64.3),.10,.25)
    cover.transformed(on_barrel)
    cover.emit(kit,'Photo visible narrow external raceway cover',steel,booster)
    bands=_Batch()
    for z in (7.2,16.1,25.0,33.9,42.8,51.7,60.6):
        bands.beam(on_barrel((4.63,-.16,z)),on_barrel((4.63,.16,z)),.045,.10)
    bands.emit(kit,'Raceway cover joints',edge,booster)


def _hotstage(booster, kit):
    parent=kit['empty']('Integrated hotstage exterior',parent=booster)
    parent['hotstage']=True
    parent['reference_limit']='Open structural rings and dome exterior only; bay spacing estimated'
    metal,trim,dome=_Batch(),_Batch(),_Batch()
    bottom,top=HOTSTAGE_BASE,BOOSTER_TOP
    metal.revolve([(4.39,bottom),(4.5,bottom),(4.5,bottom+.21),(4.39,bottom+.21),(4.39,bottom)],n=128)
    metal.revolve([(4.32,top-.38),(4.5,top-.38),(4.5,top),(4.32,top),(4.32,top-.38)],n=128)
    n=20
    for i in range(n):
        a=TAU*i/n
        foot=(4.42*cos(a),4.42*sin(a),bottom+.18)
        for direction in (-.5,.5):
            b=a+direction*TAU/n
            tip=(4.43*cos(b),4.43*sin(b),top-.37)
            metal.tube([foot,tip],.083,n=8)
        # Exterior flattened attachments visible below each V, not tank internals.
        th=a
        def mount(v):
            r,t,z=v
            return (r*cos(th)-t*sin(th),r*sin(th)+t*cos(th),z)
        b=_Batch()
        b.beam((4.51,0,bottom-.60),(4.51,0,bottom+.10),.13,.055)
        b.transformed(mount)
        trim.add(b.v,b.f)
    # Smooth protective sheet over the forward dome, exposed through open truss.
    dome_profile=[]
    for i in range(25):
        t=(pi/2)*i/24
        dome_profile.append((max(.001,4.37*cos(t)),bottom+.10+2.54*sin(t)))
    dome.revolve(dome_profile,n=128)
    dome.emit(kit,'Exposed forward dome protective steel surface',kit['steel'],parent,smooth=True)
    for theta in [TAU*i/16 for i in range(16)]:
        points=[((r+.008)*cos(theta),(r+.008)*sin(theta),z+.008) for r,z in dome_profile[:-1]]
        trim.tube(points,.009,n=4)
    metal.emit(kit,'Hotstage open V truss and structural rings',kit['steel'],parent,smooth=True)
    trim.emit(kit,'Hotstage attachment plates and shallow dome seams',kit['edge'],parent)


def _line_polygon(poly, coordinate, value):
    """Line/polygon intersections for clipped open grid bars."""
    out=[]
    for i,p in enumerate(poly):
        q=poly[(i+1)%len(poly)]
        a,b=p[coordinate]-value,q[coordinate]-value
        if (a<=0<=b or b<=0<=a) and abs(b-a)>1e-9:
            t=-a/(b-a)
            out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    out=sorted(set((round(x,7),round(y,7)) for x,y in out))
    return out[:1]+out[-1:] if len(out)>=2 else []


def _gridfins(recovery, kit):
    # Horizontal lattice in XY, clipped planform; not solid black rectangles.
    poly=[(4.63,-1.29),(5.17,-2.08),(7.85,-2.08),(8.46,-1.40),
          (8.46,1.40),(7.85,2.08),(5.17,2.08),(4.63,1.29)]
    inset=[(4.77,-1.24),(5.24,-1.94),(7.79,-1.94),(8.32,-1.34),
           (8.32,1.34),(7.79,1.94),(5.24,1.94),(4.77,1.24)]
    for index,degrees in enumerate(GRIDFIN_CLOCK,1):
        theta=degrees*pi/180
        parent=kit['empty']('B19 grid fin %d'%index,parent=recovery)
        parent['gridfin']=True
        parent['batch_boundary']=True
        parent['gridfin_index']=index
        parent['clocking_degrees_estimate']=degrees
        parent['reference_limit']='Clipped horizontal open lattice and sawtooth edge from B19 official photos; exact profile estimated'
        def tr(v):
            x,y,z=v
            return (x*cos(theta)-y*sin(theta),x*sin(theta)+y*cos(theta),z)
        frame,grid,root=_Batch(),_Batch(),_Batch()
        for i,p in enumerate(poly):
            q=poly[(i+1)%len(poly)]
            frame.beam((p[0],p[1],GRIDFIN_Z),(q[0],q[1],GRIDFIN_Z),.145,.48)
            length=sqrt((q[0]-p[0])**2+(q[1]-p[1])**2)
            if (p[0]+q[0])/2<4.9:
                continue
            # The B19 photo shows a scalloped/sawtooth lower leading silhouette.
            teeth=max(1,round(length/.46))
            for j in range(teeth):
                a=j/teeth;b=(j+.5)/teeth;c=(j+1)/teeth
                pa=(p[0]+a*(q[0]-p[0]),p[1]+a*(q[1]-p[1]),GRIDFIN_Z-.23)
                pb=(p[0]+b*(q[0]-p[0]),p[1]+b*(q[1]-p[1]),GRIDFIN_Z-.46)
                pc=(p[0]+c*(q[0]-p[0]),p[1]+c*(q[1]-p[1]),GRIDFIN_Z-.23)
                normal=_mul(_unit((q[1]-p[1],p[0]-q[0],0)),.075)
                frame.add([_add(x,_mul(normal,s)) for s in (-.5,.5) for x in (pa,pb,pc)],
                          [(0,2,1),(3,4,5),(0,1,4,3),(1,2,5,4),(2,0,3,5)])
        for x in [5.12+i*.45 for i in range(8)]:
            pts=_line_polygon(inset,0,x)
            if len(pts)==2:
                grid.beam((*pts[0],GRIDFIN_Z),(*pts[1],GRIDFIN_Z),.042,.39)
        for y in [-1.78+i*.445 for i in range(9)]:
            pts=_line_polygon(inset,1,y)
            if len(pts)==2:
                grid.beam((*pts[0],GRIDFIN_Z),(*pts[1],GRIDFIN_Z),.042,.39)
        # Root shaft is radial, with circumferential external bearing rings.
        # Actuator stays inside the tank as the V3 update specifies, so none shown.
        axis=lambda p:(p[2],p[0],GRIDFIN_Z+p[1])
        root.revolve([(.35,4.39),(.35,4.99)],n=48,transform=axis)
        root.revolve([(.52,4.47),(.52,4.59),(.34,4.59),(.34,4.47),(.52,4.47)],n=64,transform=axis)
        root.ring(.54,4.53,.035,n=64,sides=4,transform=axis)
        frame.transformed(tr).emit(kit,'Grid fin %d clipped perimeter and scalloped edge'%index,kit['darksteel'],parent)
        grid.transformed(tr).emit(kit,'Grid fin %d open cells'%index,kit['darksteel'],parent)
        root.transformed(tr).emit(kit,'Grid fin %d visible radial bearing and shaft'%index,kit['edge'],parent,smooth=True)


def _engine_positions():
    out=[]
    for count,radius,phase,label in ((20,3.56,0,'outer20'),(10,2.10,pi/10,'middle10'),(3,.80,pi/6,'center3')):
        for i in range(count):
            a=TAU*i/count+phase
            out.append((radius*cos(a),radius*sin(a),a,label))
    return out


def _engines(booster, kit):
    engines=kit['empty']('33 Raptor 3 sea level engines',parent=booster)
    engines['engine_count']=33
    engines['layout']='20 outer + 10 middle + 3 centre; ring radii are visualization estimates'
    positions=_engine_positions()
    for index,(x,y,angle,ring) in enumerate(positions,1):
        p=kit['empty']('Raptor 3 sea %02d %s'%(index,ring),parent=engines)
        p['engine']=True
        p['engine_type']='Raptor3-sea'
        p['engine_index']=index
        p['engine_ring']=ring
        p['gimballed']=ring!='outer20'
        # Shared host bell: h is nozzle height; compact housings extend +0.70 m.
        # A 0.555 m lip approximately matches the requested 0.57 m and avoids
        # adjacent nozzle overlap in the 20-engine ring at 3.56 m centre radius.
        kit['bell']('Raptor 3 sea %02d exterior'%index,.555,1.53,p,z=0,x=x,y=y,n=32)
        if ring!='outer20':
            # Open local shield surrounding inner-13 upper TVC volume; no hidden
            # TVC mechanism is invented. Aft plate itself has separate holes.
            local_shield=_Batch()
            local_shield.revolve([(.405,2.28),(.429,2.34),(.429,2.62)],n=32,shift=(x,y,0))
            local_shield.emit(kit,'Inner engine %02d open local TVC shield'%index,kit['darksteel'],p,smooth=True)
    shield=_Batch()
    for index,(x,y,_,ring) in enumerate(positions):
        # Voronoi construction makes a contiguous thin surface between engines
        # with 33 genuine through-holes. No face can cover a nozzle throat.
        poly=[(4.45*cos(TAU*i/128),4.45*sin(TAU*i/128)) for i in range(128)]
        for j,(xx,yy,_,_) in enumerate(positions):
            if index==j:
                continue
            poly=_clip(poly,xx-x,yy-y,(xx*xx+yy*yy-x*x-y*y)/2)
        _perforated_cell(shield,(x,y),poly,.355 if ring=='outer20' else .465,2.67,.045)
    shield.emit(kit,'V3 thin perforated inter engine thermal protection',kit['darksteel'],booster,
                engine_openings=33,reference_limit='Functional hole layout shown; exact panel seams estimated')
    rim=_Batch()
    rim.revolve([(4.43,2.66),(4.49,2.73),(4.50,2.87),(4.47,2.87),(4.43,2.71)],n=128)
    rim.emit(kit,'V3 short aft edge no deep engine cavity',kit['steel'],booster,smooth=True)


def build_booster(booster, recovery, kit):
    """Build B19-inspired V3 exterior; returns counts / model estimate metadata."""
    booster['booster_variant']='Super Heavy V3'
    booster['reference_vehicle']='B19'
    booster['engine_count']=33
    booster['gridfin_count']=3
    booster['scale_note']='72 m booster envelope; photographic exterior approximation, not CAD'
    _body(booster,kit)
    _hotstage(recovery,kit)
    _gridfins(recovery,kit)
    _engines(booster,kit)
    return {'engines':33,'gridfins':3,'height_m':BOOSTER_TOP,
            'diameter_m':BODY_RADIUS*2,'hotstage_base_m':HOTSTAGE_BASE,
            'gridfin_z_m':GRIDFIN_Z,'reference_vehicle':'B19',
            'limits':'Photo estimated dimensions, ring spacing, fin clocking, and thermal panel seams; no hidden engineering'}
