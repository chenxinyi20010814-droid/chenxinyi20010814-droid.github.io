# 继续编辑与重建

直接打开 `falcon-heavy.blend` 即可继续编辑；用 Blender 4.5 或兼容版本。

要从脚本重新生成，在本文件所在目录运行：

```sh
blender --background --factory-startup --python build_falcon_heavy.py -- --base input/falcon9-block5.blend --output rebuilt
```

脚本只读输入副本，输出放在新的 `rebuilt` 目录，不改原 F9。网页采用米制 Y-up GLB，不应重新归一化大小。照片来源与建模精度限制见 README / NOTES；不包含参考摄影像素。
