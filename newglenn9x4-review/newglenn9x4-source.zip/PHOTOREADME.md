# New Glenn 9×4 官方概念外形模型

本模型按 Blue Origin 官方概念图重建，供 Flight Atlas 三维观察与分解讲解。它没有对应已飞行实物，也不是工程 CAD。7×2 源码只提供通用几何工具和白漆、蓝漆、喷管材质基准；本模型的各级长度、尾段、边条翼、控制翼、腿壳、喷管排列和整流罩均单独建模，没有整体拉伸旧箭，也没有移植 NG-1／NG-2 的实拍磨损。

## 一手依据

核对日期：2026-09-10。据 [Blue Origin · New Glenn 9×4 产品页](https://www.blueorigin.com/new-glenn/9x4)，整箭接近 400 英尺，整流罩直径 8.7 米，一级使用九台 BE-4 Block 2，二级使用四台 BE-3U。网页没有把 8.7 米写成一级直径。

以下四张官方图片已经逐张查看。版权归 Blue Origin；图片仅作为造型参考，源文件包不附第三方照片，也没有把它们打包成模型贴图；可通过下列原始链接查看。

- [整箭演进对比](https://d1o72l87sylvqg.cloudfront.net/redstone/NG9x4_Evolution.jpg)：`ng9x4-evolution-concept.jpg`。主参考。用于各级比例、短白色级间领圈、短而宽的两侧边条翼、尾段腿壳与整流罩扩径肩部。
- [尾段及九喷管对比](https://d1o72l87sylvqg.cloudfront.net/blue-origin/NewGlenn-9x4_aftcompare_white.jpg)：`ng9x4-aft-comparison.jpg`。确认九喷管外圈八台、中央一台，并参考喷口外的银蓝色多边形金属覆盖片。
- [四台二级发动机](https://d1o72l87sylvqg.cloudfront.net/blue-origin/NewGlenn-9x4_quattro.jpg)：`ng9x4-upper-concept.jpg`。用于四喷管、深色下裙、二级局部接缝和短外部凸起的外形。
- [整流罩俯视](https://d1o72l87sylvqg.cloudfront.net/blue-origin/NewGlenn-9x4_fairing.jpg)：`ng9x4-fairing-concept.jpg`。补充壳体、分离接缝的观察。此图黑带位置与整箭演进图并不一致，因此模型以整箭演进图为主，没有照搬黑带，只保留浅色细接缝。

## 尺度与近似范围

网页统一标尺使用总高 121.9 米。这是对“接近 400 英尺”的展示近似，不能宣传成官方精确高度。整流罩最大壳体直径使用官方 8.7 米；一级与二级主圆筒采用约 7.8 米直径，取自概念图比例，尚无官方精确尺寸。

二级外壳起点 71 米、整流罩起点 98 米均为图像估计。喷管、腿壳、翼面和分块的具体尺寸、数量之外的细节都是概念外形近似。六个腿壳、四片控制翼与两条边条翼根据概念视图及同家族布局重建，不应称为已披露工程配置。

- 白色箭体不加穿过标志的长黑线，也不推定内部管路。
- 腿壳为较宽折面，下端有分叉拱口；只建外壳、外侧小盖和脚端包边，没有液压杆或内部机构。
- 尾段金属片有真实开孔，喷管内壁、出口唇与银蓝覆盖片分用不同材质。三角面之间只有轻微色差，不仿制箔材皱纹。
- 金褐色热防护外观干净，分块颜色变化克制；没有焦痕、烧蚀、锈蚀或飞行后磨损。
- 四台 BE-3U 全部属于二级。组装时喷管位于全局高度 64.4 至 69.49 米，收在级间段内，最大径向包络约 3.521 米，小于级间内半径 3.82 米。
- 喷管曲线是外观近似。黑色喉部封闭面只用于避免透视穿帮，未建立泵、阀、燃烧室内部结构。
- 二级顶面用简单封闭外形收口；它不是实际储箱顶、载荷适配器或任务载荷复原。
- 整流罩左右薄壳独立，有示意内衬和分离边缘。内壁颜色、壳厚与微小接缝没有公开工程尺寸依据。

## 文件与验证

- `new-glenn-9x4-refined.blend`：可编辑源文件，米制、Z 轴朝上，保留独立部件与检查相机。
- `new-glenn-9x4-refined.glb`：网页资产，米制、Y 轴朝上，地面为 y=0；未压缩，6,275,896 bytes，308,684 个三角面，37 个网格，19 种材质。
- `build_new_glenn_9x4.py`：完整重建脚本。先保存可编辑源文件，再按语义部件与材质合批导出。
- `verify_glb.py`：不依赖 Blender 的二进制几何检查。读取实际位置数据、层级变换、发动机布局和归属，对十三个喷口中心逐一检查，确认没有错误盖板封堵。
- `asset-stats.json`：建模统计。
- `glb-validation.json`：实际 GLB 统计与验证结果。最终 bytes、三角面数和包络以此文件为准。
- `qa-full.png`、`qa-aft.png`、`qa-engines.png`、`qa-upper.png`、`qa-upper-separated.png`、`qa-exploded.png`：Blender 实际渲染，依次为全貌、尾段、九喷管、装配二级、独立四喷管二级和分解图。

GLB 不含灯光、相机、动画、外部贴图或商标贴花。检查图中的尾部补光只属于源文件的检查布景，不影响网站照明。

## 接入约定

根节点名为 `NG`，自定义字段为 `vehicle=newglenn9x4`、`variant=refined`。直接子节点只有 `booster`、`upper`、`fairing`。`recovery` 位于 `booster` 内；每个网格都有 `part`，取值为 `booster`、`upper`、`fairing` 或 `recovery`。

以下是 GLB 的局部默认位置，均为米，不要再次套用 7×2 的位置偏移：

| 节点 | 父节点 | X | Y | Z |
|:---|:---|---:|---:|---:|
| NG | 场景 | 0 | 0 | 0 |
| booster | NG | 0 | 0 | 0 |
| recovery | booster | 0 | 0 | 0 |
| upper | NG | 0 | 71 | 0 |
| fairing | NG | 0 | 98 | 0 |
| fairing-left | fairing | 0 | 0 | 0 |
| fairing-right | fairing | 0 | 0 | 0 |

两瓣整流罩沿 X 轴打开：左瓣负 X，右瓣正 X。分解演示可使用二级上移 14 米、整流罩上移 32 米、左右瓣各外移 8 米；这只是讲解间距，不能称为实际分离轨迹。

贴花独立由网站涂装层处理。一级标志区域主壳半径 3.9 米，贴花表面建议再外移约 0.025 米。二级羽毛建议中心位于 `upper` 局部 y=16 米，贴花半径 3.95 米，避开局部凸起和浅环纹。图中 NEW GLENN、9×4、BLUE ORIGIN、国旗和羽毛都留给网站统一涂装，不用几何伪造字体。

## 重建

使用 Blender 4.5 或更新版本，后台运行 `build_new_glenn_9x4.py`，随后运行 `python3 verify_glb.py`。本次使用 Blender 4.5.9 LTS。部分 macOS 受限环境需要允许 Blender 访问本机图形驱动才能启动；脚本所有文件输出均位于它自身所在目录。
