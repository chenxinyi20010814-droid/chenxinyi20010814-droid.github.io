"""Independent, read-only binary/scene-graph and open-nozzle QA; stdlib only.
Run python3 verify_glb.py after build_new_glenn_9x4.py finishes.
"""
from pathlib import Path
import struct,json,math
P=Path(__file__).resolve().parent
raw=(P/'new-glenn-9x4-refined.glb').read_bytes()
magic,version,total=struct.unpack_from('<III',raw,0)
assert magic==0x46546c67 and version==2 and total==len(raw)
length,tag=struct.unpack_from('<II',raw,12);assert tag==0x4e4f534a
doc=json.loads(raw[20:20+length]);offset=20+length
blen,btag=struct.unpack_from('<II',raw,offset);assert btag==0x004e4942
binary=raw[offset+8:offset+8+blen]
nodes=doc['nodes'];rootids=doc['scenes'][doc.get('scene',0)]['nodes']
assert len(rootids)==1
root=nodes[rootids[0]]
assert root['name']=='NG' and root['extras']['vehicle']=='newglenn9x4' and root['extras']['variant']=='refined'
assert {nodes[i]['name'] for i in root['children']}=={'booster','upper','fairing'}
I=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
def mul(a,b):return [sum(a[k*4+r]*b[c*4+k] for k in range(4)) for c in range(4) for r in range(4)]
def local(n):
    if 'matrix' in n:return n['matrix']
    x,y,z,w=n.get('rotation',[0,0,0,1]);sx,sy,sz=n.get('scale',[1,1,1]);tx,ty,tz=n.get('translation',[0,0,0])
    return [(1-2*(y*y+z*z))*sx,2*(x*y+z*w)*sx,2*(x*z-y*w)*sx,0,2*(x*y-z*w)*sy,(1-2*(x*x+z*z))*sy,2*(y*z+x*w)*sy,0,2*(x*z+y*w)*sz,2*(y*z-x*w)*sz,(1-2*(x*x+y*y))*sz,0,tx,ty,tz,1]
def accessor(idx):
    a=doc['accessors'][idx];v=doc['bufferViews'][a['bufferView']]
    ctype={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'}[a['componentType']]
    count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    fmt='<'+ctype*count;size=struct.calcsize(fmt);stride=v.get('byteStride',size)
    off=v.get('byteOffset',0)+a.get('byteOffset',0)
    return [struct.unpack_from(fmt,binary,off+j*stride) for j in range(a['count'])]
verts=[];triangles=0;meshcount=0;part_meshes={};parts={};hardware={};worlds={};engine_nodes=[];tris_by_part={}
def walk(idx,parent,parentpart=None):
    global triangles,meshcount
    n=nodes[idx];world=mul(parent,local(n));worlds[n['name']]=world
    ex=n.get('extras',{});part=ex.get('part',parentpart)
    if ex.get('engine'):
        hardware[ex['engine']]=hardware.get(ex['engine'],0)+1
        engine_nodes.append({'name':n['name'],'engine':ex['engine'],'part':part,'centre':[world[12],world[13],world[14]]})
    for key in ['leg','controlFin','strake']:
        if ex.get(key):hardware[key]=hardware.get(key,0)+1
    if 'mesh' in n:
        assert ex.get('part') in ['booster','upper','fairing','recovery'],n['name']
        part_meshes[part]=part_meshes.get(part,0)+1;meshcount+=1
        for prim in doc['meshes'][n['mesh']]['primitives']:
            assert prim.get('mode',4)==4
            pp=accessor(prim['attributes']['POSITION'])
            ix=[i[0] for i in accessor(prim['indices'])] if 'indices' in prim else list(range(len(pp)))
            triangles+=len(ix)//3;transformed=[]
            for x,y,z in pp:
                p=[world[r]*x+world[4+r]*y+world[8+r]*z+world[12+r] for r in range(3)]
                assert all(math.isfinite(v) for v in p)
                transformed.append(p);verts.append(p);parts.setdefault(part,[]).append(p)
            tris_by_part.setdefault(part,[]).extend((transformed[ix[i]],transformed[ix[i+1]],transformed[ix[i+2]]) for i in range(0,len(ix),3))
    for c in n.get('children',[]):walk(c,world,part)
walk(rootids[0],I)
def bounds(v):return {'min':[min(p[i] for p in v) for i in range(3)],'max':[max(p[i] for p in v) for i in range(3)]}
bbox=bounds(verts);part_bounds={k:bounds(v) for k,v in parts.items()}
assert abs(bbox['min'][1])<1e-5 and abs(bbox['max'][1]-121.9)<1e-4,bbox
assert triangles<=350000 and len(raw)<=10000000
assert hardware=={'BE-4 Block 2':9,'leg':6,'strake':2,'controlFin':4,'BE-3U':4},hardware
assert abs(worlds['upper'][13]-71)<1e-6 and abs(worlds['fairing'][13]-98)<1e-6
assert abs(part_bounds['upper']['min'][1]-64.4)<1e-5
for g in ['NG','booster','recovery','fairing-left','fairing-right']:
    expected_y=98 if g.startswith('fairing-') else 0
    assert abs(worlds[g][13]-expected_y)<1e-5
recovery_idx=next(i for i,n in enumerate(nodes) if n['name']=='recovery')
booster_idx=next(i for i,n in enumerate(nodes) if n['name']=='booster')
assert recovery_idx in nodes[booster_idx]['children']
be4=[n for n in engine_nodes if n['engine']=='BE-4 Block 2']
be3=[n for n in engine_nodes if n['engine']=='BE-3U']
assert all(n['part']=='upper' for n in be3)
assert all(n['part']=='booster' for n in be4)
radii=sorted(math.hypot(n['centre'][0],n['centre'][2]) for n in be4)
assert radii[0]<1e-7 and all(abs(r-2.74)<1e-5 for r in radii[1:])
assert all(abs(math.hypot(n['centre'][0],n['centre'][2])-math.sqrt(4.5))<1e-5 for n in be3)

# For a vertical ray, barycentric coordinates in the XZ projection give Y at
# intersection. Reject every cover accidentally crossing an exhaust centre.
def first_hit_y(cx,cz,base_y,tri_list):
    nearest=float('inf')
    for a,b,c in tri_list:
        if not (min(a[0],b[0],c[0])-1e-8<=cx<=max(a[0],b[0],c[0])+1e-8 and min(a[2],b[2],c[2])-1e-8<=cz<=max(a[2],b[2],c[2])+1e-8):continue
        ux,uz=b[0]-a[0],b[2]-a[2];vx,vz=c[0]-a[0],c[2]-a[2]
        det=ux*vz-uz*vx
        if abs(det)<1e-10:continue
        dx,dz=cx-a[0],cz-a[2];u=(dx*vz-dz*vx)/det;v=(ux*dz-uz*dx)/det
        if u>=-1e-6 and v>=-1e-6 and u+v<=1+1e-6:
            y=a[1]+u*(b[1]-a[1])+v*(c[1]-a[1])
            if y>base_y+.001:nearest=min(nearest,y)
    return nearest
ray_checks=[]
for n in engine_nodes:
    x,y,z=n['centre'];hit=first_hit_y(x,z,y,tris_by_part[n['part']]);clear=hit-y
    assert math.isfinite(hit) and clear>3.0,(n,hit)
    ray_checks.append({'engine':n['name'],'clear_axial_depth_m':round(clear,5),'passed':True})
assert len(doc.get('textures',[]))==0 and len(doc.get('animations',[]))==0 and len(doc.get('cameras',[]))==0
result={'passed':True,'root':'NG','vehicle':'newglenn9x4','variant':'refined','axis':'Y-up','units':'metres','bounds':bbox,'height_m':bbox['max'][1]-bbox['min'][1],'triangles':triangles,'mesh_count':meshcount,'material_count':len(doc['materials']),'bytes':len(raw),'part_mesh_counts':part_meshes,'part_bounds':part_bounds,'hardware_empty_counts':hardware,'engine_nodes':engine_nodes,'nozzle_centre_ray_checks':ray_checks,'textures':len(doc.get('textures',[])),'animations':len(doc.get('animations',[])),'exported_cameras':len(doc.get('cameras',[])),'notes':'Independent binary positions transformed through actual GLB hierarchy; dimensions, 8+1/4 engine layouts, part ancestry, and clear exhaust centres verified.'}
(P/'glb-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
