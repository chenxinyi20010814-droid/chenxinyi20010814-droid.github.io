# Falcon Heavy Block 5 · GOES-U

模型选择 2024-06-25 的 GOES-U 构型：两侧助推器回收，中心芯级消耗，标准整流罩。所有回收硬件保持发射前收拢状态，无动画。只制作火箭飞行外观，不含发射架、运载车、尾部运输遮挡件、载荷或推测的精密内部机构。

## 文件

- `falcon-heavy.blend`：可编辑、未合并的 Blender 工程。按中心芯级、两侧芯级、回收组件、上面级和两片整流罩分组。相同侧芯细节使用关联几何，需单独改某一件时可设为单用户。
- `falcon-heavy.glb`：网页版。静态几何按所属部件和材质合并，重复的相同材质批次共用几何缓冲。保留 27 个海平面发动机、1 个真空发动机、8 个栅格翼和8条腿的位置标记；这些标记不单独持有绘制网格。可编辑工程保留逐件归属。
- `build_falcon_heavy.py`：独立可复建脚本，仅以接受版 F9 `.blend` 为只读输入，不导入或改写 F9 邻近脚本。
- `asset-stats.json`：实际面数、尺寸、文件字节数和部件统计。
- `render_checks.py`、`full.png`、`upper-connections.png`、`aft.png`：本地形体检查。不是用户网页的实机表现证据。

复建示例：

```sh
blender --background --factory-startup --python build_falcon_heavy.py -- --base /absolute/path/falcon9-block5.blend --output /absolute/path/falcon-heavy-output
```

默认输出在本脚本目录，默认输入指向接受版 F9 文件。脚本只读取输入。需使用支持 glTF 导出的 Blender。复建不需要网络。

## 尺寸与可动层级

源工程使用米和 Blender Z 向上；GLB 导出为米和 Y 向上，不需网站再归一化尺寸。

- 整箭名义高度 70m，三芯直径各3.66m，标准罩直径5.2m，整罩高度13.2m。接受版接缝几何使包围盒高度约70.003m、罩最大深度约5.209m。
- 左右总外包络约12.2m。芯级中心距约4.149m，是按实际收拢外件包络和照片间距选择的建模值，不是公开工程尺寸。
- 根 `FH`，`vehicle='fh'`；中心 `booster`，`part='booster'`。
- 两侧 `side-left`、`side-right`，`part='side'`；各自包含 `part='recovery'` 的回收部件根。
- `upper` 直接挂根节点，源坐标Z47m；上面级真空喷管随它移动，装配时藏在中心级间内部。
- `fairing` 直接挂根节点，源坐标Z56.8m；下含 `fairing-left` 和 `fairing-right` 两片半壳。
- 中心级间保留在 `booster`，白色外观；照片中的较高灰环画在上面级底部Z47–50m。没有给灰环强加未经官方确认的功能名称。
- 上部连接横梁中心Z43.28m，下方短斜撑到Z41.88m。分解展示时每个侧半连接整体随对应侧芯移动，中心小安装座留在中心，不会留下一根同时连接两端的拉长杆。

## 依据与取舍

据 NOAA 的 GOES-U 发射准备说明，中心助推器消耗、两侧回陆地；NASA 在发射当天确认两侧分别成功返回 Landing Zone 1 和2。[NOAA说明](https://www.nesdis.noaa.gov/news/goes-u-road-launch)、[NASA着陆确认](https://science.nasa.gov/blogs/goes/2024/06/25/falcon-heavy-side-boosters-stick-the-landing/)。中心没有腿、没有栅格翼，同时得到本任务照片支持。

尺寸沿用 SpaceX 公开 Falcon/Falcon Heavy 外包络和接受版 F9 标准罩；三芯各9台、合计27台海平面 Merlin 的布局据 [SpaceX Falcon Heavy](https://new.spacex.com/vehicles/falcon-heavy)。喷管、尾板、腿部连接采用接受版 F9 的同代 Block 5 细节，来源和近似范围仍以原 F9 `README.md` 为准；不能说这套尾部每个紧固点都由 GOES-U 照片逐一确认。

本模型作者亲自查看过 NASA 官方高清0005、0010和 NOAA 离塔发射原图，并先后查看该任务的五张预备照片。最终外部新增细节主要依据：

1. [NASA KSC-20240624-PH-SPX01_0005](https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0005)，署名 SpaceX，2024-06-24：侧芯圆钝鼻锥、折叠栅格翼、上部细白横梁、短斜撑、黑色顶部外罩和中心白色段上方的灰环。
2. [NASA KSC-20240624-PH-SPX01_0010](https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0010)，署名 SpaceX，同日：中心无回收件、侧腿收拢轮廓、三芯前侧黑色纵向外部线槽。
3. [NOAA GOES-U发射原图](https://www.flickr.com/photos/noaasatellites/53828532278)，2024-06-25，NASA/Kevin O'Connell与Kevin Davies：离开发射塔之后仍能看到上部细白横件；整流罩两侧的宽臂和环夹属于地面设备，没有画进模型。

侧鼻锥从Z42.5m到45.9m、线槽宽度与局部外罩、连接梁截面和上下安装位置均为照片估计。主整流罩只在最后约1m将接受版F9偏尖的鼻端略收圆，依据NASA0005的轮廓；保持总高度、直径和两片拆分，原F9文件不变。特别是下连接件遮挡严重，本模型只画简化外部安装座和短连接轮廓，不声称重建释放机构、承力内部或真实销轴尺寸。上连接不画精密紧固点。

Rollout照片中的整流罩深色鼻端，在白天飞行图上没有得到一致确认，最终没有保留。没有新增烟熏、划痕、任务贴花、国旗或机构logo；贴花留给网站处理。参考照片仅用于本地检查，没有嵌入 GLB 或上传公开目录。GLB 仅含接受版 F9 自绘的两张256px表面纹理，不使用照片像素。

## 检查范围

脚本逐次断言：28个发动机标记、8翼、8腿，中心无回收组，12.2m宽和70m高的容差通过。本人检查了整箭、上连接和尾部三张渲染：侧鼻锥和中心白段关系正常，三芯尾部都有八加一喷管；中心没有腿或翼。网页加载、鼠标选择、真实分解和深浅主题由主任务另行验证。
