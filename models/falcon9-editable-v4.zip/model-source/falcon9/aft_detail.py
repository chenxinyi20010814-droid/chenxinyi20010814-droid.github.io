"""Block 5 aft exterior, photo-led visual approximation, not an engineering model.

References: Pauline Acalin's B1048 engine close-up (2018) and SpaceX-credited
B1060 processing photo (2019). Visible nozzle ring, short curved tube, quilted
neck covering, aperture flanges and fasteners only. No valves, turbopumps,
internal Octaweb, temporary red protective pieces or surrounding ground rigs.
"""
import bpy, math
from mathutils import Vector


def material(name, color, metal, rough):
    m=bpy.data.materials.new(name); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Metallic'].default_value=metal
    p.inputs['Roughness'].default_value=rough
    return m


def surface_maps(m, roughness=.45, metallic=.7):
    """Small original cylindrical metal finish maps, not copied photo textures."""
    n=256; normal=[]; orm=[]
    for j in range(n):
        for i in range(n):
            u=i/n; v=j/n
            fine=math.sin(2*math.pi*(u*83+v*1.2))*.45+math.sin(2*math.pi*(u*137-v*2.3))*.25
            broad=math.sin(2*math.pi*(u*7+v*1.1))*.5+math.sin(2*math.pi*(u*13-v*4))*.2
            normal.extend((.5+.012*fine,.5+.003*math.sin(2*math.pi*v*73),1,1))
            orm.extend((1,roughness+.065*broad+.025*fine,metallic,1))
    nodes=m.node_tree.nodes; links=m.node_tree.links; p=nodes.get('Principled BSDF')
    for suffix,pixels in [('normal',normal),('metal-roughness',orm)]:
        img=bpy.data.images.new('F9 aft '+suffix,width=n,height=n,alpha=True)
        img.colorspace_settings.name='Non-Color'; img.pixels.foreach_set(pixels); img.pack()
        tex=nodes.new('ShaderNodeTexImage'); tex.image=img
        if suffix=='normal':
            normal_node=nodes.new('ShaderNodeNormalMap'); normal_node.inputs['Strength'].default_value=.5
            links.new(tex.outputs['Color'],normal_node.inputs['Color'])
            links.new(normal_node.outputs['Normal'],p.inputs['Normal'])
        else:
            separate=nodes.new('ShaderNodeSeparateColor')
            links.new(tex.outputs['Color'],separate.inputs['Color'])
            links.new(separate.outputs['Green'],p.inputs['Roughness'])
            links.new(separate.outputs['Blue'],p.inputs['Metallic'])


def mesh(name, vertices, faces, mat, parent, smooth=False, uvs=None):
    data=bpy.data.meshes.new(name); data.from_pydata(vertices,[],faces); data.update()
    ob=bpy.data.objects.new(name,data); bpy.context.collection.objects.link(ob)
    ob.parent=parent; data.materials.append(mat)
    for poly in data.polygons: poly.use_smooth=smooth
    if uvs:
        layer=data.uv_layers.new(name='Cylinder UV')
        for poly in data.polygons:
            for li in poly.loop_indices: layer.data[li].uv=uvs[data.loops[li].vertex_index]
    ob['detail_source']='B1048/B1060 exterior photographs; local dimensions approximate'
    return ob


def lathe(name, profile, mat, parent, n=64):
    vertices=[]; uvs=[]
    for j,(r,z) in enumerate(profile):
        for i in range(n+1):
            a=2*math.pi*i/n
            vertices.append((r*math.cos(a),r*math.sin(a),z))
            uvs.append((i/n,j/(len(profile)-1)))
    faces=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=j*(n+1)+i; faces.append((a,a+1,a+n+2,a+n+1))
    return mesh(name,vertices,faces,mat,parent,True,uvs)


def ring(name,r,z,minor,mat,parent,n=48):
    return lathe(name,[(r+minor*math.cos(i*math.tau/8),z+minor*math.sin(i*math.tau/8)) for i in range(9)],mat,parent,n)


def pipe(name,points,r,mat,parent,sides=12):
    # Smooth sampled centre line with a small closed tubular section.
    curve=bpy.data.curves.new(name,'CURVE'); curve.dimensions='3D'
    curve.resolution_u=6; curve.bevel_depth=r; curve.bevel_resolution=2
    s=curve.splines.new('BEZIER'); s.bezier_points.add(len(points)-1)
    for p,co in zip(s.bezier_points,points):
        p.co=co; p.handle_left_type=p.handle_right_type='AUTO'
    ob=bpy.data.objects.new(name,curve); bpy.context.collection.objects.link(ob); ob.parent=parent
    curve.materials.append(mat)
    bpy.ops.object.select_all(action='DESELECT'); bpy.context.view_layer.objects.active=ob
    ob.select_set(True); bpy.ops.object.convert(target='MESH'); ob.select_set(False)
    return ob


def fastener(name,x,y,z,mat,parent,r=.018):
    # Sparse visible head/washer silhouette; number and pitch are not engineering values.
    ob=lathe(name,[(0,z),(r,z),(r,z+.008),(r*.68,z+.009),(r*.68,z+.024),(0,z+.024)],mat,parent,12)
    ob.location.x=x; ob.location.y=y
    return ob


def build_aft(booster):
    metal=material('Merlin aft · satin metal exterior',(.265,.28,.295),.66,.58)
    surface_maps(metal,roughness=.58,metallic=.66)
    dark=material('Merlin aft · dark internal nozzle',(.006,.009,.012),.12,.86)
    neck=material('Merlin aft · dark neck exterior',(.052,.061,.068),.55,.56)
    plate=material('Aft exterior · coated segmented shield',(.044,.05,.055),.18,.70)
    rim=material('Aft exterior · exposed flange',(.30,.32,.335),.66,.42)
    hardware=material('Aft exterior · dark fastener',(.024,.030,.034),.55,.48)
    blanket=material('Aft exterior · folded neck cover',(.035,.041,.046),.05,.91)
    # A recessed shield, not a speculative exposed structural truss.
    bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=1.765,depth=.085,location=(0,0,1.525))
    deck=bpy.context.object; deck.name='photo-led-aft-shield'; deck.parent=booster
    deck.data.materials.append(plate); deck['detail_source']='B1060 underside: shield with circular engine apertures'
    centers=[]
    for k in range(9):
        a=(k-1)*math.pi/4
        x,y=(0,0) if k==0 else (1.12*math.cos(a),1.12*math.sin(a))
        centers.append((x,y))
        bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.335,depth=.5,location=(x,y,1.525))
        cutter=bpy.context.object; mod=deck.modifiers.new('Engine clearance','BOOLEAN'); mod.operation='DIFFERENCE'; mod.object=cutter
        bpy.context.view_layer.objects.active=deck; bpy.ops.object.modifier_apply(modifier=mod.name)
        bpy.data.objects.remove(cutter,do_unlink=True)
    # Plate seams and perimeter heads visible in the underside photograph.
    ring('aft-perimeter-flange',1.725,1.479,.022,rim,booster,96)
    for k in range(32):
        a=math.tau*k/32
        fastener('perimeter shield fastener',1.66*math.cos(a),1.66*math.sin(a),1.442,hardware,booster,.023)
    for k in range(8):
        a=(k+.5)*math.pi/4
        pipe('shield panel overlap seam',[(r*math.cos(a),r*math.sin(a),1.476) for r in (.43,.85,1.35,1.70)],.009,rim,booster)
    profile=[(.429,0),(.43,.025),(.421,.09),(.400,.23),(.377,.39),(.349,.55),(.322,.70),(.302,.85),(.283,1.01),(.265,1.16),(.249,1.30),(.235,1.44),(.231,1.54)]
    for k,(x,y) in enumerate(centers):
        ob=bpy.data.objects.new('Merlin-1D-'+str(k+1),None); bpy.context.collection.objects.link(ob)
        ob.parent=booster; ob.location=(x,y,0); ob.rotation_euler.z=(k-1)*math.pi/4 if k else 0
        ob['engine']=True
        ob['detail_source']='B1048 nozzle curve/ring/tube; B1060 aperture/neck cover. Local proportions approximate.'
        lathe('Merlin bell · exterior lower',profile[:8],metal,ob,64)
        lathe('Merlin bell · dark upper neck',profile[7:],neck,ob,64)
        lathe('Merlin bell · open dark inside',[(r-.010,z+.006) for r,z in reversed(profile)],dark,ob,64)
        # Conceal the unmodelled chamber; do not let a bottom view look through
        # the throat into the white tank. This dark baffle is a display device,
        # not an invented injector plate or a physical chamber reconstruction.
        lathe('Merlin throat · display-only dark occluder',[(0,1.541),(.225,1.541)],dark,ob,64)
        ring('Merlin bell · thin open lip',.429,.017,.011,metal,ob,64)
        # One prominent external ring with a bent external line, seen in B1048.
        ring('Merlin bell · external annular tube',.304,.86,.033,metal,ob,64)
        pipe('Merlin bell · visible short bent tube',[(.334,0,1.50),(.340,0,1.31),(.327,0,1.04),(.304,0,.90)],.031,neck,ob)
        ring('Merlin neck · upper interface rim',.322,1.438,.016,rim,ob,64)
        ring('Merlin neck · aperture trim',.34,1.474,.018,rim,ob,64)
        for j in range(12):
            a=math.tau*j/12
            fastener('aperture flange head',.365*math.cos(a),.365*math.sin(a),1.435,hardware,ob,.015)
        # Soft folded cover visible inside each aperture, represented geometrically.
        vertices=[]; faces=[]; rows=10; columns=64
        for j in range(rows+1):
            t=j/rows; z=1.38+.125*t
            for i in range(columns+1):
                a=math.tau*i/columns
                r=.264+.058*t + .004*math.sin(11*a+t*8)+.003*math.sin(19*a-t*11)
                vertices.append((r*math.cos(a),r*math.sin(a),z))
        for j in range(rows):
            for i in range(columns):
                a=j*(columns+1)+i; faces.append((a,a+1,a+columns+2,a+columns+1))
        mesh('Merlin neck · folded external cover',vertices,faces,blanket,ob,True)
    return deck
