# Falcon Heavy GOES-U photo references

Selected configuration: GOES-U, launched 2024-06-25, modern Falcon Heavy Block 5 with standard-looking payload fairing. These are local visual references only, not assets cleared for website rehosting. Inspected on 2026-09-10. All six selected original JPEGs were personally inspected. No 2018 demonstration or other mission image is in the selected set.

## Mission profile and confidence

- NOAA explicitly says that the two side boosters return to Landing Zones 1 and 2 and SpaceX expends the center booster: https://www.nesdis.noaa.gov/news/goes-u-road-launch (2024-01-17, launch-date editor update 2024-03-26; Liftoff section). This older preparatory article contains some other-mission example photos; do NOT use those photos as GOES-U references.
- NASA confirms actual near-simultaneous side-booster touchdowns on 2024-06-25: https://science.nasa.gov/blogs/goes/2024/06/25/falcon-heavy-side-boosters-stick-the-landing/
- The selected photos show a center core with no folded landing legs and no grid fins. Both side boosters carry folded black landing legs and grid fins below their rounded nosecones. This is a photo observation, consistent with the official recovery profile.
- NASA's GOES launch blog states 27 Merlin engines, and SpaceX states three nine-engine cores: https://science.nasa.gov/blogs/goes/ and https://new.spacex.com/vehicles/falcon-heavy . Do not claim that the supplied photos resolve all 27 nozzles; they do not.

## Selected six originals

### 1. Upper assembly close view

- Local: `/tmp/fh-photo-refs/nasa-goes-u-0005-original.jpg`
- Size: 2000 x 3000.
- Direct image: https://images-assets.nasa.gov/image/KSC-20240624-PH-SPX01_0005/KSC-20240624-PH-SPX01_0005~orig.jpg
- Record: https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0005
- NASA metadata credit: SpaceX. Date: 2024-06-24, LC-39A, GOES-U Rollout for Launch.
- Best for rounded side nosecone profile, fin lattice silhouette/folded posture, top white inter-core cross-member and short oblique braces, black external raceway covers, central upper-stage/interstage paint regions and fairing shape.
- The broad arms beside/below the fairing and rear tower are ground equipment. Do not attach them to the flying model.

### 2. Low-angle front, lower body and folded side legs

- Local: `/tmp/fh-photo-refs/nasa-goes-u-0010-original.jpg`
- Size: 2000 x 3000.
- Direct image: https://images-assets.nasa.gov/image/KSC-20240624-PH-SPX01_0010/KSC-20240624-PH-SPX01_0010~orig.jpg
- Record: https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0010
- NASA metadata credit: SpaceX. Date: 2024-06-24.
- Best for bare center-core lower cylinder, black folded side legs with tapered/rounded upper ends, three longitudinal external raceways, side-to-core gaps, and visible small braces under the upper cross-member.
- Lower inner attachment region is partly hidden behind the legs, cores and launch-mount hardware. The brown/gray triangular structures outside the side cores at the base are not automatically flight hardware. No complete 27-engine tail view.
- This is the higher-resolution official counterpart of preliminary Ben Cooper `goes-u-27-pad-night.jpg`; use this original instead.

### 3. Near-frontal full stack

- Local: `/tmp/fh-photo-refs/nasa-goes-u-0006-original.jpg`
- Size: 3000 x 2000.
- Direct image: https://images-assets.nasa.gov/image/KSC-20240624-PH-SPX01_0006/KSC-20240624-PH-SPX01_0006~orig.jpg
- Record: https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0006
- NASA metadata credit: SpaceX. Date: 2024-06-24.
- Best for overall proportions and symmetry without strong low-angle perspective. Center has no landing legs or grid fins; side fin height is below each nosecone shoulder. Ground tower/arms remain visible, so compare with image 6 before assigning any cross-member to the flight vehicle.

### 4. Horizontal broadside rollout

- Local: `/tmp/fh-photo-refs/nasa-goes-u-0003-original.jpg`
- Size: 3000 x 2000.
- Direct image: https://images-assets.nasa.gov/image/KSC-20240624-PH-SPX01_0003/KSC-20240624-PH-SPX01_0003~orig.jpg
- Record: https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0003
- NASA metadata credit: SpaceX. Date: 2024-06-24.
- Best for long folded leg profiles, side-booster nosecone curvature, compact folded grid fins, top/bottom raceway silhouettes and relative body lengths. Tail bells are covered/occluded by transport-launch hardware.
- Same scene previously obtained from Space.com as `spacex-goes-u-rollout-wide.jpg`; prefer this official original.

### 5. Horizontal front three-quarter rollout

- Local: `/tmp/fh-photo-refs/nasa-goes-u-0002-original.jpg`
- Size: 3000 x 2000.
- Direct image: https://images-assets.nasa.gov/image/KSC-20240624-PH-SPX01_0002/KSC-20240624-PH-SPX01_0002~orig.jpg
- Record: https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0002
- NASA metadata credit: SpaceX. Date: 2024-06-24.
- Best for fairing ogive/taper, split seam, panel texture, side nosecone curvature and distinguishing cradle/erector hardware from the rocket.
- Fairing's nose has a dark metallic-looking patch in this ground image. Its material/function is not established. In the flight photo the tip reads white, so do not confidently add a permanent dark metallic flight nose based on this image alone. Lighting, view direction or ground protection may explain the difference; not resolved here.

### 6. Free-flight near-frontal launch

- Local: `/tmp/fh-photo-refs/noaa-goes-u-launch-original.jpg`
- Size: 2663 x 4002.
- Direct image: https://live.staticflickr.com/65535/53828532278_26a08b9209_o.jpg
- Record: https://www.flickr.com/photos/noaasatellites/53828532278
- Publisher: NOAA Satellites. Date: 2024-06-25. Photo credit: NASA/Kevin O'Connell & Kevin Davies. Flickr marks this photograph public domain; the task still limits its use to local reference.
- Best for verifying which upper cross-members fly with the vehicle. A thin white transverse member remains just below the side-nosecone shoulders, with smaller underlying strut forms; broad fairing-level erector arms are gone. Flight fairing reads white. Smoke, heat distortion and distance limit fine-detail inference.

## Modeling boundaries

- Appropriate changes supported by the photos: two side-recovery boosters and bare center core; rounded side nosecones without a Falcon 9-style black cylindrical interstage above them; black stowed side legs; folded lattice fins below nosecone shoulder; subtle exterior raceways; a visible upper inter-core attachment assembly.
- Do not mistake the ground erector's broad fairing arms, rear truss, access structures or mount at the base for flight hardware.
- Lower attachment hardware exact geometry, pin/hinge internals, material specification, and 27-nozzle tail layout were NOT resolved in these mission photographs. Model only conservative externally visible features or label any generic geometry as schematic.
- The small inter-core gaps and fine white braces are partly obscured. Photos support their presence, not dimensionally exact CAD.
- The center section carrying the FH mark and US flag is WHITE. The broad gray band is ABOVE it. Do not copy Falcon 9's black interstage coloring or label that gray band as the interstage solely from its color. NASA confirms GOES-U coasted for just under four hours before its final burn: https://science.nasa.gov/blogs/goes/2024/06/25/goes-u-satellite-now-in-coast-phase/ . A GOES-U-specific official text naming the gray-band kit was not found here; photo-consistent placement is secure, precise kit naming/function is outside this evidence set.
- Final set is the six files named above. Other JPEGs in this directory are preliminary lower-resolution duplicates or supplemental views, not additional mission variants.

## Retrieval provenance

- NASA search metadata saved as `nasa-images-search.json` from https://images-api.nasa.gov/search?q=GOES-U&media_type=image&page_size=100 . It contains official dates, descriptions, IDs and photographer attribution.
- NASA collection sample saved as `nasa-rollout-9-collection.json`; original JPEG URLs followed the verified image-asset entries and downloaded successfully.
- NOAA Flickr original-size page saved as `noaa-flickr-launch-sizes.html`.
- Preliminary photographer album saved as `goes-u-page.html`: https://www.launchphotography.com/GOES-U . Copyright Ben Cooper / Launch Photography; not cleared for rehosting.
