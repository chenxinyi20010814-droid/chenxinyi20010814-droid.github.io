# Starship V3 精修样板

Starship V3 精修模型已于 2026-09-10 收录到正式 Flight Atlas。以下保留建模依据与验收记录。

## 构型与资料

采用既有 V3：总高 124 m、Super Heavy 72 m、Ship 52 m、主体直径 9 m。总包络沿用 [SpaceX 产品参数](https://www.spacex.com/vehicles/starship/)；外形统一参考 B19 / S39，不混入 V1/V2 密孔热分离环、四格栅翼或旧型发动机大包覆罩。

根本依据为 [SpaceX：Introducing Starship V3，2026-05-12](https://www.spacex.com/updates/#starship-v3)。正文核对过三片下移格栅翼、集成热分离、四个背风对接锥、Raptor 3 与尾部包覆方式变化。照片均实际打开查看；不是仅凭搜索摘要制作。

主要实拍：

- [B19 三片格栅翼及顶部桁架](https://sxcontent9668.azureedge.us/cms-assets/assets/B19_Transport_2603083576_1cc29f2c4f.jpg)：开孔格网、齿状外缘、翼根圆形连接。
- [B19 户外吊装](https://sxcontent9668.azureedge.us/cms-assets/assets/B19_Lift_Pad2_2603083611_083bb17256.jpg)：开放桁架及其后方穹顶。
- [S39 迎风面静点](https://sxcontent9668.azureedge.us/cms-assets/assets/S39_6_Engine_Static_Fire_04142600114_d9f1acc588.jpg)：黑瓦、船头、前后襟翼与尾裙。
- [V3 全箭湿演练](https://sxcontent9668.azureedge.us/cms-assets/assets/20260511_Wet_Dress_Actual_2_259bcb3ae9.jpg)：整箭背风外形、级间连续关系；不照搬蒸汽或塔架。
- [Raptor 3 单机官方照片](https://sxcontent9668.azureedge.us/cms-assets/assets/Raptor_V3_Mc_G_20240802_1w3a8289_daa3a51ef3.jpg)：喷管、上部紧凑壳体及主要外露弯管；未复制运输支架和保护盖。
- S39 正迎风与背风成对照片来自 [SpaceX 2026-02-26 原帖](https://x.com/SpaceX/status/2027143801949618205)。本次原帖访问被拒，实际看的是[有明确 SpaceX 署名的转载图片](https://www.teslaoracle.com/2026/02/27/spacex-prepares-for-flight-12-starship-39-prelaunch-testing-at-starbase-the-first-v3-starship-starbase-updates/)，只采纳照片可见形态，不采纳二手参数推断。

图片仅作本地参考，未打入站点或源文件下载包。官方 V3 旋转视频属于渲染，没有冒称实拍。

## 本轮新增

- 迎风筒身及四片襟翼使用合批六边形瓦面，瓦缝具有真实几何间隙；鼻尖少量区域用小型重复纹理。
- 前襟翼向背风方向后移；补厚边、翼根覆盖、分段连接及背面接缝。
- 裸露钢壳、浅焊缝、轻微钢板反射起伏与陶瓷材质分开处理。
- 三片开孔格栅翼、齿状外缘、翼根轴环；集成热分离顶部环、V 形桁架和可见穹顶。
- 33 台一级发动机和 3 海平面＋3 真空上面级发动机保留独立分组，开口喷管、唇缘、上部外部轮廓分别建模。
- 四处背风对接接口只做外部环形轮廓；没有虚构内部对接机构。

## 精度边界

官方事实：总体尺寸、发动机与控制面数量、V3 结构变化。

照片近似：船头曲线、分段长度、约 3.6 m 热分离桁架、约 1.8 m 焊缝间距、格栅翼角距与单元数、襟翼钟向、接口位置，以及发动机环半径。瓦片约 0.30 m 的视觉排布和模型瓦片数不代表实际安装数量；鼻部铺排不是专有真实瓦片地图。

完整 B19 33 台发动机装机底视尚未取得可检查原图。尾部薄隔热面开孔、泵体轮廓和连接颈采用保守教学近似；不称工程级复原。暗色遮挡面只防止未建模储箱被看成贯通空筒，不代表已知舱底工程图。无推进剂罐剖面、管路网络、内部执行器或有效载荷。

## 文件与维护

- `starship-v3.blend`：可编辑原件，完整零件层级；Blender 4.5.9 LTS。
- `build_starship.py` 与 `booster_detail.py`：可重复构建脚本，米制 Z-up；导出自动转换成网页 Y-up。
- `public/models/starship-v3.glb`：8,344,080 字节，340,940 三角面、164 网格，3 张小型内嵌材质图。
- `public/models/starship-v3-editable.zip`：可编辑源包，不含参考摄影版权图片。

Ship 分解偏移 18 m 仅为展示；六台发动机随 Ship 移动，热分离段及格栅翼留在助推器。未增加自动旋转。两种主题、部件点选、紧凑型号选择和同尺比较沿用原网站。
