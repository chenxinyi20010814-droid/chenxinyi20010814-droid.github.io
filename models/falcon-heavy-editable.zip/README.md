# Falcon Heavy 精修样板

Falcon Heavy 精修模型已于 2026-09-10 收录到正式 Flight Atlas；F9 与 Starship 已验收资产保持原样。

## 选定构型

Falcon Heavy Block 5，标准整流罩；外形统一参考 **GOES-U，2024-06-25**。两枚侧助推器带四腿四翼，中央芯级无回收硬件。NOAA 说明中央芯级消耗，NASA 确认两侧在 LZ-1/LZ-2 着陆。不是 2018 首飞构型，也不是三芯全消耗的 Europa Clipper。

官方产品尺度：总高 70 m、单芯直径 3.66 m、总宽 12.2 m；标准整流罩直径 5.2 m。继承 2025 Falcon 手册 13.2 m 标准整流罩包络。网站质量、推力、运力属于官方产品参数，不代表 GOES-U 的任务实测起飞质量或实载。

## 依据

- [SpaceX Falcon Heavy 产品参数](https://www.spacex.com/vehicles/falcon-heavy/)
- [SpaceX Falcon 用户手册，2025-05](https://www.spacex.com/assets/media/falcon-users-guide-2025-05-09.pdf)
- [NOAA：GOES-U Road to Launch，2024-01-17，3月更新](https://www.nesdis.noaa.gov/news/goes-u-road-launch)：Liftoff 段明确中心消耗、两侧回收。该文部分配图是别次任务，没有当成 GOES-U 建模照片。
- [NASA：两枚侧助推器着陆，2024-06-25](https://science.nasa.gov/blogs/goes/2024/06/25/falcon-heavy-side-boosters-stick-the-landing/)
- [NASA/SpaceX 上部特写，2024-06-24](https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0005)：鼻锥、折叠翼、上连接与中央黑白分区。
- [NASA/SpaceX 低角度前视](https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0010)：无腿中央芯级、两侧折叠腿和浅外部线槽。
- [NASA/SpaceX 全箭](https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0006)及[水平侧面](https://images.nasa.gov/details/KSC-20240624-PH-SPX01_0003)：外形比例与侧鼻锥轮廓。
- [NOAA 发布的离塔飞行照，2024-06-25](https://www.flickr.com/photos/noaasatellites/53828532278)：区分飞行连接件与地面抱持臂。

图片均为本地核对依据，不将参考摄影打入站点或下载包。尾部和腿部共通零件沿用已验收 F9 Block 5 精修资产，其原始依据在 `../falcon9/README.md`。本轮没有取得 GOES-U 的无遮挡 27 喷管装机底视，因此尾部只作共通 Merlin 几何和排列的教学复原。

## 新增与保留

- 新建两枚圆润侧鼻锥，移除侧助推器上不应有的 Falcon 9 级间段。
- 中央芯级无腿无翼；两侧共 8 条收拢腿、8 片开孔栅格翼。
- 三芯各 9 台海平面 Merlin，独立中央二级有 1 台真空 Merlin。喷管开口、唇缘、颈部轮廓、短弯管和尾部护板沿用 F9 实拍精修基础。
- 按同任务照片补上部连接横梁、短斜撑及有限的下部连接轮廓；未加地面塔架、整流罩抱持臂。
- 材质区分白漆、深色涂覆回收件、喷管金属和连接表面。SpaceX 字标由既有网页贴花绘制；保留干净代表性外观，不复刻 GOES-U 客户徽章。
- 米制无缩放。上面级连同真空喷管上移，级间段留在中央芯级；侧助推器各自带走其连接件一侧，不留横穿分解间隙的长杆。
- 保留手动拖动、缩放、深浅皮肤、点选和构造分解；无地面网格，无自动旋转。本轮不增添 FH 着陆动画。

## 精度与限制

鼻锥曲线、各段长度、芯间距、连接件外形与钟向、翼格间距、腿部铰接和表面缝线都是照片估计，不是官方 CAD 或工程图。外部深色线槽仅还原可见外形，不推断其隐藏管线用途；它们位于实拍对应的一面，不覆盖所有视角。

未重建储箱剖面、连接销内部释放机构、完整发动机管路或有效载荷。下连接区在资料中被遮挡，保留简化外部轮廓；不以任意螺丝或管线填充。整流罩运输图的深色鼻端成因未确认，不当永久飞行材料处理。

## 文件

- `falcon-heavy.blend`：未合批、可继续编辑的原件。
- `build_falcon_heavy.py`：可重建脚本；原始 F9 `.blend` 为只读输入，支持 `--base` 路径和 `--output` 独立目录。下载源包包含输入副本。
- `asset-stats.json`：文件大小、三角面、语义标记及合批统计。
- `public/models/falcon-heavy.glb`：网页资产；绘制网格按部件和材质合批，28 个引擎/8 翼/8 腿位置标记仍保留，可编辑源保持逐件层级。
- `scripts/validate-falcon-heavy-asset.mjs`：米制包络、部件点选、数量、遮挡、分解归属、复原、加载预算检查。

网页近景按钮只是相机取景，不会改变模型比例。构造分解的距离为教学展示，不代表真实飞行时序。
