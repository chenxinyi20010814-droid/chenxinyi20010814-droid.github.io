"""New Glenn 9x4: official concept exterior reconstruction, not engineering CAD.

Run with Blender 4.5+:
  Blender -b --factory-startup --python build_new_glenn_9x4.py
The editable source is metre/Z-up; GLB is metre/Y-up with ground at y=0.
No logos, mission marks, flight wear, internal plumbing or payload are invented.
Only general mesh helpers are adapted from Flight Atlas's New Glenn 7x2 source.
Every 9x4 station, tail, strake, collar and engine layout is independently built.
"""
import bpy, math, json, random
from pathlib import Path
from mathutils import Vector

OUT=Path(__file__).resolve().parent
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
random.seed(94)
H=121.9; CORE=3.9; UPPER_Z=71.0; FAIRING_Z=98.0

def material(name,c,metal=0,rough=.5):
    m=bpy.data.materials.new(name);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*c,1)
    p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
    m.diffuse_color=(*c,1);return m
white=material('NG clean warm white exterior',(.79,.805,.80),.16,.40)
trim=material('NG light interface metal',(.66,.695,.695),.28,.42)
liner=material('Representative fairing interior',(.40,.405,.385),.03,.83)
silver=material('9x4 visible satin metal',(.44,.49,.51),.76,.34)
blue=material('NG lower body blue paint',(.011,.055,.31),.15,.32)
edge=material('9x4 thermal panel edge',(.25,.219,.161),.30,.65)
seam=material('Restrained recessed seam',(.13,.15,.16),.18,.74)
dark=material('Covered engine bay',(.018,.026,.032),.40,.51)
bell=material('Nozzle nickel alloy exterior',(.28,.31,.32),.83,.32)
inside=material('Nozzle interior dark metal',(.047,.052,.055),.50,.62)
lip=material('Machined nozzle exit lip',(.52,.56,.57),.89,.26)
thermal=[material('9x4 clean thermal panel %02d'%i,(.276+s,.213+s*.7,.124+s*.45),.28,.71) for i,s in enumerate([0,.010,-.008,.005,-.004])]
foil=[material('9x4 angular aft metallic cover %02d'%i,(.18+i*.013,.22+i*.014,.25+i*.015),.72,.43) for i in range(4)]

def empty(name,parent=None,part=None,loc=(0,0,0)):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.parent=parent;o.location=loc
    if part:o['part']=part
    return o
root=empty('NG');root['vehicle']='newglenn9x4';root['variant']='refined'
root['configuration']='New Glenn 9x4 official concept exterior; no flown configuration claimed'
root['source_precision']='Official 8.7 m fairing and 9/4 engine counts; 121.9 m display scale, other dimensions concept-estimated'
root['height_m']=H;root['body_diameter_m']=7.8;root['body_diameter_status']='concept image estimate'
root['fairing_diameter_m']=8.7;root['pose']='assembled launch; concept landing shells stowed'
booster=empty('booster',root,'booster');recovery=empty('recovery',booster,'recovery')
upper=empty('upper',root,'upper',(0,0,UPPER_Z));fairing=empty('fairing',root,'fairing',(0,0,FAIRING_Z))
left=empty('fairing-left',fairing,'fairing');left['split_sign']=-1
right=empty('fairing-right',fairing,'fairing');right['split_sign']=1
booster['be4_count']=9;booster['engine_configuration']='BE-4 Block 2, outer eight plus central one'
recovery['leg_count']=6;recovery['control_fin_count']=4;recovery['strake_count']=2
recovery['detail_precision']='Six stowed shells and four fins inferred from official concept views and family layout; not an engineering disclosure'
upper['be3u_count']=4;upper['engine_concealed_in_assembled_pose']=True

def partof(o):
    while o:
        if o.get('part'):return o['part']
        o=o.parent
    raise RuntimeError('Missing semantic part')
def mesh(name,verts,faces,mat,parent,smooth=True):
    d=bpy.data.meshes.new(name);d.from_pydata(verts,[],faces);d.update()
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.parent=parent
    o['part']=partof(parent);d.materials.append(mat)
    for p in d.polygons:p.use_smooth=smooth
    return o
def lathe(name,profile,mat,parent,n=128,a0=0,span=math.tau):
    v=[(r*math.cos(a0+span*i/n),r*math.sin(a0+span*i/n),z) for r,z in profile for i in range(n+1)]
    f=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=j*(n+1)+i;f.append((a,a+1,a+n+2,a+n+1))
    return mesh(name,v,f,mat,parent)
def ring(name,r,z,w,mat,parent,n=96):
    return lathe(name,[(r+w*math.cos(i*math.tau/6),z+w*math.sin(i*math.tau/6)) for i in range(7)],mat,parent,n)
def radial(a,r,z):return (r*math.cos(a),r*math.sin(a),z)
def rod(name,a,b,r,mat,parent,n=12):
    a,b=Vector(a),Vector(b)
    o=lathe(name,[(0,0),(r,0),(r,(b-a).length),(0,(b-a).length)],mat,parent,n)
    o.location=a;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def beam(name,a,b,w,d,mat,parent,bevel=0):
    a,b=Vector(a),Vector(b);bpy.ops.mesh.primitive_cube_add(size=1)
    o=bpy.context.object;o.name=name;o.parent=parent;o.location=(a+b)/2
    o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();o.scale=(w,d,(b-a).length)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(mat);o['part']=partof(parent)
    if bevel:
        mod=o.modifiers.new('Visible edge radius','BEVEL');mod.width=bevel;mod.segments=2
        bpy.ops.object.modifier_apply(modifier=mod.name)
    return o
def plate(name,outline,t,mat,parent):
    v=[(r,-t/2,z) for r,z in outline]+[(r,t/2,z) for r,z in outline];n=len(outline)
    f=[tuple(reversed(range(n))),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return mesh(name,v,f,mat,parent,False)
def patch(name,z0,z1,r0,r1,a0,a1,mat,parent,n=8):
    return lathe(name,[(r0,z0),(r1,z1)],mat,parent,n,a0,a1-a0)

# INDEPENDENT 9x4 stations from the official evolution artwork.
# Concept's logo-facing tank is intentionally uninterrupted by dark long strips.
lathe('9x4 first stage smooth tank wall',[(CORE,10.35),(CORE,58.70)],white,booster,192)
for z in [10.58,20.1,39.6,58.48]:ring('First stage circumferential joint',CORE+.002,z,.011,trim,booster,160)
v=[];f=[];n=192
for row in range(2):
    for j in range(n+1):
        a=j*math.tau/n;z=10.40 if row==0 else 11.2+1.17*abs(math.sin(a))
        v.append(radial(a,CORE+.008,z))
for j in range(n):f.append((j,j+1,n+j+2,n+j+1))
mesh('Concept blue arched paint boundary',v,f,blue,booster)

# The aft barrel is wider than the tank and nearly cylindrical, not a cone.
tail_profile=[(4.16,.55),(4.26,1.20),(4.30,3.60),(4.26,6.20),(4.10,8.20),(CORE,10.44)]
def tailr(z):
    for (r0,z0),(r1,z1) in zip(tail_profile,tail_profile[1:]):
        if z0<=z<=z1:return r0+(r1-r0)*(z-z0)/(z1-z0)
    return tail_profile[0][0] if z<.55 else CORE
lathe('Concept aft thermal barrel substrate',tail_profile,thermal[0],booster,160)
lathe('Aft dark inside lining',[(4.03,.56),(4.03,4.7)],dark,booster,128)
rows=[.65,2.5,4.5,6.5,8.45,10.40]
for row,(z0,z1) in enumerate(zip(rows,rows[1:])):
    for j in range(24):
        a0=j*math.tau/24+.0015;a1=(j+1)*math.tau/24-.0015
        patch('Clean aft thermal panel',z0+.012,z1-.012,tailr(z0)+.008,tailr(z1)+.008,a0,a1,thermal[(j+2*row)%5],booster)
for z in rows[1:-1]:ring('Fine aft transverse panel join',tailr(z)+.009,z,.009,edge,booster,160)
ring('White aft lower rolled rim',4.17,.60,.065,trim,booster,160)

# Angular six stowed leg-shell envelopes visible in the concept. No hydraulic
# internals or 7x2 photographed hinges/fastener pattern are transferred.
leg_half_outline=[(-.99,1.0),(-1.06,2.95),(-.89,7.55),(-.50,9.05),(-.12,9.67),(0,9.70),(0,3.12),(-.46,2.2),(-.64,1.15)]
for k in range(6):
    g=empty('landing-leg-%02d'%(k+1),recovery,'recovery');g.rotation_euler.z=math.pi/6+k*math.tau/6
    g['leg']=True;g['pose']='stowed';g['detail_precision']='Concept envelope only; concealed mechanism omitted'
    for side in [-1,1]:
        # Two folded outer panels meet at a shallow central ridge. The lower
        # arch is genuinely open, with two separate toes, as in the concept.
        outline=[(w*side,z) for w,z in leg_half_outline]
        def shellpoint(w,z,offset=0):return (tailr(z)+.18+.25*(1-abs(w)/1.06)+offset,w,z)
        v=[shellpoint(w,z,off) for off in [-.065,0] for w,z in outline];nn=len(outline)
        f=[tuple(reversed(range(nn))),tuple(range(nn,nn*2))]+[(j,(j+1)%nn,(j+1)%nn+nn,j+nn) for j in range(nn)]
        shell=mesh('Wide forked concept landing shell',v,f,silver,g,False)
        mod=shell.modifiers.new('Folded shell face triangulation','TRIANGULATE');bpy.context.view_layer.objects.active=shell;bpy.ops.object.modifier_apply(modifier=mod.name)
        for (w0,z0),(w1,z1) in zip(outline,outline[1:]+outline[:1]):
            if abs(w0)+abs(w1)>.01:rod('Forked shell perimeter seal',shellpoint(w0,z0,.008),shellpoint(w1,z1,.008),.024,trim,g,8)
        beam('Concept fork toe shoe',(tailr(1.10)+.23,side*.81-.13,1.08),(tailr(1.10)+.23,side*.81+.13,1.08),.27,.17,dark,g,.028)
    # Only the small exterior pivot cover visible near the shoulder is shown.
    rod('Exterior shoulder pivot cover',(tailr(8.65)+.17,-.12,8.65),(tailr(8.65)+.29,-.12,8.65),.16,dark,g,20)

# Shorter, wider strakes than 7x2. These stations are NOT a uniform scaling.
strake_outline=[(3.89,8.9),(6.80,8.55),(8.04,14.8),(8.04,24.0),(3.91,32.7)]
for k,a in enumerate([0,math.pi]):
    g=empty('strake-%02d'%(k+1),recovery,'recovery');g.rotation_euler.z=a;g['strake']=True
    plate('Broad swept concept strake',strake_outline,.19,thermal[0],g)
    for (r0,z0),(r1,z1) in zip(strake_outline,strake_outline[1:]+strake_outline[:1]):
        rod('Strake metallic perimeter cap',(r0,0,z0),(r1,0,z1),.048,trim,g,8)
    for z in [11.3,14.8,18.3,21.8,25.3,28.8]:
        ints=[]
        for (r0,z0),(r1,z1) in zip(strake_outline,strake_outline[1:]+strake_outline[:1]):
            if min(z0,z1)<=z<=max(z0,z1) and z0!=z1:ints.append(r0+(r1-r0)*(z-z0)/(z1-z0))
        if len(ints)>1:
            for side in [-1,1]:rod('Strake subtle panel join',(min(ints),side*.097,z),(max(ints),side*.097,z),.008,edge,g,6)
    rod('Strake shallow root fillet',(3.92,0,10.5),(3.92,0,31.2),.09,trim,g,12)

# Brown interstage followed by a SHORT WHITE collar, distinct in the concept.
lathe('9x4 interstage thermal substrate',[(CORE,58.60),(CORE,68.82)],thermal[0],booster,160)
lathe('Interstage hollow inner lining',[(3.82,58.60),(3.82,71.00)],dark,booster,128)
for row,(z0,z1) in enumerate([(58.66,61.2),(61.2,63.75),(63.75,66.30),(66.30,68.76)]):
    for j in range(24):
        a0=j*math.tau/24+.0015;a1=(j+1)*math.tau/24-.0015
        patch('Clean concept interstage panel',z0+.012,z1-.012,CORE+.010,CORE+.010,a0,a1,thermal[(j+row)%5],booster)
    ring('Interstage thin transverse joint',CORE+.012,z0,.010,edge,booster,160)
lathe('Short white interstage collar',[(CORE,68.80),(CORE,70.96)],white,booster,192)
for z in [68.83,69.08,70.86,70.99]:ring('White collar circumferential lip',CORE+.012,z,.033,trim,booster,160)
for j in range(96):
    a=j*math.tau/96
    patch('Collar shallow vertical fluting',69.16,70.77,CORE+.010,CORE+.010,a-.0027,a+.0027,trim,booster,1)
for k in range(4):
    g=empty('control-fin-%02d'%(k+1),recovery,'recovery');g.rotation_euler.z=math.pi/4+k*math.pi/2;g['controlFin']=True
    outline=[(3.88,60.30),(5.85,62.02),(5.85,64.00),(3.88,65.45)]
    plate('Swept concept control fin',outline,.18,thermal[1],g)
    for (r0,z0),(r1,z1) in zip(outline,outline[1:]+outline[:1]):rod('Control fin light perimeter',(r0,0,z0),(r1,0,z1),.043,trim,g,8)
    rod('Control fin root hinge envelope',(4.0,0,61.0),(4.0,0,64.75),.105,dark,g,16)
    for z in [62.1,63.0,63.9]:
        for side in [-1,1]:rod('Control fin restrained panel join',(4.03,side*.092,z),(5.75,side*.092,z),.008,edge,g,6)

def engine(name,parent,x,y,z,h,exit_r,kind):
    g=empty(name,parent,partof(parent),(x,y,z));g['engine']=kind
    g['precision']='Externally visible nozzle envelope from concept; no turbopump/plumbing reconstruction'
    prof=[];steps=30
    for i in range(steps+1):
        t=i/steps;r=exit_r*(.19+.81*(1-t)**.64);prof.append((r,h*.85*t))
    prof +=[(exit_r*.20,h*.94),(exit_r*.25,h)]
    lathe(kind+' smooth outer bell',prof,bell,g,80)
    lathe(kind+' dark inner bell',[(max(.05,r-.038),zz+.022) for r,zz in reversed(prof[:steps+1])],inside,g,80)
    ring(kind+' polished exit lip',exit_r-.012,.030,.024,lip,g,96)
    for t in [.30,.53,.72]:
        rr=exit_r*(.19+.81*(1-t)**.64);ring(kind+' shallow nozzle reinforcement',rr+.006,h*.85*t,.010,bell,g,64)
    lathe(kind+' covered attachment neck',[(exit_r*.245,h*.88),(exit_r*.26,h+.24)],dark,g,32)
    lathe(kind+' black throat closure',[(exit_r*.18,h*.855),(0,h*.855)],inside,g,32)
    return g
centres=[(2.74*math.cos(k*math.tau/8),2.74*math.sin(k*math.tau/8)) for k in range(8)]+[(0,0)]
for k,(x,y) in enumerate(centres):engine('BE-4-Block2-%02d'%(k+1),booster,x,y,0,3.9,1.005,'BE-4 Block 2')

# The aft concept specifically shows an angular metallic web around the nine
# nozzles. Real holes leave each exhaust open; no disk crosses a nozzle mouth.
bpy.ops.mesh.primitive_cylinder_add(vertices=128,radius=4.10,depth=.14,location=(0,0,.44))
web=bpy.context.object;web.name='Nine-opening aft metallic web';web.parent=booster;web['part']='booster'
for m in foil:web.data.materials.append(m)
for x,y in centres:
    bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=1.045,depth=2,location=(x,y,.44))
    cutter=bpy.context.object;bpy.context.view_layer.objects.active=web
    mod=web.modifiers.new('Open nozzle aperture','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter
    bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cutter,do_unlink=True)
mod=web.modifiers.new('Triangulated metallic cover facets','TRIANGULATE')
bpy.context.view_layer.objects.active=web;bpy.ops.object.modifier_apply(modifier=mod.name)
for p in web.data.polygons:p.material_index=(p.index*7)%4;p.use_smooth=False
for j,(x,y) in enumerate(centres):
    g=empty('Aft octagonal nozzle surround %02d'%j,booster,'booster',(x,y,0))
    # Slight eight-sided outer envelope with a smooth circular inner opening.
    v=[]
    for radius,z,polygon in [(1.034,.25,False),(1.062,.23,True),(1.072,.39,True)]:
        for k in range(64):
            a=k*math.tau/64
            rr=radius/(math.cos((a+math.pi/8)%(math.pi/4)-math.pi/8)) if polygon else radius
            v.append((rr*math.cos(a),rr*math.sin(a),z))
    f=[(r*64+k,r*64+(k+1)%64,(r+1)*64+(k+1)%64,(r+1)*64+k) for r in range(2) for k in range(64)]
    mesh('Angular metal thermal nozzle surround',v,f,foil[j%4],g,False)

# 27 m exposed upper stage with four engines contained inside the interstage.
lathe('9x4 upper smooth white stage wall',[(CORE,0),(CORE,27.0)],white,upper,192)
bulk=lathe('Representative closed forward stage envelope',[(3.85,26.72),(3.38,27.08),(2.5,27.45),(1.4,27.69),(0,27.78)],trim,upper,128)
bulk['detail_precision']='Simple closed illustrative envelope; no payload adapter or tank internals claimed'
lathe('Upper covered lower envelope',[(.6,-1.15),(2.80,-.55),(3.79,-.16),(3.83,.07)],dark,upper,128)
lathe('Upper dark aft nozzle shroud',[(3.80,-1.60),(3.84,-.8),(3.84,.05)],dark,upper,128)
for k,(x,y) in enumerate([(-1.50,-1.50),(1.50,-1.50),(1.50,1.50),(-1.50,1.50)]):
    engine('BE-3U-%02d'%(k+1),upper,x,y,-6.60,4.85,1.40,'BE-3U')
    rod('BE-3U covered mounting neck',(x,y,-1.85),(x,y,-1.05),.34,dark,upper,20)
for z in [0,.25,1.35,7.6,21.5,26.72,26.95]:ring('Upper circumferential interface',CORE+.004,z,.021,trim,upper,160)
for centre in [1.50,22.2,25.3]:
    for i in range(5):
        z=centre+i*.085
        lathe('Upper subtle band micro rib',[(CORE,z),(CORE+.014,z+.026),(CORE,z+.050)],trim,upper,144)
# Two short teardrop-shaped covers are visible low on the concept upper stage.
for a in [-math.pi/2-.48,math.pi/2-.48]:
    g=empty('Upper concept exterior fitting',upper,'upper');g.rotation_euler.z=a
    plate('Upper tapered short service cover',[(CORE,2.4),(CORE+.29,2.45),(CORE+.34,4.9),(CORE+.19,6.3),(CORE,7.0)],.44,trim,g)
    rod('Upper short exterior fitting stem',(CORE+.12,0,.5),(CORE+.17,0,2.65),.095,silver,g,16)
for j in range(12):
    a=j*math.tau/12
    rod('Upper small flush circular access fitting',radial(a,CORE+.008,.65),radial(a,CORE+.028,.65),.076,trim,upper,12)

# 8.7 m fairing: flared shoulder, long barrel and rounded 9.9 m nose.
profile=[(CORE,0),(4.04,.43),(4.24,1.14),(4.35,1.78),(4.35,14.0)]
for i in range(1,57):
    # Official concept is a pointed ogive, not the 7x2 source's half-ellipse.
    # The smooth tangent at the barrel transitions to a short rounded tip.
    t=i/56;profile.append((4.35*(1-t**1.8),14.0+9.9*t))
for half,a0 in [(right,-math.pi/2),(left,math.pi/2)]:
    half['pose']='closed';half['inner_liner']='Representative thin liner, not disclosed engineering detail'
    lathe('9x4 fairing outer shell',profile,white,half,80,a0,math.pi)
    ip=[(max(0,r-.066),z+.010 if z<23 else z-.03) for r,z in profile]
    lathe('Fairing thin inside liner',list(reversed(ip)),liner,half,80,a0,math.pi)
    for a in [a0,a0+math.pi]:
        v=[radial(a,r,z) for pp in [profile,ip] for r,z in pp];nn=len(profile)
        mesh('Fairing longitudinal split rim',v,[(i,i+1,i+1+nn,i+nn) for i in range(nn-1)],trim,half)
        for (r0,z0),(r1,z1) in zip(profile,profile[1:]):
            if z1<23.89:rod('Fairing very fine split seam',radial(a,r0+.003,z0),radial(a,r1+.003,z1),.010,trim,half,6)
    lathe('Fairing lower separation flange',[(3.86,.015),(3.93,.015),(3.97,.15),(3.91,.19)],trim,half,80,a0,math.pi)
    for z,r in [(1.8,4.354),(14.0,4.354)]:patch('Fairing subtle transverse shell joint',z-.007,z+.007,r,r,a0,a0+math.pi,trim,half,80)
    # The overhead fairing concept has a dark band at a different station than
    # the full evolution artwork. Do not combine conflicting concepts. Primary
    # full-vehicle artwork wins here: keep only a fine, pale low shell joint.
    patch('Fairing pale lower shell joint',2.49,2.51,4.356,4.356,a0,a0+math.pi,trim,half,80)
    for j in range(6):
        a=a0+(j+.5)*math.pi/6
        g=empty('Fairing small fastening tab',half,'fairing');g.rotation_euler.z=a
        beam('Fairing flush light fastening tab',(4.366,0,2.39),(4.366,0,2.66),.20,.019,trim,g,.012)
        rod('Fairing low circular flush port',radial(a,4.352,3.25),radial(a,4.371,3.25),.105,trim,half,16)

# Review studio is source-only. Web asset has no cameras, lights or textures.
def camera(name,loc,target,scale):
    d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o)
    o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    d.type='ORTHO';d.ortho_scale=scale;d.lens=55;return o
cam=camera('QA full assembly',(115,-185,88),(0,0,60.95),135)
camera('QA aft detail',(34,-51,18),(0,0,13.5),33)
camera('QA upper assembly',(37,-60,91),(0,0,82.0),46)
camera('QA nine engine underside',(11,-15,-25),(0,0,1.2),13)
camera('QA separated four engine stage',(25,-38,77),(0,0,95.0),42)
camera('QA exploded assembly',(100,-180,113),(0,0,79.0),172)
for name,loc,power,size in [('Key',(30,-42,100),65000,36),('Fill',(-45,-25,55),40000,42),('Rim',(30,48,85),85000,32)]:
    d=bpy.data.lights.new(name,'AREA');o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o)
    o.location=loc;o.rotation_euler=(Vector((0,0,62))-o.location).to_track_quat('-Z','Y').to_euler();d.energy=power;d.shape='DISK';d.size=size
d=bpy.data.lights.new('Aft inspection fill','AREA');o=bpy.data.objects.new('Aft inspection fill',d);bpy.context.collection.objects.link(o)
o.location=(12,-15,-18);o.rotation_euler=(Vector((0,0,2))-o.location).to_track_quat('-Z','Y').to_euler();d.energy=4200;d.shape='DISK';d.size=16
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.20,.24,.29,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.65
scene.render.engine='CYCLES';scene.cycles.samples=20;scene.cycles.use_denoising=True
scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.render.resolution_x=1100;scene.render.resolution_y=1500;scene.render.resolution_percentage=100;scene.camera=cam
bpy.context.view_layer.update()
source_meshes=[o for o in root.children_recursive if o.type=='MESH']
source_tris=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in source_meshes)
bounds=[o.matrix_world@v.co for o in source_meshes for v in o.data.vertices]
assert abs(min(p.z for p in bounds))<1e-5
assert abs(max(p.z for p in bounds)-H)<1e-4
assert all(o.get('part') in ['booster','upper','fairing','recovery'] for o in source_meshes)
assert math.sqrt(1.5**2+1.5**2)+1.4<3.82
assert UPPER_Z-6.6>58.6 and UPPER_Z-6.6+4.85+.24<71
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'new-glenn-9x4-refined.blend'))

# Keep individual editable components in .blend. Runtime meshes consolidate by
# material within semantic parents, while named engine/leg identities remain.
buckets={}
for o in source_meshes:
    ancestor=o
    while ancestor.parent and ancestor.parent not in [booster,upper,recovery,left,right]:ancestor=ancestor.parent
    dest=ancestor.parent
    assert dest in [booster,upper,recovery,left,right]
    # Multi-material aft web is kept independent.
    key=(dest.name,o.data.materials[0].name if len(o.data.materials)==1 else 'AFT_WEB')
    buckets.setdefault(key,[]).append(o)
for (pname,mname),objects in buckets.items():
    bpy.ops.object.select_all(action='DESELECT')
    for o in objects:o.select_set(True)
    bpy.context.view_layer.objects.active=objects[0]
    if len(objects)>1:bpy.ops.object.join()
    o=bpy.context.object;world=o.matrix_world.copy();o.parent=bpy.data.objects[pname];o.matrix_world=world
    o.name=pname+'__'+mname;o['part']=partof(o.parent)
runtime_meshes=[o for o in root.children_recursive if o.type=='MESH']
bpy.ops.object.select_all(action='DESELECT');root.select_set(True)
for o in root.children_recursive:o.select_set(True)
bpy.context.view_layer.objects.active=root
asset=OUT/'new-glenn-9x4-refined.glb'
bpy.ops.export_scene.gltf(filepath=str(asset),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_extras=True,export_animations=False,export_cameras=False,export_lights=False,export_texcoords=False,export_normals=True,export_materials='EXPORT')
stats={'asset':asset.name,'configuration':'New Glenn 9x4 official concept exterior approximation','height_m':H,'body_diameter_m_approx':7.8,'fairing_diameter_m':8.7,'source_meshes':len(source_meshes),'source_triangles':source_tris,'runtime_meshes':len(runtime_meshes),'runtime_batches':len(buckets),'glb_bytes':asset.stat().st_size,'booster_base_y':0,'upper_base_y':UPPER_Z,'fairing_base_y':FAIRING_Z,'be4_block2_count':9,'be3u_count':4,'control_fins':4,'strakes':2,'stowed_legs_approx':6,'ground_y':0,'source_axis':'Z-up','glb_axis':'Y-up','bbox_blender':{'min':[min(p[i] for p in bounds) for i in range(3)],'max':[max(p[i] for p in bounds) for i in range(3)]},'upper_engine_global_min_y':UPPER_Z-6.6,'upper_engine_global_max_y':UPPER_Z-6.6+4.85+.24,'upper_engine_max_radial_extent_m':math.sqrt(4.5)+1.4,'interstage_internal_radius_m':3.82,'semantic_groups':['booster','upper','fairing','booster/recovery','fairing/fairing-left','fairing/fairing-right']}
(OUT/'asset-stats.json').write_text(json.dumps(stats,indent=2));print('ASSET_STATS',json.dumps(stats),flush=True)
def render(c,name,res):
    scene.camera=bpy.data.objects[c];scene.render.resolution_x=res[0];scene.render.resolution_y=res[1]
    scene.render.filepath=str(OUT/name);bpy.ops.render.render(write_still=True)
for c,name,res in [('QA full assembly','qa-full.png',(1100,1500)),('QA aft detail','qa-aft.png',(1400,1200)),('QA upper assembly','qa-upper.png',(1200,1500)),('QA nine engine underside','qa-engines.png',(1200,1200))]:render(c,name,res)
upper.location.z+=14;fairing.location.z+=32;left.location.x=-8;right.location.x=8
bpy.context.view_layer.update()
render('QA exploded assembly','qa-exploded.png',(1200,1500))
# Isolated stage shows all four BE-3U engines without a booster occluding them.
for o in booster.children_recursive:
    if o.type=='MESH':o.hide_render=True
for o in fairing.children_recursive:
    if o.type=='MESH':o.hide_render=True
render('QA separated four engine stage','qa-upper-separated.png',(1200,1500))
print('DONE: GLB, editable blend, six review renders and stats',flush=True)
