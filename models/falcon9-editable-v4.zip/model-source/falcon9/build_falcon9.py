"""Falcon 9 Block 5 standard-fairing educational exterior.
Blender 4.5 LTS. Metres, Z up; GLB exporter converts to Y up.
Official: 70 m total, 3.66 m core, 5.2 x 13.2 m fairing.
Station heights and local hardware profiles below are photographic estimates.
No internal plumbing or engineering-precision claim.
"""
import bpy, math, json, sys, os
from pathlib import Path
from mathutils import Vector, Matrix

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from landing_legs import build_landing_legs, ANIMATION_NAME, ANIMATION_START, ANIMATION_END
from aft_detail import build_aft
OUT = Path(os.environ.get('FALCON9_EXPORT_DIR', str(HERE.parents[1] / 'public' / 'models')))
OUT.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
bpy.context.scene.unit_settings.system = 'METRIC'
bpy.context.scene.unit_settings.scale_length = 1

def mat(name, color, metal, rough):
    m = bpy.data.materials.new(name); m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Metallic'].default_value = metal
    p.inputs['Roughness'].default_value = rough
    return m
paint = mat('White exterior paint · substrate varies by part', (.81,.83,.84), .03, .38)
carbon = mat('Coated composite interstage', (.007,.009,.012), 0, .73)
legmat = mat('Coated landing leg shell', (.012,.016,.021), .02, .60)
titanium = mat('Grid fin · satin dark titanium', (.055,.062,.07), .65, .61)
nozzle = mat('Merlin nozzle exterior', (.17,.18,.19), .75, .38)
inner = mat('Nozzle inner surface', (.010,.013,.017), .25, .74)
edge = mat('Interfaces and nozzle lip', (.37,.39,.41), .78, .31)
seal = mat('Recessed joints', (.085,.092,.10), .1, .65)

def empty(name, parent=None, z=0, part=None):
    o=bpy.data.objects.new(name,None); bpy.context.collection.objects.link(o)
    o.parent=parent; o.location.z=z
    if part: o['part']=part
    return o
root=empty('F9'); root['vehicle']='f9'
root['variant']='Block 5, standard fairing; clean representative exterior'
root['source_precision']='Overall envelope official; component stations estimated from photos'
booster=empty('booster',root,part='booster')
recovery=empty('recovery',booster,part='recovery')
upper=empty('upper',root,47,'upper')
fairing=empty('fairing',root,56.8,'fairing')

def mesh(name, verts, faces, material, parent):
    data=bpy.data.meshes.new(name); data.from_pydata(verts,[],faces); data.update()
    o=bpy.data.objects.new(name,data); bpy.context.collection.objects.link(o)
    o.parent=parent; data.materials.append(material)
    for p in data.polygons: p.use_smooth=True
    return o
def lathe(name, profile, material, parent, n=64, start=0, span=2*math.pi):
    closed=abs(span-2*math.pi)<1e-5
    verts=[(r*math.cos(start+span*i/n),r*math.sin(start+span*i/n),z)
           for r,z in profile for i in range(n+1)]
    faces=[]
    for j in range(len(profile)-1):
        for i in range(n):
            a=j*(n+1)+i; faces.append((a,a+1,a+n+2,a+n+1))
    return mesh(name,verts,faces,material,parent)
def cylinder(name,r,z0,z1,material,parent,n=96):
    return lathe(name,[(0,z0),(r,z0),(r,z1),(0,z1)],material,parent,n)
def torus(name,r,z,minor,material,parent,n=64):
    profile=[(r+minor*math.cos(i*2*math.pi/8),z+minor*math.sin(i*2*math.pi/8)) for i in range(9)]
    return lathe(name,profile,material,parent,n)
def beam(name,a,b,width,depth,material,parent,fin_plane=False):
    a,b=Vector(a),Vector(b); c=(a+b)/2
    bpy.ops.mesh.primitive_cube_add(size=1,location=c)
    o=bpy.context.object; o.name=name; o.parent=parent
    o.dimensions=(width,depth,(b-a).length)
    if fin_plane:
        # Fixed local Y is the fin's outward normal. A tracking quaternion swaps
        # width and depth on diagonal webs, almost closing every lattice opening.
        z_axis=(b-a).normalized(); y_axis=Vector((0,1,0)); x_axis=y_axis.cross(z_axis)
        o.rotation_euler=Matrix((x_axis,y_axis,z_axis)).transposed().to_euler()
    else:
        o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(material)
    bevel=o.modifiers.new('Small manufactured edge radius','BEVEL'); bevel.width=.006; bevel.segments=2
    bpy.context.view_layer.objects.active=o; bpy.ops.object.modifier_apply(modifier=bevel.name)
    return o

# Continuous exterior; the open interstage remains attached to the first stage.
cylinder('booster-paint',1.83,2.15,42.5,paint,booster,128)
# B1048/B1060 photos expose the upper nozzle rings below the shield: the old
# long skirt hid them. End the shallow skirt beside the deck (photo estimate).
lathe('aft-skirt',[(1.79,1.43),(1.82,1.55),(1.83,2.15),(1.79,2.15),(1.78,1.55),(1.75,1.43)],carbon,booster)
lathe('falcon-interstage',[(1.83,42.5),(1.83,47),(1.795,47),(1.795,42.5)],carbon,booster,128)
for z in [2.15,42.5,46.98]: torus('structural-interface',1.834,z,.016,edge,booster)
for z in [14.0,29.7]: torus('subtle-tank-joint',1.831,z,.006,paint,booster)
for z in [43.62,44.74,45.86]: torus('interstage-panel-joint',1.833,z,.008,seal,booster)
# User photographs do not support a full-height black raceway through the logo.
# Omit this unverified feature rather than invent its opposite-side placement.
stowed_legs = build_landing_legs(recovery, deployed=False)

# Folded titanium fins hang from the interstage base. Open diagonal lattice, not solid plates.
for k in range(4):
    g=empty('stowed-grid-fin-'+str(k+1),recovery); g.rotation_euler.z=math.pi/4+k*math.pi/2
    g['gridfin']=True
    w,h,z0,r=.68,1.62,40.76,1.96
    # Thick perimeter with chamfered shoulders, inferred from user photos 1 and 5.
    # Cell count and exact corner radii remain visual approximations.
    outline=[(-.61,0),(.61,0),(.68,.08),(.68,1.36),(.44,1.62),(-.44,1.62),(-.68,1.36),(-.68,.08)]
    edges=list(zip(outline,outline[1:]+outline[:1]))
    for (x,y),(x2,y2) in edges:
        beam('fin-thick-perimeter',(x,r,z0+y),(x2,r,z0+y2),.065,.15,titanium,g,fin_plane=True)
    # Clip both lattice families to the actual shoulder outline.
    for slope in [-1,1]:
        for n in range(-13,14):
            c=n*.19; pts=[]
            for (x,y),(x2,y2) in edges:
                d0=y-slope*x-c; d1=y2-slope*x2-c
                if abs(d0-d1)<1e-7: continue
                t=d0/(d0-d1)
                if 0<=t<=1:
                    v=(x+t*(x2-x),r,z0+y+t*(y2-y))
                    if all((Vector(v)-Vector(p)).length>.001 for p in pts): pts.append(v)
            if len(pts)>=2 and (Vector(pts[0])-Vector(pts[1])).length>.02:
                beam('diagonal-grid-web',pts[0],pts[1],.028,.13,titanium,g,fin_plane=True)
    beam('fin-hinge',(-.28,1.86,42.55),(.28,1.86,42.55),.14,.17,edge,g)
    beam('fin-root-arm',(0,1.86,42.55),(0,r,42.30),.24,.14,titanium,g)

def bell(name,r,h,parent,z=0,x=0,y=0,n=48):
    g=empty(name,parent,z); g.location.x=x; g.location.y=y; g['engine']=True
    # Smooth bell with an actual open throat and separate inner surface.
    profile=[]
    for i in range(25):
        t=i/24
        rr=r*(.18+.82*(1-t)**1.65)
        profile.append((rr,h*t))
    lathe(name+'-outer',profile,nozzle,g,n)
    lathe(name+'-inside',[(rr-.012,zz) for rr,zz in reversed(profile)],inner,g,n)
    torus('rolled-nozzle-lip',r-.005,.018,.014,edge,g,64)
    cylinder('chamber',r*.185,h,h+.32,edge,g,48)
    for zz in [.25*h,.40*h,.55*h]:
        rr=r*(.18+.82*(1-zz/h)**1.65)
        torus('nozzle-band',rr+.004,zz,.008,nozzle,g,64)
    return g
# Photograph-led external shield, apertures and nine Merlin bells. Concealed
# load-bearing Octaweb and engine internals are deliberately not reconstructed.
build_aft(booster)

# Second-stage engine is BELOW its tank, fully inside the interstage when assembled.
cylinder('upper-stage-tank',1.83,0,8.28,paint,upper,128)
lathe('payload-adapter',[(1.83,8.28),(1.83,9.8),(1.78,9.8),(1.78,8.28)],paint,upper)
vac=bell('falcon-vacuum-engine',1.45,2.65,upper,-2.80,n=96)
for z in [0,8.28,9.79]: torus('upper-interface',1.831,z,.012,edge,upper)
# No payload, tanks, valves or attachment detail invented inside the fairing.
profile=[(1.83,0),(1.95,.45),(2.24,1.02),(2.48,1.48),(2.60,2.10),(2.60,6.65)]
# Smooth ogive tangent to cylindrical barrel; target overall fairing height 13.2 m.
for i in range(1,49):
    t=i/48; profile.append((2.60*math.cos(t*math.pi/2)**.82,6.65+6.55*t))
for side,start in [('left',math.pi/2),('right',-math.pi/2)]:
    half=empty('fairing-'+side,fairing,part='fairing')
    outer=lathe('fairing-'+side+'-skin',profile,paint,half,64,start,math.pi)
    outer.data.materials.append(carbon)
    solid=outer.modifiers.new('Educational thin shell, not engineering thickness','SOLIDIFY'); solid.thickness=.025
    bpy.context.view_layer.objects.active=outer; bpy.ops.object.modifier_apply(modifier=solid.name)
    for angle in [start,start+math.pi]:
        for (r,z),(r2,z2) in zip(profile,profile[1:]):
            beam('fairing-seam',(r*math.cos(angle),r*math.sin(angle),z),(r2*math.cos(angle),r2*math.sin(angle),z2),.009,.009,seal,half)

# Preserve editable components and NLA animation in .blend. Keep all moving
# node boundaries when batching the web export, including shell hinge children.
bpy.context.scene.frame_set(ANIMATION_START)
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'falcon9-block5.blend'))
leg_roots = list(stowed_legs.children)
hinges = [o for o in stowed_legs.children_recursive if o.get('rig_role') == 'rigid-shell-hinge']
for parent in [booster,recovery,upper,*list(fairing.children),*leg_roots,*hinges]:
    # Gather meshes under child hardware groups, but do not cross semantic part boundaries.
    def own_meshes(p):
        out=[]
        for c in p.children:
            if c.get('batch_boundary') or c.animation_data: continue
            if c.type=='MESH': out.append(c)
            elif 'part' not in c: out.extend(own_meshes(c))
        return out
    buckets={}
    for o in own_meshes(parent): buckets.setdefault(tuple(m.name for m in o.data.materials),[]).append(o)
    for objects in buckets.values():
        if len(objects)<2: continue
        bpy.ops.object.select_all(action='DESELECT')
        for o in objects: o.select_set(True)
        bpy.context.view_layer.objects.active=objects[0]; bpy.ops.object.join()
        bpy.context.object.name=parent.name+'-'+objects[0].data.materials[0].name
        world=bpy.context.object.matrix_world.copy(); bpy.context.object.parent=parent; bpy.context.object.matrix_world=world
# Bake each export mesh into its semantic parent's coordinates. This keeps browser
# bounding boxes tight after material batching and preserves the metre envelope.
for o in list(bpy.context.scene.objects):
    if o.type != 'MESH': continue
    if o.animation_data: continue
    bpy.ops.object.select_all(action='DESELECT')
    o.select_set(True); bpy.context.view_layer.objects.active=o
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
bpy.ops.object.select_all(action='DESELECT')
for o in [root, *root.children_recursive]:
    o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'falcon9-block5.glb'),export_format='GLB',
    use_selection=True,export_extras=True,export_yup=True,
    export_animations=True,export_animation_mode='NLA_TRACKS',
    export_frame_range=True,export_force_sampling=True,export_frame_step=1,
    export_cameras=False,export_lights=False)
triangles=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in bpy.context.scene.objects if o.type=='MESH')
report={'variant':root['variant'],'height_m':70,'body_diameter_m':3.66,'fairing_height_m':13.2,
    'triangles':triangles,'mesh_objects':sum(o.type=='MESH' for o in bpy.context.scene.objects),
    'glb_bytes':(OUT/'falcon9-block5.glb').stat().st_size,
    'textures':[{'name':im.name,'width':im.size[0],'height':im.size[1]} for im in bpy.data.images if im.name.startswith('F9 aft ')],
    'animation':{'clip':ANIMATION_NAME,'duration_s':3.2,'fps':30,
                 'start_frame':ANIMATION_START,'end_frame':ANIMATION_END,
                 'angular_progress':'linear; the player may ease clip time',
                 'default_pose':'stowed','root_lift_m':0},
    'notes':'Original SpaceX decal applied by website; photo-estimated component stations. No fictitious interiors. Four rigid leg shells and four-stage TRS telescopic stroke; educational timing, not engineering kinematics.'}
(HERE/'asset-stats.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
